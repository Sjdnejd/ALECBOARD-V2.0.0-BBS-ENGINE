<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?=$_site_info['site_name']?></title>

<!-- Bootstrap -->
<link href="<?=$_url['site']?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="<?=$_url['site']?>bootstrap/css/font-awesome.min.css" rel="stylesheet">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<link href="<?=$_url['css']?>m_style.css" rel="stylesheet" type="text/css">

<script src="<?=$_url['js']?>common.js"></script>
<script src="<?=$_url['js']?>lib.validate.js"></script>
<script src="<?=$_url['js']?>jquery-1.10.2.min.js"></script>
<script src="<?=$_url['site']?>bootstrap/js/bootstrap.min.js"></script>

<script language="javascript">
set_url("<?=$_url['bbs']?>","<?=$_url['member']?>");
</script>

<script>
$(document).ready(function(e) {
	$('#site-main').on('touchend click', function(event) {
		if ($('#sb_left_menu').css('display') != 'none') {
			$('#sb_left_menu').hide(200);
		}
	});
	
	$('#sb_left_btn').on('touchend click', function(event) {
		event.stopPropagation();
		event.preventDefault();
		if (event.type === 'touchend') selector.off('click');
		$('#sb_left_menu').toggle(200);
	});
	$('#sb_left_menu').height($(window).height() + 50);
	
	$(window).on('resize',function () {
		$('#sb_left_menu').height($(window).height() + 50);
	});

});
</script>
</head>