<?
	$site_path="../../";
	$site_url=str_replace("//","/",dirname(dirname(dirname($_SERVER['PHP_SELF'])))."/");
	include_once($site_path."alec2_include/lib.php");
	include_once("../include/menu.php");
	include_once("../include/auth_chk.php");
?>