<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	$_MENU='0502';
	include_once("../include/header_code.php");

	$rs_list = new $rs_class($dbcon);
	$rs_list->clear();
	$rs_list->set_table($_table['popup']);

	if(is_array($ss)) {
		foreach($ss as $__k => $__v) {
			switch ($__k) {
				/***********************************************************************/
				// 검색어 '고객명','대표자명','전화번호','담당자','이메일','담당자연락처'
				case '0' : 
					if($kw!='' && $__v!='') {
						$ss_kw=$dbcon->escape_string($kw,DB_LIKE);
						switch ($__v) {
							case '1' : $rs_list->add_where("popup_name LIKE '%$ss_kw%' escape '".$dbcon->escape_ch."'"); break;
						}
						unset($ss_kw);
					}
					break; 
				/***********************************************************************/
				// 필터 조건에 의한 필터링
				case '1' : // 
					if($__v != '') { $rs_list->add_where("'$__v' = pp_win_type_cd"); } break;
				case '2' : // 
					if($__v != '') { $rs_list->add_where("'$__v' = pp_use_yn"); } break;
				break;
			}
		}
	}

	switch ($ot) {
		case 10 : $rs_list->add_order("pp_num DESC");		break;
		default : $rs_list->add_order("pp_num DESC");		break;
	}
	
	$page_info=$rs_list->select_list($page,20,10);
	$win_type_arr=rg_comm_code('popup','win_type');
	$cont_type_arr=rg_comm_code('popup','cont_type');
	$yns_arr=rg_comm_code('comm','yns');
	$token=rg_get_token();
?>
<? include("../include/header_win.php"); ?>
<script>
function edit_data(num) {
	location.href='popup_edit.php?<?=$p_str?>&page=<?=$page?>&mode=modify&num='+num;
}
function delete_data(num) {
	if(confirm('삭제하시겠습니까?'))
	location.href='popup_edit.php?<?=$p_str?>&page=<?=$page?>&mode=delete&token=<?=$token?>&num='+num;
}
</script>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?></td>
  </tr>
</table>
<br>
<table width="100%" cellspacing="0" style="border-collapse:collapse;table-layout:auto">
<form name="search_form" method="get" enctype="multipart/form-data">
	<tr> 
		<td>
  사용 :
  <select name="ss[2]" onChange="search_form.submit()">
    <option value="">=전체=</option>
    <?=rg_html_option($yns_arr,"$ss[2]")?>
  </select>
  구분 :
  <select name="ss[1]" onChange="search_form.submit()">
    <option value="">=전체=</option>
    <?=rg_html_option($win_type_arr,"$ss[1]")?>
  </select>
  </td>
		<td align="right">Total : 
			<?=$page_info['total_rows']?>
			(<?=$page_info['page']?>/<?=$page_info['total_page']?>)</td>
    </tr>
</form>
</table>
<br>
<form name="list_form" method="post" enctype="multipart/form-data" action="?<?=$p_str?>">
<input name="mode" type="hidden" value="">
<table border="0" cellpadding="0" cellspacing="0" width="100%" class="site_list" onmouseover="list_over_color(event,'#FFE6E6',1)" onmouseout='list_out_color(event)'>
	<tr align="center" bgcolor="#F0F0F4">
		<td width="40" >No</td>
		<td width="40">수정</td>
		<td width="40">삭제</td>
		<td>구분</td>
		<td>팝업타이틀</td>
		<td>방식</td>
		<td>사용여부</td>
		<td>기간</td>
		<td>미리보기</td>
		<td width="80">등록일</td>
		</tr>
<?
	if($rs_list->num_rows()<1) {
		echo "
	<tr height=\"100\">
		<td align=\"center\" colspan=\"15\"><B>등록(검색) 된 자료가 없습니다.</td>
	</tr>";
	}
	
	$no = $page_info['start_no'];
	while($R=$rs_list->fetch()) {
		$no--;
//		$R['images']=unserialize($R['images']);
?>
<?
	if($R['pp_win_type_cd']=='02') {
?>
<script language="JavaScript">
<!--
function closeWin_<?=$R[pp_num]?>() { 
document.getElementById('pop<?=$R[pp_num]?>').style.visibility = "hidden";
}
function openWin_<?=$R[pp_num]?>() { 
document.getElementById('pop<?=$R[pp_num]?>').style.visibility = "visible";
}
//--> 
</script>
<div id="pop<?=$R[pp_num]?>" style="position:absolute;width:<?=$R[pp_width]?>px;height:<?=$R[pp_height]?>px;left:<?=$R[pp_left]?>px;top:<?=$R[pp_top]?>px;z-index:200;visibility:hidden;border:#999999 1px solid;text-align:center;background-color:#FFF">
<iframe src="<?=$_url['site']?>alec2_popup/popup.php?num=<?=$R[pp_num]?>" frameborder="0" width="<?=$R[pp_width]?>" height="<?=$R[pp_height]?>" scrolling="<?=(($R[pp_scrollbars]!='Y')?'NO':'YES')?>" border="0" marginheight="0" marginwidth="0"></iframe>
<br>
<a href="javascript:closeWin_<?=$R[pp_num]?>();">닫기</a>
</div> 
<? } ?>
	<tr height="25">
		<td align="center"><?=$no?></td>
		<td align="center" style="cursor:pointer;" onclick="edit_data('<?=$R[pp_num]?>')">수정</td>
		<td align="center" style="cursor:pointer;" onclick="delete_data('<?=$R[pp_num]?>')">삭제</td>
		<td align="center"><?=$win_type_arr[$R['pp_win_type_cd']]?></td>
		<td align="center"><?=$R['pp_title']?></td>
		<td align="center"><?=$cont_type_arr[$R['pp_cont_type_cd']]?></td>
		<td align="center"><?=$yns_arr[$R['pp_use_yn']]?></td>
		<td align="center">
<?
	if($R['pp_start_use_yn']=='Y') {
		echo rg_date($R['pp_start_time'],'','');
	}
	echo " ~ ";
	if($R['pp_end_use_yn']=='Y') {
		echo rg_date($R['pp_end_time'],'','');
	}
?>
    </td>
		<td align="center" style="cursor:pointer;" onclick="<? if($R['pp_win_type_cd']=='02') { ?>openWin_<?=$R[pp_num]?>()<? } else { ?>window_open('<?=$_url['site']?>alec2_popup/popup.php?num=<?=$R[pp_num]?>','popup','width=<?=$R[pp_width]?>,height=<?=$R[pp_height]?>,scrollbars=<?=(($R[pp_scrollbars]!='Y')?'NO':'YES')?>,left=<?=$R[pp_left]?>,top=<?=$R[pp_top]?>,')<? } ?>">[보기]</td>
		<td align="center"><?=rg_date($R[reg_date],'%Y-%m-%d')?></td>
		</tr>
<?
}
?>
</table>
<table width="100%">
	<tr>
		<td align="center" width="50"><input type="button" value="등록하기" class="button" onclick="location.href='popup_edit.php?<?=$p_str?>&page=<?=$page?>'"></td>
		<td align="center"><?=rg_navi_display($page_info,$_get_param[2]); ?></td>
	</tr>
</table>
</form>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>