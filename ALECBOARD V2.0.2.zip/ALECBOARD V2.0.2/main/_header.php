<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<? include('../include/header_win.php'); ?>
<? include('../include/header.php'); ?>
<!-- // 메인 컨텐츠 -->
<div id="mcontent">
  <!-- 좌측 컨텐츠 -->
	<div class="mleft">
			<table width="175"  border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td height="10"></td>
				</tr>
				<tr>
					<td align="center"><?=rg_outlogin('default',$ret_url)?></td>
				</tr>
				<tr>
					<td height="10"></td>
				</tr>
			</table>
<?
	include("../include/left_bbs.php");
?>
	</div>
 <!-- // 좌측 컨텐츠 -->
 <!-- 우측 컨텐츠 -->
  <div class="mright">
