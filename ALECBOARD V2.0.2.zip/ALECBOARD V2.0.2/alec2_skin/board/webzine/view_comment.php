<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
/* =====================================================
 프로그램명 : ALECBOARDV2 V4 게시판스킨

파일설명 : 코멘트루틴

변수설명
$_bbs_auth['comment'] : 코멘트 입력여부
$bd_num : 글번호
$vcfg['input_name'] : 이름입력받을지
$s_bc_name : 기본으로 채워질 이름
$vcfg['spam_chk'] : 스팸체크여부
$spam_chk_img : 스팸이미지
$spam_chk_code : 스팸체크코드(현재는고정)
$comment_delete_chk : 코멘트삭제 가능여부
$comment_delete_url : 코멘트삭제 주소
$bc_write_date : 코멘트 작성일
$bc_content : 코멘트내용
===================================================== */
?>
<div style="clear:both;padding:0 10px 3px 10px">
<form name="cmt_list_form" method="post" enctype="multipart/form-data" action="?">
<?=$_post_param[3]?>
<input name="mode" type="hidden" value="">
<input name="mode2" type="hidden" value="">
<input type="hidden" name="bd_num" value="<?=$bd_num?>">
<input type="hidden" name="token" value="<?=$token?>">
<?
	// 코멘트 목록을 뿌려주는 부분
	include("clist_pre_process.php");
	while($data_comment=$rs_comment->fetch()) {
		include("clist_data_process.php");
?>
<div style="clear:both;border-bottom:1px #CCC dotted;padding-top:7px;padding-bottom:5px">
	<div>
<? if($_bbs_auth['admin']) { ?><input type=checkbox name="chk_cnums[]" value="<?=$bc_num?>"><? } ?>
<?=$bd_name_layer?> <span style="color:#999">( <?=$bc_write_date?>, <?=$bc_write_ip?> )</span>
<? if($comment_delete_chk) { ?> -  <a href="<?=$comment_delete_url?>">x</a><? } ?>
	</div>
	<div><?=$bc_content?></div>
</div>
<? } ?>	
<? if($_bbs_auth['admin']) { ?>
<script>
function comment_delete_select(){
	if(!chk_checkbox(cmt_list_form,'chk_cnums[]',true)){
		alert('한개이상 선택 하세요.');
		return;
	}
	if(!confirm('삭제하시겠습니까?')){
		return;
	}
	
	document.cmt_list_form.mode.value='comment_delete';
	document.cmt_list_form.mode2.value='select';
	document.cmt_list_form.submit();
}
</script>
전체댓글선택 : <input type="checkbox" onClick="set_checkbox(cmt_list_form,'chk_cnums[]',this.checked)">
<input type="button" value="선택 코멘트삭제" class="button" onclick="comment_delete_select();">
<? } ?>
</form>
</div>
<? if($_bbs_auth['comment']) { // 코멘트 쓰기 ?>
<form name="comment_form" action="?" method="post" onSubmit="return validate(this)">
<?=$_post_param[3]?>
<input type="hidden" name="mode" value="comment_write">
<input type="hidden" name="bd_num" value="<?=$bd_num?>">
<input type="hidden" name="token" value="<?=$token?>">
<div style="border:#EEE 1px solid;padding:10px;margin:10px;margin-bottom:0">
<? if($vcfg['input_name']) { ?>
	<div>
		<div style="float:left;margin-right:20px">
    작성자 : <input type="text" name="bc_name" value="<?=$s_bc_name?>" class="input" required hname="작성자">
		</div>
		<div>
    암호 : <input type="password" name="bc_pass" class="input">
		</div>
	</div>
<? } else { ?>
	<div>
    작성자 : <?=$s_bc_name?>
	</div>
<? } ?>
	<table width="100%" cellspacing="2" border="0">
		<td align="center">
			<textarea name="bc_content" rows="5" style="width:99%;display:block" class="input" required hname="내용"></textarea>
		</td>
		<td width="70">
      <input type="submit" value="등록하기" class="button" style="width:95%;height:99%">
		</td>
	</table>
	<div style="clear:both"></div>
<? if($vcfg['spam_chk']) { ?>
	<div>
      스팸방지 : <?=$spam_chk_img?> 좌측의 문자를 입력해주세요.
    <input name="spam_chk" type="text" class="input" size="10" required hname="스팸방지코드">
    <input name="spam_chk_code" type="hidden" value="<?=$spam_chk_code?>"></td>
	</div>
<? } ?>
</div>
</form>
<? } ?>