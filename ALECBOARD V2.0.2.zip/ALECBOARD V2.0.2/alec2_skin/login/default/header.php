<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<style type='text/css'> 
.id_blur { background: transparent url("<?=$skin_url?>images/login_bg.gif") top left} 
.id_focus { background: #ffffe0 ; color: #003300 } 
.pw_blur { background: transparent url("<?=$skin_url?>images/login_bg.gif") bottom left} 
.pw_focus { background: #ffffe0 ; color: #003300 }

.login_default_v1_box .input {width:100px;}

</style>
<div class="login_default_v1_box" style="border:#999 1px solid;border-radius:4px;background-color:#FFF;padding-bottom:4px">