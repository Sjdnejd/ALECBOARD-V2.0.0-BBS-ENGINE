<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	include_once("../alec2_include/lib.php");

	if(!$_mb) {
		rg_href('','로그인 후 이용해주세요.','close');
	}

	if($_SERVER['REQUEST_METHOD']=='POST' && $mode=='note_write_ok') {
		if(!rg_verify_token($_POST['token'])) {
			rg_href('','정상적인 접근이 아닙니다.\n\n새로고침후 다시 시도해보세요.','back');
		}

		$result = rg_note_send($recv_id,$nt_content,$nt_link='',$save_sent_box);
		if($result['cnt']<1) {
			rg_href('','받는이 아이디를 입력해주세요.','back');
		}
		rg_href('','쪽지보내기 성공!!','close');
	}
	$token=rg_get_token();
?>
<!doctype html>
<html>
<head>
<title></title>
<meta charset="utf-8">
<link href="<?=$_url['css']?>style.css" rel="stylesheet" type="text/css">
</head>
<script src="<?=$_url['js']?>common.js"></script>
<script src="<?=$_url['js']?>lib.validate.js"></script>
<body bottommargin="0" topmargin="0" leftmargin="0" rightmargin="0">
<div class="title">쪽지쓰기</div>
		<form name="note_write_form" method="post" action="?" onSubmit="return validate(this)" enctype='multipart/form-data'>
		<input type="hidden" name="mode" value="note_write_ok">
		<input type="hidden" name="token" value="<?=$token?>">
		<table width="100%" align="center" border="0" cellpadding="0" cellspacing="6" style="table-layout:fixed">
			<tr>
				<td width="100" align="right"><strong>받는이 아이디</strong></td>
				<td><input type="text" class="input" name="recv_id" size="35" hname="아이디" required value="<?=$recv_id?>"></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><textarea name="nt_content" cols="50" rows="15" class="input" hname="내용"></textarea></td>
				</tr>
			<tr>
				<td colspan="2" align="center"><input type="checkbox" name="save_sent_box" value="1" checked class="none">
				  보낸쪽지함에 저장 (수신확인) </td>
			</tr>
		</table>
		<div style="margin:10px 0 5px 0;text-align:center">
				<input type="submit" class="button" value=" 보내기 ">
				<input type="button" class="button" value="  닫  기  " onClick="self.close()">
		</div>
		</form>
</body>
</html>
