<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
/* =====================================================
 프로그램명 : ALECBOARDV2 V4 갤러리 스킨

파일설명 : 갤러리 목록

변수설명
$_bbs_info['use_category'] : 카테고리 사용유무
$cat_name : 카테고리명

$_post_param[0] : POST방식의 기본정보, 게시판코드만
$_post_param[3] : POST방식의 기본정보, 전체(게시판코드,키워드,필터,정렬,페이지)

$_bbs_auth['cart'] : 카트사용여부
$_bbs_auth['write'] : 글쓰기권한여부
$_bbs_auth['admin'] : 관리자여부

$bd_delete : 삭제여부
$bd_secret : 비밀글여부
$bd_notice : 공지사항여부
$o_bd_num : 최근본글번호
$bd_num : 현재글번호
$_url['bbs'] : 게시판URL

$ss['cat'] : 검색 카테고리선택
$url_all_list : 검색 action URL(list.php를 의미)
$kw : 검색키워드

$i_no : 글순서번호
$i_reply : 응답글들여쓰기,아이콘 (setup.php 에서 정의)
$i_secret : 비밀글아이콘 (setup.php 에서 정의)
$i_new : 최근글아이콘 (setup.php 에서 정의,표시시간은 게시판관리자에서)
$i_comment_count : 코멘트개수 (형태는 setup.php 에서 정의)
$view_url : 글보기 URL
$bd_subject : 글제목

$bbs_code : 게시판코드
$mb_icon : 작성자가 회원이면 회원아이콘
$mb_id : 회원이라면 아이디
$bd_name : 작성자명
$open_homepage : 글작성시 입력한 홈페이지주소
$open_email : 글작성시 입력한 이메일주소
$open_profile : 회원정보공개여부
$open_memo : 쪽지보내기

$bd_write_date : 글작성일
$bd_view_count : 글조회수
$bd_vote_yes : 추천/찬성 표수
$bd_vote_no : 반대 표수

$img_view_url : 첫번째 이미지 경로

$_list_cfg['col_cnt'] : 한줄에 보여줄 이미지수 (관리자에서 설정)
$_list_cfg['img_width'] : 이미지 넓이 (관리자에서 설정)
$_list_cfg['img_height'] : 이미지 높이 (관리자에서 설정)

기타 list_data_process.php 와 db구조 참고
===================================================== */
	list($old_width, $old_height) = getimagesize($_path['bbs_data'].$first_img['sname']);

	// 이미지 비율을 계산한다.
	if($_list_cfg['img_height'] < $old_height || $_list_cfg['img_width'] < $old_width) {
		$new_height = $_list_cfg['img_height'];
		$new_width = $_list_cfg['img_width'];
		if(($old_width / $old_height) > ($new_width / $new_height)){ 
			$new_height = ($old_height / ($old_width / $new_width));
		} else {
			$new_width = ($old_width / ($old_height / $new_height));
		}
	} else {
		$new_height = $old_height;
		$new_width = $old_width;
	}
?>
<? if($li % $_list_cfg['col_cnt'] == 0) echo "<tr>"; ?>
<td width="<?=(1/$_list_cfg['col_cnt'])*100?>%" valign="top" align="center">
  <table border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td class="thumbnail_img" width="<?=$_list_cfg['img_width']?>" height="<?=$_list_cfg['img_height']?>">
			<a href="<?=$view_url?>">	<? if($img_view_url) { ?><img src="<?=$img_view_url?>" width="<?=$new_width?>" height="<?=$new_height?>" border="0"><? } ?></a>
      </td>
    </tr>
	</table>
	<div>
<? if($_bbs_auth['cart']) { ?>
<input type=checkbox name="chk_nums[]" value="<?=$bd_num?>" class=none>
<? } ?>
<? if($_bbs_info['use_category']) { ?>[<?=$cat_name?>] <? } ?>
<?=$i_secret?> <a href="<?=$view_url?>"><?=$bd_subject?></a> <?=$i_comment_count?>
	</div>
</td>
<? if($li % $_list_cfg['col_cnt'] == ($_list_cfg['col_cnt']-1))  echo "</tr>"; ?>
<? $li++; ?>
