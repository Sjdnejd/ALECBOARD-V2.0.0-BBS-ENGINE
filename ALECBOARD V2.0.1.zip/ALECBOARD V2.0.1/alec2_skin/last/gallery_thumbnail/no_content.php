<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	/* 글이 없을때 보여주는 내용 */
?>
<tr>
	<td align="center">최신글이 없습니다.</td>
</tr>