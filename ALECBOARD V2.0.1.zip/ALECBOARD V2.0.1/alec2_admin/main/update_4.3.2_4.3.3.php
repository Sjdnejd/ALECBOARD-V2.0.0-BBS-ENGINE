<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	$_MENU='0505';
	include_once("../include/header_code.php");

	if($act) {
		switch(DB_TYPE) { // db종류
			case 'cubrid' :
				$dbcon->query("
ALTER TABLE  `{$_table['bbs_cfg']}` 
ADD  `m_bbs_skin` VARCHAR( 255 ) default '' NOT NULL,
ADD  `m_header_file` VARCHAR( 255 ) default '' NOT NULL,
ADD  `m_header_tag` varchar,
ADD  `m_footer_tag` varchar,
ADD  `m_footer_file` VARCHAR( 255 ) default '' NOT NULL
				");
				$dbcon->query("
ALTER TABLE  `{$_table['group']}` 
ADD  `mgr_header_file` VARCHAR( 255 ) default '' NOT NULL,
ADD  `mgr_header_tag` varchar,
ADD  `mgr_footer_tag` varchar,
ADD  `mgr_footer_file` VARCHAR( 255 ) default '' NOT NULL
				");
			break;
			
			
			case 'oracle' :
				$dbcon->query("
ALTER TABLE  `{$_table['bbs_cfg']}` 
ADD  `m_bbs_skin` varchar2(255) default '',
ADD  `m_header_file` varchar2(255) default '',
ADD  `m_header_tag` varchar2(4000),
ADD  `m_footer_tag` varchar2(4000),
ADD  `m_footer_file` varchar2(255) default ''
				");
				$dbcon->query("
ALTER TABLE  `{$_table['group']}` 
ADD  `mgr_header_file` varchar2(255) default '',
ADD  `mgr_header_tag` varchar2(4000),
ADD  `mgr_footer_tag` varchar2(4000),
ADD  `mgr_footer_file` varchar2(255) default ''
				");
			break;
			
			
			case 'mysql' :
				$dbcon->query("
ALTER TABLE  `{$_table['bbs_cfg']}` 
ADD  `m_bbs_skin` VARCHAR( 255 ) NOT NULL COMMENT  '모바일 스킨',
ADD  `m_header_file` VARCHAR( 255 ) NOT NULL COMMENT  '모바일 헤더파일',
ADD  `m_header_tag` TEXT NOT NULL COMMENT  '모바일 헤더태그',
ADD  `m_footer_tag` TEXT NOT NULL COMMENT  '모바일 푸터태그',
ADD  `m_footer_file` VARCHAR( 255 ) NOT NULL COMMENT  '모바일 푸터파일'
				");
				$dbcon->query("
ALTER TABLE  `{$_table['group']}` 
ADD  `mgr_header_file` VARCHAR( 255 ) NOT NULL COMMENT  '모바일 헤더파일',
ADD  `mgr_header_tag` TEXT NOT NULL COMMENT  '모바일 헤더태그',
ADD  `mgr_footer_tag` TEXT NOT NULL COMMENT  '모바일 푸터태그',
ADD  `mgr_footer_file` VARCHAR( 255 ) NOT NULL COMMENT  '모바일 푸터파일'
				");
			break;
		}

		$rs->clear();
		$rs->set_table($_table['group']);
		$rs->add_field("mgr_header_file",'../include/m_header.php');
		$rs->add_field("mgr_footer_file",'../include/m_footer.php');
		$rs->update();
		
		$rs->clear();
		$rs->set_table($_table['bbs_cfg']);
		$rs->add_field("m_bbs_skin",'default_mobile');
		$rs->add_where("bbs_skin='default'");
		$rs->update();
		
		$rs->clear();
		$rs->set_table($_table['bbs_cfg']);
		$rs->add_field("m_bbs_skin",'webzine_mobile');
		$rs->add_where("bbs_skin='webzine'");
		$rs->update();

		$rs->clear();
		$rs->set_table($_table['bbs_cfg']);
		$rs->add_field("m_bbs_skin",'gallery_thumb_mobile');
		$rs->add_where("bbs_skin='gallery_thumbnail'");
		$rs->update();
		
		rg_href("update.php","database 변환이 완료되었습니다.");
	}
?>
<? include("../include/header_win.php"); ?>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?> > 4.3.2 => 4.3.3</td>
  </tr>
</table>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="center"><br>
    <form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="if(!confirm('확실합니까?')) return false;">
<input name="act" type="hidden" value="ok">
          <table border="0" cellspacing="0" cellpadding="0" width="70%" class="site_content">
          <tr> 
            <td height="30" align="center" valign="middle" bgcolor="f7f7f7">ALECBOARDV2 database를 4.3.2 에서 4.3.3 으로 변환합니다.<br>
							에러 및 데이타 유실에대한 책임을 지지 않사오니 미리 백업해주시기 바랍니다.<br>
<br>
업데이트 내용<br>
<br>
1. 모바일 웹을 위한 필드 추가</td>
          </tr>
        </table>
        <br>
        <input type="submit" value=" 업데이트시작 " class="button">
        <input type="button" value=" 취 소 " class="button" onClick="history.back()">
      </form></td>
  </tr>
</table>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>