<?
/* =====================================================
	프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com
	
  최종수정일 : 
 ===================================================== */
	$_MENU='0106';
	include_once("../include/header_code.php");
	
	if($_SERVER['REQUEST_METHOD']=="POST" && $mode == "update"){
		if(!rg_verify_token($_POST['token'])) {
			rg_href('','정상적인 접근이 아닙니다.\n\n새로고침후 다시 시도해보세요.','back');
		}

		$rs->clear();
		$rs->set_table($_table['setup']);
		$rs->add_field("ss_content",$content);
		$rs->add_where("ss_name='page_company'");
		$rs->update();
		rg_href('?');
	}

	// 사이트 설정
	$rs->clear();
	$rs->set_table($_table['setup']);
	$rs->add_field("ss_content");
	$rs->add_where("ss_name='page_company'");
	$rs->select();
	if($rs->num_rows()<1) {
		$rs->clear_field();
		$rs->add_field("ss_name","page_company");
		$rs->insert();

		$rs->clear_field();
		$rs->add_field("ss_content");
		$rs->select();
	}
	$rs->fetch('content');
	$token=rg_get_token();
?>
<? include("../include/header_win.php"); ?>
<script>
var editorConfig_upload='Y';
$(document).ready(function(e) {
	CKEDITOR.replace( 'content', {height: '400px'});
	CKEDITOR.replace( 'mb_privacy', {height: '400px'});
});
</script>
<script src="<?=$_path['site']?>ckeditor/ckeditor.js"></script>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?></td>
  </tr>
</table>
<br>
<form name=form1 method=post action="?" onSubmit="return validate(this)">
  <input type=hidden name=mode value="update">
	<input type="hidden" name="token" value="<?=$token?>">
  <table border="0" cellspacing="0" cellpadding="0" width="700" align="center">
    <tr>
      <td class="a_sub_title">회사소개</td>
    </tr>
    <tr>
      <td><textarea name="content" id="content" cols="80" rows="24"><?=$content?></textarea></td>
    </tr>
  </table>
  <br>
  <table width="700" align="center">
    <tr>
      <td align=center><input type="submit" value=" 저  장 " class="button">
      </td>
    </tr>
  </table>
</form>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>