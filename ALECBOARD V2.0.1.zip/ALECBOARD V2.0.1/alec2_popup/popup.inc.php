<?
	$rs_popup = new $rs_class($dbcon);
	$rs_popup->clear();
	$rs_popup->set_table($_table['popup']);
	$rs_popup->add_where("'Y' = pp_use_yn");
	$rs_popup->add_where("('Y' <> pp_start_use_yn OR pp_start_time < ".time().")");
	$rs_popup->add_where("('Y' <> pp_end_use_yn OR pp_end_time > ".time().")");
	while($popup=$rs_popup->fetch()) {
		if($_COOKIE["pop$popup[pp_num]"]=='no') continue;
			if($popup['pp_win_type_cd']=='02') {
?>
<script language="JavaScript">
<!--
function closeWin_<?=$popup[pp_num]?>() { 
document.getElementById('pop<?=$popup[pp_num]?>').style.visibility = "hidden";
}
//--> 
</script>
<div id="pop<?=$popup[pp_num]?>" style="position:absolute;width:<?=$popup[pp_width]?>px;height:<?=$popup[pp_height]?>px;left:<?=$popup[pp_left]?>px;top:<?=$popup[pp_top]?>px;z-index:200;visibility:visible;border:#999999 1px solid;text-align:center;background-color:#FFF">
<iframe src="<?=$_url['site']?>alec2_popup/popup.php?num=<?=$popup[pp_num]?>" frameborder="0" width="<?=$popup[pp_width]?>" height="<?=$popup[pp_height]?>" scrolling="<?=(($popup[pp_scrollbars_yn]!='Y')?'NO':'YES')?>" border="0" marginheight="0" marginwidth="0"></iframe>
<!--<a href="javascript:closeWin_<?=$popup[num]?>();">닫기</a>-->
</div> 
<?
			} else {
?>
<script>
	window_open('<?=$_url['site']?>alec2_popup/popup.php?num=<?=$popup[pp_num]?>','popup','width=<?=$popup[pp_width]?>,height=<?=$popup[pp_height]?>,scrollbars=<?=(($popup[pp_scrollbars_yn]!='Y')?'NO':'YES')?>,left=<?=$popup[pp_left]?>,top=<?=$popup[pp_top]?>,');
</script>
<?
		}
	}
?>