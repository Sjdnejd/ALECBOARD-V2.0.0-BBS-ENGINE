<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	include('_br.inc.php');
?>