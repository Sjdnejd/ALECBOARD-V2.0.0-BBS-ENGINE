<?
	$_MENU_ADM=array(
		'01' => array(
				'0100' => array("기본정보","../main/cfg_site.php"),
				'0101' => array("사이트정보","../main/cfg_site.php"),
				'0102' => array("회원항목설정","../main/cfg_member_form.php"),
				'0103' => array("회원레벨설정","../main/cfg_member_level.php"),
				'0104' => array("sns로그인설정","../main/cfg_sns_login.php"),
				'0105' => array("약관/개인정보방침","../main/cfg_agree.php"),
				'0106' => array("회사소개","../main/cfg_company.php"),
		),
		'02' => array(
				'0200' => array("회원관리","../member/member_list.php"),
				'0201' => array("회원목록","../member/member_list.php"),
				
				'0202' => array("단체메일링","../member/send_email.php"),
				'0203' => array("단체쪽지","../member/send_note.php"),
		),
		'03' => array(
				'0300' => array("그룹관리","../main/group_list.php"),
				'0301' => array("그룹목록","../main/group_list.php"),
				'0302' => array("그룹회원목록","../main/group_member_list.php"),
		),
		'04' => array(
				'0400' => array("게시판관리","../main/bbs_list.php"),
				'0401' => array("게시판목록","../main/bbs_list.php"),
				'0402' => array("게시판등록","../main/bbs_edit.php"),
		),
		'05' => array(
				'0500' => array("기타관리","../main/create_zip_tables.php"),
				'0501' => array("우편번호 테이블생성","../main/create_zip_tables.php"),
				'0502' => array("팝업관리","../main/popup_list.php"),
				'0504' => array("ALECBOARDV2제거","../main/uninstall.php"),
				'0505' => array("업데이트","../main/update.php"),
		),

		'06' => array(
				'0600' => array("접속통계","../counter/index.php?type=main"),
				'0601' => array("시간대별","../counter/index.php?type=hour"),
				'0602' => array("일별통계","../counter/index.php?type=day"),
				'0603' => array("월별통계","../counter/index.php?type=month"),
				'0604' => array("년별통계","../counter/index.php?type=year"),
				'0605' => array("브라우저","../counter/index.php?type=br"),
				'0606' => array("운영체제","../counter/index.php?type=os"),
				'0607' => array("해상도","../counter/index.php?type=res"),
				'0608' => array("검색엔진","../counter/index.php?type=search"),
				'0609' => array("호스트별","../counter/index.php?type=host"),
				'0610' => array("접속로그","../counter/index.php?type=log"),
		),
		'99' => array(
				'9900' => array("로그아웃",$_url['member']."login.php?logout&ret_url=".urlencode($_url['admin'])),
		)
	);
?>