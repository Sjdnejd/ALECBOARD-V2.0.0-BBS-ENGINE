 <!-- End Right Column -->
 </div>
<div class="float_null" style="clear:both;"></div>
 <!-- Begin Footer -->
	<div id="footer">Copyleft ⓒ 2003 ALECBOARDV2. All rights not reserved.</div>
 <!-- End Footer -->
 
</div>
<!-- End Wrapper -->
</body>