<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<? include("../include/header_win.php"); ?>
<body>
<?
	echo $msg;	
?>
</body>
<? include("../include/footer_win.php"); ?>
<?
exit;
?>