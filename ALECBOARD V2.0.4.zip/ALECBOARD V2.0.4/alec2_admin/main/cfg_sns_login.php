<?
/* =====================================================
	 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com
	
  최종수정일 : 
 ===================================================== */
	$_MENU='0104';
	include_once("../include/header_code.php");
	
	// SNS로그인 연동 설정
	if($_SERVER['REQUEST_METHOD']=="POST" && $mode == "update"){
		if(!rg_verify_token($_POST['token'])) {
			rg_href('','정상적인 접근이 아닙니다.\n\n새로고침후 다시 시도해보세요.','back');
		}

		$rs->clear();
		$rs->set_table($_table['setup']);
		$rs->add_field("ss_content",serialize($sns));
		$rs->add_where("ss_name='sns_api_info'");
		$rs->update();
		
		$data = rg_get_setup('site_info');
		$data['sl_facebook']=$site_info['sl_facebook'];
		$data['sl_twitter']=$site_info['sl_twitter'];
		$data['sl_google']=$site_info['sl_google'];
		$data['sl_naver']=$site_info['sl_naver'];
		$rs->clear();
		$rs->set_table($_table['setup']);
		$rs->add_field("ss_content",serialize($data));
		$rs->add_where("ss_name='site_info'");
		$rs->update();
		rg_href('?');
	}

	// 사이트 설정
	$rs->clear();
	$rs->set_table($_table['setup']);
	$rs->add_field("ss_content");
	$rs->add_where("ss_name='sns_api_info'");
	$rs->select();
	if($rs->num_rows()<1) {
		$rs->clear_field();
		$rs->add_field("ss_name","sns_api_info");
		$rs->insert();

		$rs->clear_field();
		$rs->add_field("ss_content");
		$rs->select();
	}
	$rs->fetch('tmp');
	$sns = unserialize($tmp);
	
	
	// 사이트 설정
	$site_info = rg_get_setup('site_info');
	$token=rg_get_token();
?>
<? include("../include/header_win.php"); ?>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?></td>
  </tr>
</table>
<br>
<form name=form1 method=post action="?" onSubmit="return validate(this)">
  <input type=hidden name=mode value="update">
	<input type="hidden" name="token" value="<?=$token?>">
  <table width="600" border="1" cellspacing="0" cellpadding="3" class="site_content" style="table-layout:fixed">
<col width="120">
<col width="">
<tr>
		<td colspan="2">페이스북(Callback URL:http://홈페이지주소/설치경로/alec2_member/oauth-api/login_with_facebook.php)</td>
</tr>
<tr>
		<th>연동 여부</th>
		<td>
				<label><input type="radio" name="site_info[sl_facebook]" value="Y" <?=(($site_info['sl_facebook']=='Y')?'checked':'')?>> 예</label> &nbsp;
				<label><input type="radio" name="site_info[sl_facebook]" value="N" <?=(($site_info['sl_facebook']!='Y')?'checked':'')?>> 아니요</label> 
		</td>
</tr>
<tr>
		<th>API 키</th>
		<td><input type="text" name="sns[facebook_key]" size="50" style="width:100%" value="<?=$sns[facebook_key]?>" /></td>
</tr>
<tr>
		<th>시크릿코드</th>
		<td><input type="text" name="sns[facebook_secret]" size="50" style="width:100%" value="<?=$sns[facebook_secret]?>" /></td>
</tr>
<tr>
		<td colspan="2">트위터(Callback URL:http://홈페이지주소/설치경로/alec2_member/oauth-api/login_with_twitter.php)</td>
</tr>
<tr>
		<th>연동 여부</th>
		<td>
				<label><input type="radio" name="site_info[sl_twitter]" value="Y" <?=(($site_info['sl_twitter']=='Y')?'checked':'')?>> 예</label> &nbsp;
				<label><input type="radio" name="site_info[sl_twitter]" value="N" <?=(($site_info['sl_twitter']!='Y')?'checked':'')?>> 아니요</label> 
		</td>
</tr>
<tr>
		<th>Consumer key</th>
		<td><input type="text" name="sns[twitter_key]" size="50" style="width:100%" value="<?=$sns[twitter_key]?>" /></td>
</tr>
<tr>
		<th>Consumer secret</th>
		<td><input type="text" name="sns[twitter_secret]" size="50" style="width:100%" value="<?=$sns[twitter_secret]?>" /></td>
</tr>
<tr>
		<td colspan="2">구글(Callback URL:http://홈페이지주소/설치경로/alec2_member/oauth-api/login_with_google.php)</td>
</tr>
<tr>
		<th>연동 여부</th>
		<td>
				<label><input type="radio" name="site_info[sl_google]" value="Y" <?=(($site_info['sl_google']=='Y')?'checked':'')?>> 예</label> &nbsp;
				<label><input type="radio" name="site_info[sl_google]" value="N" <?=(($site_info['sl_google']!='Y')?'checked':'')?>> 아니요</label> 
		</td>
</tr>
<tr>
		<th>Consumer key</th>
		<td><input type="text" name="sns[google_key]" size="50" style="width:100%" value="<?=$sns[google_key]?>" /></td>
</tr>
<tr>
		<th>Consumer secret</th>
		<td><input type="text" name="sns[google_secret]" size="50" style="width:100%" value="<?=$sns[google_secret]?>" /></td>
</tr>
<tr>
		<td colspan="2">네이버(Callback URL:http://홈페이지주소/설치경로/alec2_member/oauth-api/login_with_naver.php)</td>
</tr>
<tr>
		<th>연동 여부</th>
		<td>
				<label><input type="radio" name="site_info[sl_naver]" value="Y" <?=(($site_info['sl_naver']=='Y')?'checked':'')?>> 예</label> &nbsp;
				<label><input type="radio" name="site_info[sl_naver]" value="N" <?=(($site_info['sl_naver']!='Y')?'checked':'')?>> 아니요</label> 
		</td>
</tr>
<tr>
		<th>ClientID</th>
		<td><input type="text" name="sns[naver_key]" size="50" style="width:100%" value="<?=$sns[naver_key]?>" /></td>
</tr>
<tr>
		<th>ClientSecret</th>
		<td><input type="text" name="sns[naver_secret]" size="50" style="width:100%" value="<?=$sns[naver_secret]?>" /></td>
</tr>
</table>
  <br>
  <table width="500" align="center">
    <tr>
      <td align=center><input type="submit" value=" 저  장 " class="btn btn-outline-primary">
      </td>
    </tr>
  </table>
</form>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>