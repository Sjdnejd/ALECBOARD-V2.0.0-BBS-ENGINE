<?
/* =====================================================
	 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com
	
  최종수정일 : 
 ===================================================== */
	$_MENU='0103';
	include_once("../include/header_code.php");
	
	if($_SERVER['REQUEST_METHOD']=="POST" && $mode == "update"){
		if(!rg_verify_token($_POST['token'])) {
			rg_href('','정상적인 접근이 아닙니다.\n\n새로고침후 다시 시도해보세요.','back');
		}

		unset($tmp);
		foreach($level_info['level'] as $k => $v)
			if($v!='')
				$tmp[$v]=$level_info['name'][$k];
		ksort($tmp);
		$rs->clear();
		$rs->set_table($_table['setup']);
		$rs->add_field("ss_content",serialize($tmp));
		$rs->add_where("ss_name='level_info'");
		$rs->update();
		
		$rs->commit();
		
		rg_href('?');
	}

	// 레벨 정보
	$rs->clear();
	$rs->set_table($_table['setup']);
	$rs->add_field("ss_content");
	$rs->add_where("ss_name='level_info'");
	$rs->select();
	if($rs->num_rows()<1) {
		$rs->clear_field();
		$rs->add_field("ss_name","level_info");
		$rs->insert();

		$rs->clear_field();
		$rs->add_field("ss_content");
		$rs->select();
	}
	$rs->fetch('tmp');
	$level_info = unserialize($tmp);

	$token=rg_get_token();
?>
<? include("../include/header_win.php"); ?>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?></td>
  </tr>
</table>
<br>
<form name=form1 method=post action="?" onSubmit="return validate(this)">
  <input type=hidden name=mode value="update">
	<input type="hidden" name="token" value="<?=$token?>">
  <table border="0" cellspacing="0" cellpadding="0" width="500" align="center">
    <tr>
      <td class="a_sub_title">레벨별 이름설정</td>
    </tr>
  </table>
  <table id="tb1" border="0" cellpadding="0" cellspacing="0" width="500" class="site_content">
    <tr>
      <th align="right" width="120">레벨&nbsp;</th>
      <th>&nbsp;레벨이름 (0 : 비회원, <?=$_const['group_admin_level']?> : 그룹관리자, <?=$_const['admin_level']?> : 최고관리자)</th>
    </tr>
<?
	$i=0;
	if(is_array($level_info)) 
	foreach($level_info as $k => $v) {
		$i++;
?>
    <tr>
      <td align="right"><input type="text" class="input" name=level_info[level][] value="<?=$k?>" size="3" dir="rtl">&nbsp;</td>
      <td>&nbsp;<input type="text" class="input" name=level_info[name][] value="<?=$v?>" size=50> 
      <? if($k!=$_const['group_admin_level'] && $k!=$_const['admin_level']) { ?>
      <input type="button" value="삭제" class="btn btn-outline-primary" onClick="level_delete(event)">
      <? } ?>
      </td>
    </tr>
<?
	}
?>
	</table>
  <table border="0" cellpadding="0" cellspacing="0" width="500" class="site_content">
    <tr>
      <td align="center"><input type="button" value=" 추 가 " class="btn btn-outline-primary" onClick="level_insert()"></td>
    </tr>
  </table>
<script>
var row_count=<?=$i?>;

function level_delete(e)
{
	var obj = find_parent_tag(e,'td');
	if(obj.parentNode)
		var idx = obj.parentNode.rowIndex;
	else
		var idx = obj.parentElement.rowIndex;
	var tRow = tb1.deleteRow(idx);
}

function level_insert() {
	if(row_count<100) {
		row_count++;
		if(document.getElementById){
			var Tbl = document.getElementById('tb1');
		} else {
			var Tbl = document.all['tb1'];
		}
		var tRow = Tbl.insertRow(-1);  	
		var tmp=tRow.insertCell(0);
		tmp.innerHTML ='<input type="text" class="input" name=level_info[level][] value="" size="3" dir="rtl">&nbsp;';
		tmp.align='right';
		tmp=tRow.insertCell(1);
		tmp.innerHTML ='&nbsp;<input type="text" class="input" name=level_info[name][] value="" size=50> <input type="button" value="삭제" class="btn btn-outline-primary" onClick="level_delete(event)">';
	}
}
</script>
  <br>
  <table width="500" align="center">
    <tr>
      <td align=center><input type="submit" value=" 저  장 " class="btn btn-outline-primary">
      </td>
    </tr>
  </table>
</form>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>