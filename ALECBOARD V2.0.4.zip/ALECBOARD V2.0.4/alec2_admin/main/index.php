<?
/* =====================================================
   : ALECBOARDV2 V4
  화일명 : 관리자 초기화면
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com
	
	게시판 현황,회원가입 현황등 표시할 예정

  최종수정일 : 
 ===================================================== */
	include_once("../include/header_code.php");
	
	$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
	$yesterday = mktime(0,0,0,date('m'),date('d')-1,date('Y'));
	
	$today_data = rg_db_data_one($_table['prefix'].'counter_day',"reg_date=$today");
	$yesterday_data = rg_db_data_one($_table['prefix'].'counter_day',"reg_date=$yesterday");
	$total_data = rg_db_data_one($_table['prefix'].'counter_day',"","","sum(hits) as hits,sum(unique_hits) as unique_hits");
?>
<? include("../include/header_win.php"); ?>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
	<tr>
		<td>관리자</td>
	</tr>
</table>
<br>
<div style="margin:0 auto;width:200px">
접속통계
<table width="200" border="1" class="site_content">
		<tr>
				<th scope="col">&nbsp;</th>
				<th scope="col">방문자</th>
				<th scope="col">히트수</th>
		</tr>
		<tr>
				<td align="center">어제</td>
				<td align="right"><?=number_format($yesterday_data['unique_hits'])?></td>
				<td align="right"><?=number_format($yesterday_data['hits'])?></td>
		</tr>
		<tr>
				<td align="center">오늘</td>
				<td align="right"><?=number_format($today_data['unique_hits'])?></td>
				<td align="right"><?=number_format($today_data['hits'])?></td>
		</tr>
		<tr>
				<td align="center">전체</td>
				<td align="right"><?=number_format($total_data['unique_hits'])?></td>
				<td align="right"><?=number_format($total_data['hits'])?></td>
		</tr>
</table>
</div>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>