<?

	$_MENU='0505';
	include_once("../include/header_code.php");

	if($act) {
		// ALECBOARDV2 테이블 변환

		switch(DB_TYPE) { // db종류
			case 'cubrid' :
				include_once('../schema/cubrid_schema.inc.php');
			break;
			case 'oracle' :
				include_once('../schema/oracle_schema.inc.php');
			break;
			case 'mysql' :
				include_once('../schema/mysql_schema.inc.php');
			break;
		}

		$table_array=array('popup','comm_code');
		foreach($table_array as $k => $v)	{					
			if(!$dbcon->list_tables($_table[$v])) {
				$dbcon->query("CREATE TABLE {$_table[$v]} \n {$db_schema[$v]}");
//			$dbcon->query("CREATE TABLE {$_table[$v]} {$db_schema[$v]} DEFAULT CHARSET=euckr");
			} else {
				rg_href("update.php","이미 테이블이 있습니다.");
			}
		}

		if(DB_TYPE=='cubrid') {
			// 인덱스, 시리얼, 트리거 생성
			foreach($table_array as $v)	{
				if(is_array($db_schema_index[$v])) {
					foreach($db_schema_index[$v] as $v1) {
						$dbcon->query("CREATE INDEX {$v1}_idx on {$_table[$v]} ({$v1})");
					}
				}
				
				if($db_schema_serial_field[$v] != '') {
					$serial_name="{$_table[$v]}__{$db_schema_serial_field[$v]}";
					$dbcon->query("CREATE SERIAL $serial_name START WITH 10");
				}
			}
		}

		if(DB_TYPE=='oracle') {
			// 인덱스, 시퀀스 생성
			$i=0;
			foreach($table_array as $v)	{
				if(is_array($db_schema_index[$v])) {
					foreach($db_schema_index[$v] as $v1) {
						$i++;
						$dbcon->query("CREATE INDEX i{$i}_{$v1}_idx on {$_table[$v]} ({$v1})");
					}
				}
				
				if($db_schema_serial_field[$v] != '') {
					$serial_name="{$_table[$v]}__{$db_schema_serial_field[$v]}";
					$dbcon->query("CREATE SEQUENCE $serial_name START WITH 10");
				}
			}
		}
		
		if(!is_dir($_path['popup']))
			mkdir($_path['popup'],0707);

		$dbcon->query(
			"INSERT INTO {$_table['comm_code']}
					(`cd_num`, `cd_type1`, `cd_type2`, `cd_code`, `cd_name`, `cd_ord`, `cd_data1`, `cd_data2`)
				VALUES
					(1, 'comm', 'yns', 'Y', '예', 1, '사용', '')");
		$dbcon->query(
			"INSERT INTO {$_table['comm_code']}
					(`cd_num`, `cd_type1`, `cd_type2`, `cd_code`, `cd_name`, `cd_ord`, `cd_data1`, `cd_data2`)
				VALUES
					(2, 'comm', 'yns', 'N', '아니요', 2, '사용안함', '')");
		$dbcon->query(
			"INSERT INTO {$_table['comm_code']}
					(`cd_num`, `cd_type1`, `cd_type2`, `cd_code`, `cd_name`, `cd_ord`, `cd_data1`, `cd_data2`)
				VALUES
					(3, 'popup', 'win_type', '01', '일반팝업', 0, '', '')");
		$dbcon->query(
			"INSERT INTO {$_table['comm_code']}
					(`cd_num`, `cd_type1`, `cd_type2`, `cd_code`, `cd_name`, `cd_ord`, `cd_data1`, `cd_data2`)
				VALUES
					(4, 'popup', 'win_type', '02', '레이어팝업', 0, '', '')");
		$dbcon->query(
			"INSERT INTO {$_table['comm_code']}
					(`cd_num`, `cd_type1`, `cd_type2`, `cd_code`, `cd_name`, `cd_ord`, `cd_data1`, `cd_data2`)
				VALUES
					(5, 'popup', 'cont_type', '01', '이미지업로드', 0, '', '')");
		$dbcon->query(
			"INSERT INTO {$_table['comm_code']}
					(`cd_num`, `cd_type1`, `cd_type2`, `cd_code`, `cd_name`, `cd_ord`, `cd_data1`, `cd_data2`)
				VALUES
					(6, 'popup', 'cont_type', '02', 'html링크', 0, '', '')");
		$dbcon->query(
			"INSERT INTO {$_table['comm_code']}
					(`cd_num`, `cd_type1`, `cd_type2`, `cd_code`, `cd_name`, `cd_ord`, `cd_data1`, `cd_data2`)
				VALUES
					(7, 'popup', 'cont_type', '03', 'html직접입력', 0, '', '')");
		rg_href("update.php","database 변환이 완료되었습니다.");
	}

?>
<? include("../include/header_win.php"); ?>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?> > 4.2.0 => 4.2.1</td>
  </tr>
</table>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="center"><br>
    <form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="if(!confirm('확실합니까?')) return false;">
<input name="act" type="hidden" value="ok">
          <table border="0" cellspacing="0" cellpadding="0" width="70%" class="site_content">
          <tr> 
            <td height="30" align="center" valign="middle" bgcolor="f7f7f7">ALECBOARDV2 database를 4.2.0 에서 4.2.1 로 변환합니다.<br>
							에러 및 데이터 유실에대한 책임을 지지 않사오니 미리 백업해주시기 바랍니다.<br>
<br>
업데이트 내용<br>
<br>
1. 팝업기능 추가를 위한 테이블 생성</td>
          </tr>
        </table>
        <br>
        <input type="submit" value=" 업데이트시작 " class="btn btn-outline-primary">
        <input type="button" value=" 취 소 " class="btn btn-outline-primary" onClick="history.back()">
      </form></td>
  </tr>
</table>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>