<?

	$_MENU='0502';
	include_once("../include/header_code.php");

	$arr_hour=array();
	for($i=0;$i<24;$i++) {
		$arr_hour[$i]=$i;
	}
	
	$arr_minute=array();
	$arr_second=array();
	for($i=0;$i<60;$i++) {
		$arr_minute[$i]=$i;
		$arr_second[$i]=$i;
	}

	if($mode=='modify' || $mode=='delete' || $mode=='undelete') {
		$rs->clear();
		$rs->set_table($_table['popup']);
		$rs->add_where("pp_num=$num");
		$rs->select();
		if($rs->num_rows()!=1) { // 정보가 올바르지 않다면
			rg_href('','정보를 찾을수 없습니다.','back');
		}
		$data=$rs->fetch();
		$data['pp_images']=unserialize($data['pp_images']);
		
		$data['start_date']=date('Y-m-d',$data['pp_start_time']);
		$data['start_hour']=date('H',$data['pp_start_time']);
		$data['start_minute']=date('i',$data['pp_start_time']);
		$data['start_second']=date('s',$data['pp_start_time']);
		$data['end_date']=date('Y-m-d',$data['pp_end_time']);
		$data['end_hour']=date('H',$data['pp_end_time']);
		$data['end_minute']=date('i',$data['pp_end_time']);
		$data['end_second']=date('s',$data['pp_end_time']);
	} else {
		$mode='insert';
	}
	
	if($mode=='delete') {	// 삭제
		if(!rg_verify_token($_REQUEST['token'])) {
			rg_href('','정상적인 접근이 아닙니다.\n\n새로고침후 다시 시도해보세요.','back');
		}
		
		rg_upload_file_delete($_path['popup'],$data['pp_images']); // 파일삭제

		$rs->clear();
		$rs->set_table($_table['popup']);
		$rs->add_where("pp_num=$num");
		$rs->delete();
		rg_href("popup_list.php?$_get_param[3]");
	}

	if($_SERVER['REQUEST_METHOD']=='POST') {
		if(!rg_verify_token($_POST['token'])) {
			rg_href('','정상적인 접근이 아닙니다.\n\n새로고침후 다시 시도해보세요.','back');
		}

		$pp_start_time=strtotime("$start_date $start_hour:$start_minute:$start_second");
		$pp_end_time=strtotime("$end_date $end_hour:$end_minute:$end_second");
		$pp_start_use_yn=$pp_start_use_yn!='Y'?'N':'Y';
		$pp_end_use_yn=$pp_end_use_yn!='Y'?'N':'Y';
		$pp_scrollbars_yn=$pp_scrollbars_yn!='Y'?'N':'Y';
		
		$rs->clear();
		$rs->set_table($_table['popup']);

		$rs->add_field("pp_win_type_cd","$pp_win_type_cd"); // 팝업형식
		$rs->add_field("pp_title","$pp_title"); // 팝업타이틀
		$rs->add_field("pp_use_yn","$pp_use_yn"); // 사용여부
		$rs->add_field("pp_start_time","$pp_start_time"); // 시작시간
		$rs->add_field("pp_start_use_yn","$pp_start_use_yn"); // 시작설정여부
		$rs->add_field("pp_end_time","$pp_end_time"); // 종료시간
		$rs->add_field("pp_end_use_yn","$pp_end_use_yn"); // 종료설정여부
		$rs->add_field("pp_width","$pp_width"); // 넓이
		$rs->add_field("pp_height","$pp_height"); // 높이
		$rs->add_field("pp_scrollbars_yn","$pp_scrollbars_yn"); // 스크롤바여부
		$rs->add_field("pp_left","$pp_left"); // 팝업 왼쪽위치
		$rs->add_field("pp_top","$pp_top"); // 팝업 상단위치
		$rs->add_field("pp_cont_type_cd","$pp_cont_type_cd"); // 팝업내용구분
		$rs->add_field("pp_link_url","$pp_link_url"); // 링크
		$rs->add_field("pp_content","$pp_content"); // 내용
		if($mode=='insert') {
			$rs->add_field("reg_date",time()); // 등록일
			$rs->add_field("reg_mb_id","$_mb[mb_id]"); // 등록자아이디
			$rs->insert();
			$num=$rs->get_insert_id();		
		} else if($mode=='modify') {
			$rs->add_where("pp_num=$num");
			$rs->update();
		}
		
		// 파일 업로드
		$pp_images=rg_file_upload($_path['popup'],"pp_images",$num,$data['pp_images'],$pp_images_del);
		$pp_images=serialize($pp_images);		
		
		$rs->clear();
		$rs->set_table($_table['popup']);
		$rs->add_field("pp_images","$pp_images"); // 첨부파일
		$rs->add_where("pp_num=$num");
		$rs->update();
		
		$rs->commit();
		rg_href("popup_list.php?$_get_param[3]");

	}
	
 if($mode=='insert') {
		$data['pp_use_yn']='Y';
		$data['pp_win_type_cd']='01';
		$data['pp_width']='300';
		$data['pp_height']='400';
		$data['pp_scrollbars_yn']='Y';
		$data['pp_left']='0';
		$data['pp_top']='0';
		$data['pp_cont_type_cd']='03';
		
		$data['start_date']=date('Y-m-d');
		$data['start_hour']=date('H');
		$data['start_minute']=date('i');
		$data['start_second']=date('s');
		$data['end_date']=date('Y-m-d',time()+60*60*24*7);
		$data['end_hour']=date('H');
		$data['end_minute']=date('i');
		$data['end_second']=date('s');
	}
	
	$c_pp_scrollbars_yn[$data['pp_scrollbars_yn']]='checked';
	$c_pp_start_use_yn[$data['pp_start_use_yn']]='checked';
	$c_pp_end_use_yn[$data['pp_end_use_yn']]='checked';
	$token=rg_get_token();
?>
<? include("../include/header_win.php"); ?>
<script>
var editorConfig_upload='Y';
</script>
<script src="<?=$_path['site']?>ckeditor/ckeditor.js"></script>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?> > 등록/수정</td>
  </tr>
</table>
<br>
<form name="form1" method="post" action="?<?=$_get_param[3]?>" onSubmit="return validate(this);" enctype="multipart/form-data">
<input type="hidden" name="mode" value="<?=$mode?>" />
<input type="hidden" name="num" value="<?=$num?>" />
<input type="hidden" name="token" value="<?=$token?>">
<table border="0" cellpadding="0" cellspacing="0" width="700" align="center" class="site_content">
	<tr>
    <th width="120">구분</th>
	  <td><?=rg_html_radio('pp_win_type_cd',rg_comm_code('popup','win_type'),$data['pp_win_type_cd'],'','','','&nbsp;&nbsp;')?></td>
	  </tr>
	<tr>
    <th>사용여부</th>
	  <td><?=rg_html_radio('pp_use_yn',rg_comm_code('comm','yns'),$data['pp_use_yn'],'','','','&nbsp;&nbsp;')?></td>
	  </tr>
	<tr>
	  <th>자동팝업<br>
	    등록예약</span></th>
	  <td>시작 <input type="text" name="start_date" value="<?=$data['start_date']?>" size="10"  onfocus="new CalendarFrame.Calendar(this)" class="input">

      <select name="start_hour">
        <?=rg_html_option($arr_hour,"$data[start_hour]")?>
      </select>
      시 
      <select name="start_minute">
        <?=rg_html_option($arr_minute,"$data[start_minute]")?>
      </select>
      분 
      <select name="start_second">
        <?=rg_html_option($arr_second,"$data[start_second]")?>
      </select>
      초 부터 
      <input type="checkbox" name="pp_start_use_yn" id="pp_start_use_yn" <?=$c_pp_start_use_yn['Y']?> value="Y">
      시작시간설정     <br>
	    마감 <input type="text" name="end_date" value="<?=$data['end_date']?>" size="10"  onfocus="new CalendarFrame.Calendar(this)" class="input">
	    <select name="end_hour">
        <?=rg_html_option($arr_hour,"$data[end_hour]")?>
      </select>
시
<select name="end_minute">
  <?=rg_html_option($arr_minute,"$data[end_minute]")?>
</select>
분
<select name="end_second">
  <?=rg_html_option($arr_second,"$data[end_second]")?>
</select>
초 까지 
      <input type="checkbox" name="pp_end_use_yn" id="pp_end_use_yn" <?=$c_pp_end_use_yn['Y']?> value="Y">
마감시간설정 </td>
	  </tr>
	<tr>
    <th> 팝업타이틀</th>
	  <td><input name="pp_title" type="text" class="input" value="<?=$data['pp_title']?>" size="60"></td>
	  </tr>
	<tr>
    <th> 팝업사이즈</th>
	  <td>가로: 
	    <input name="pp_width" type="text" class="input" value="<?=$data['pp_width']?>" size="3">
	    px, 세로: 
	    <input name="pp_height" type="text" class="input" value="<?=$data['pp_height']?>" size="3">
px, 스크롤:
<input type="checkbox" name="pp_scrollbars_yn" id="pp_scrollbars_yn" <?=$c_pp_scrollbars_yn['Y']?> value="Y"></td>
	</tr>
	<tr>
    <th> 팝업위치</th>
	  <td>왼쪽:
      <input name="pp_left" type="text" class="input" value="<?=$data['pp_left']?>" size="3">
px, 상단: 
	    <input name="pp_top" type="text" class="input" value="<?=$data['pp_top']?>" size="3">
px,</td>
	  </tr>
	<tr>
    <th> 팝업방식</th>
	  <td><?=rg_html_radio('pp_cont_type_cd',rg_comm_code('popup','cont_type'),$data['pp_cont_type_cd'],'','','','&nbsp;&nbsp;')?></td>
	  </tr>
	<tr>
    <th>이미지업로드</th>
	  <td><input name="pp_images[popup]" type="file" class="input" size="50">
        <? if($data['pp_images']['popup']['name']!='') { ?>
        <br>
        <?=$data['pp_images']['popup']['name']?>
        <input type="checkbox" name="pp_images_del[popup]" value="1" />
	    삭제
	    <? } ?></td>
	  </tr>
	<tr>
    <th> HTML링크</th>
	  <td><input name="pp_link_url" type="text" class="input" value="<?=$data['pp_link_url']?>" size="60"></td>
	  </tr>
	<tr>
    <th> HTML직접입력</th>
	  <td><textarea name="pp_content" class="ckeditor" cols="60" rows="10"><?=$data['pp_content']?></textarea></td>
	  </tr>
</table>
<table width="700" border="0" align="center">
	<tr>
	  <td align="center">
<input type="submit" value=" <?=(($mode=="modify")?'수 정':'등 록')?> " class="btn btn-outline-primary">	
<input type="button" value=" 취  소 " onClick="location.href='<?="popup_list.php?$_get_param[3]"?>'" class="btn btn-outline-primary"></td>
	  </tr>
</table>
</form>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>
<div id="CalendarLayer" style="display:none; width:172px; height:180px">
<iframe name="CalendarFrame" src="<?=$_url['js']?>/lib.calendar.js.htm"
width="172" height="180" border="0" frameborder="0" scrolling="no"></iframe></div>