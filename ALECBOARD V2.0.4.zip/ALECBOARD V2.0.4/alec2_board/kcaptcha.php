<?
/* =====================================================
   : ALECBOARDV2 V4
  화일명 : kcaptcha.php 자동등록 방지
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 :
 ===================================================== */
	include_once("../alec2_include/lib.php");
	include_once('../alec2_include/kcaptcha/kcaptcha.php');
	$captcha = new KCAPTCHA();
	
	if($_REQUEST[session_name()]){
		$_SESSION['captcha_keystring'] = $captcha->getKeyString();
	}
?>