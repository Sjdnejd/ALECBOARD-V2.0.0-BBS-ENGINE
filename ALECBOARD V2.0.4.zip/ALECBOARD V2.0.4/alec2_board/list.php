<?

	include_once("../alec2_include/lib.php");
	include_once($_path['inc']."lib_bbs.php");
	
	$mode='list';
	
	if(file_exists($skin_path.'setup.php')) include($skin_path.'setup.php');
	if(!$_bbs_auth['list']) {
		$_msg_type='list_no_auth';
		include("msg.php");
		exit;
	}	
	include('list_main_process.php');
?>