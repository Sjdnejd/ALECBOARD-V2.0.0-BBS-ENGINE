<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?

	if(isset($_REQUEST['skin_path'])) exit;
	
	$rs_comment = new $rs_class($dbcon);
	$rs_comment->clear();
	$rs_comment->set_table($_table['bbs_comment']);
	$rs_comment->add_where("bd_num=$bd_num");
	$rs_comment->add_order("bc_num");
?>