<?
	$_GET['chg_site']='mobile';
	include_once("../include/header_code.php");
?>
<? include_once("_header.php"); ?>
<?=rg_lastest_style('default_mobile')// 최신글 스킨에 사용하는 스타일을 미리 읽어온다 ?>
<?=rg_lastest_style('webzine_mobile') ?>
    <!DOCTYPE html>
    <html lang="ko">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <title>bxSlider</title>
        <link href="jquery.bxslider/jquery.bxslider.css" rel="stylesheet" />
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
        <script src="jquery.bxslider/jquery.bxslider.js"></script>
        <style>
            h1 {color:white;}
        </style>
        <script type="text/javascript">
            //<![CDATA[
            $(document).ready(function(){
                //$('.bxslider').bxSlider();

                $('.bxslider').bxSlider({
                    auto: true,
                    speed: 500,
                    pause: 4000,
                    mode:'fade',
                    autoControls: true,
                    pager: true,
                });
            });
            //]]>
        </script>
    </head>
    <body>
    <!--
    <div style="max-width:1000px;">
    <ul class="bxslider">
        <li><img src="images/img01.jpg" title="캡션이 보여집니다." /></li>
        <li><img src="images/img02.jpg" title="캡션이 보여집니다." /></li>
        <li><img src="images/img03.jpg" title="캡션이 보여집니다." /></li>
        <li><img src="images/img04.jpg" title="캡션이 보여집니다." /></li>
    </ul>
    </div>
    -->

    <div style="max-width:1000px;">
        <ul class="bxslider">
            <li>
                <div style="position:absolute;"></div>
                <img src="images/img01.jpg" />
            </li>
            <li>
                <div style="position:absolute;"></div>
                <img src="images/img02.jpg" />
            </li>
            <li>
                <div style="position:absolute;"></div>
                <img src="images/img03.jpg" />
            </li>
            <li>
                <div style="position:absolute;"></div>
                <img src="images/img04.jpg" />
            </li>
        </ul>
    </div>

    </body>
    </html>
<?
	$rs_bbs = new $rs_class($dbcon);
	$rs_group = new $rs_class($dbcon);
	$rs_group->clear();
	$rs_group->set_table($_table['group']);
	$rs_group->add_where("gr_state=1");
	$rs_group->add_order("gr_num");
	while($g_info=$rs_group->fetch()) {
		$rs_bbs->clear();
		$rs_bbs->set_table($_table['bbs_cfg']);
		$rs_bbs->add_where("gr_num={$g_info['gr_num']}");
		$rs_bbs->add_order("bbs_num");
		$i=0;
?>
<i class="fa fa-folder-o" style="margin-left:10px"></i> <?=$g_info['gr_name']?>
<?
		$gallery=array();
		while($bbs_info=$rs_bbs->fetch()) {
			if($bbs_info['bbs_code']=='gallery') { // bbs_code 가 gallery 인 게시판은 따로 출력
				$gallery[]=$bbs_info;
				continue;
			}
			$i++;
?>
	<?=rg_lastest($bbs_info['bbs_code'],'default_mobile',5,45)?>
<?
		}
		foreach($gallery as $bbs_info) {
?>
	<?=rg_lastest($bbs_info['bbs_code'],'webzine_mobile',"5",45,'','','','75x75')?>
<?
		}
	}
?>
<? include_once("_footer.php"); ?>