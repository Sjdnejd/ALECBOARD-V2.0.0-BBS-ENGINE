<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<div class="login_box">
		<div class="title">로그인</div>
		<form name="login_form" method="post" action="?" onSubmit="return validate(this)" enctype='multipart/form-data'>
		<input type="hidden" name="form_mode" value="member_login_ok">
		<input type="hidden" name="from" value="<?=$from?>">
		<input type="hidden" name="ret_url" value="<?=$ret_url?>">
		<table width="300" align="center" border="0" cellpadding="0" cellspacing="6" style="margin:0 auto">
			<tr>
				<td width="60" align="right"><strong>아이디</strong>&nbsp;</td>
				<td width="140"><input type="text" class="input" name="mb_id" size="20" maxlength="12" hname="아이디" required tabindex="101"></td>
				<td rowspan="2"><input name="submit" type="submit" class="btn btn-outline-primary" value=" 로그인 " style="height:50;width:60" tabindex="103"></td>
			</tr>
			<tr>
				<td align="right"><strong>암호</strong></td>
				<td><input name="mb_pass" type="password" class="input" size="20" required hname="암호" tabindex="102"></td>
				</tr>
		</table>
		</form>
		<div style="margin:10px 0 5px 0;text-align:center">
			<input type="button" class="btn btn-outline-primary" value=" 회원가입 " onClick="location.href='<?=$_path['member']?>join.php'">
			<input type="button" class="btn btn-outline-primary" value=" 암호찾기 " onClick="location.href='<?=$_path['member']?>find_pass.php'">
		</div>
<? if($_site_info['sl_naver']=='Y' || $_site_info['sl_facebook']=='Y' || $_site_info['sl_twitter']=='Y' || $_site_info['sl_google']=='Y') { ?>
		<div style="margin:10px 0 5px 0;text-align:center">
<? if($_site_info['sl_naver']=='Y') { ?>
	<button type="button" class="login_naver" onClick="login_naver()"><div class="sns_login_txt">네이버 아이디로 로그인</div></button>
<? } ?>
<? if($_site_info['sl_facebook']=='Y') { ?>
	<button type="button" class="login_facebook" onClick="login_facebook()"><div class="sns_login_txt">페이스북 아이디로 로그인</div></button>
<? } ?>
<? if($_site_info['sl_twitter']=='Y') { ?>
	<button type="button" class="login_twitter" onClick="login_twitter()"><div class="sns_login_txt">트위터 아이디로 로그인</div></button>
<? } ?>
<? if($_site_info['sl_google']=='Y') { ?>
	<button type="button" class="login_google" onClick="login_google()"><div class="sns_login_txt">구글 아이디로 로그인</div></button>
<? } ?>
	</div>
<? } ?>

</div>
<script language='Javascript'>
	if(typeof(document.login_form.mb_id) != "undefined")
		document.login_form.mb_id.focus();
</script>