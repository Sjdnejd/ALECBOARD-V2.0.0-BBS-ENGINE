<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
/* =====================================================
  : ALECBOARDV2 V4 게시판스킨

파일설명 : 글보기

변수설명

$prev_data : 이전글정보
$next_data : 다음글정보
$vcfg['btn_modify'] : 수정버튼표시여부
$vcfg['btn_del'] : 삭제버튼표시여부
$vcfg['btn_reply'] : 답변버튼표시여부
$vcfg['btn_vote_yes'] : 추천버튼표시여부
$vcfg['btn_vote_no'] : 반대버튼표시여부
$vcfg['btn_list'] : 글목록버튼표시여부

$bbs_code : 게시판코드
$bd_num : 글번호
$bd_name : 작성자
$bd_email : 이메일
$mb_id : 작성자아이디
$open_homepage : 글작성시 입력한 홈페이지주소
$open_email : 글작성시 입력한 이메일주소
$open_profile : 회원정보공개여부
$open_memo : 쪽지보내기
$mb_icon : 회원아이콘

$bd_write_date : 글작성일
$bd_home : 글홈페이지
$vcfg['use_category'] : 카테고리사용여부
$cat_name : 카테고리명
$vcfg['btn_vote_yes'] : 찬성/추천 사용여부
$vcfg['btn_vote_no'] : 반대 사용여부
$bd_vote_yes : 찬성/추천 투표수
$bd_vote_no : 반대 투표수
$bd_subject : 글제목
$vcfg['view_image'] : 글내용과 이미지를 함께보여줌
$bd_files : 첨부파일정보(배열)
$bd_content : 글내용
$bd_links : 링크정보 (배열)
$vcfg['use_download'] : 다운로드여부
$vcfg['view_signature'] : 서명표시여부
$mb_signature : 서명(회원인경우)
$vcfg['view_comment'] : 코멘트표시여부
$vcfg['view_list'] : 글목록표시 여부
===================================================== */
?>
<? if($vcfg['view_syntaxhighlight']) { ?>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shCore.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushAppleScript.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushAS3.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushBash.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushColdFusion.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushCpp.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushCSharp.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushCss.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushDelphi.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushDiff.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushErlang.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushGroovy.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushJava.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushJavaFx.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushJScript.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushPerl.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushPhp.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushPlain.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushPowerShell.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushPython.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushRuby.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushSass.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushScala.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushSql.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushVb.js"></script>
<script type="text/javascript" src="<?=$_url['site']?>syntaxhighlighter/scripts/shBrushXml.js"></script>
<link href="<?=$_url['site']?>syntaxhighlighter/styles/shCore.css" rel="stylesheet" type="text/css" />
<link href="<?=$_url['site']?>syntaxhighlighter/styles/shThemeDefault.css" rel="stylesheet" type="text/css" />
<? } ?>
<div class="bbs_view">
	<div>
		<ul class="subject">
			<li>
				<? if($vcfg['use_category'] && $cat_name!='') { ?>[<?=$cat_name?>]<? } ?><?=$bd_subject?>
				</li>
		</ul>
		<ul class="view_top">
			<li class="writer"><?=$bd_name_layer?></li>
			<li class="write_date">작성일 : <?=$bd_write_date?></li>
			<? if($vcfg['btn_vote_no']) { ?><li class="vote_no">반대 : <?=$bd_vote_no?></li><? } ?>
			<? if($vcfg['btn_vote_yes']) { ?><li class="vote_yes">찬성 : <?=$bd_vote_yes?></li><? } ?>
		</ul>
		<? if($bd_home) { ?><div class="homepage">Homepage : <?=$bd_home?></div><? } ?>
		<ul class="content">
<?
	if($vcfg['view_image']) {
		foreach($bd_files as $k => $v) {
			if($v['view_url']=='') continue;
?>
<img src="<?=$v['view_url']?>" onclick="view_image_popup(this)" style="cursor:hand;max-width:800px" class="view_image"><br>
<? 	}
	}
?>
		<?=$bd_content?>
		</ul>
		<div style="clear:both"></div>
		<ul class="content_bottom">
<?
	if(is_array($bd_links) && (count($bd_links) > 0)) {
		foreach($bd_links as $k => $v) {
			if($v['url']=='') continue;
			if($v['name']=='') $v['name']=$v['url'];
?>
		<li class="link">링크 : <a href="<?=$v['link_url']?>" target="_blank"><?=$v['name']?>&nbsp;&nbsp;(<?=number_format($v['hits'])?>)</a></li>
<? 	} ?>
<?
	}
?>
<?
	if($vcfg['use_download']) {
		foreach($bd_files as $k => $v) {
			if($v['name']=='') continue;
?>
			<li class="file">첨부파일 : <a href="<?=$v['down_url']?>"><?=$v['name']?>&nbsp;&nbsp;Down:<?=number_format($v['hits'])?></a></li>
<? 	} ?>
<?
	}
?>
		</ul>
<? if($vcfg['view_signature']) { ?>
		<div class="signature"><?=$mb_signature?></div>
<? } ?>
	</div>
</div>
<?
	if($vcfg['view_comment']) // 코멘트 표시여부 
		if(file_exists($skin_path."view_comment.php")) include($skin_path."view_comment.php");
?>

<div style="padding:10px">
	<div style="float:left">
<? if($prev_data) { ?>
		<input type="button" value="이전" onClick="location.href='<?=$url_view_prev?>'" class="btn btn-outline-primary">
<? } ?>
<? if($next_data) { ?>
		<input type="button" value="다음" onClick="location.href='<?=$url_view_next?>'" class="btn btn-outline-primary">
<? } ?>
<? if($vcfg['btn_modify']) { ?>	
		<input type="button" value="수정" onClick="location.href='<?=$url_modify?>'" class="btn btn-outline-primary">
<? } ?>
<? if($vcfg['btn_del']) { ?>	
		<input type="button" value="삭제" onClick="location.href='<?=$url_delete?>'" class="btn btn-outline-primary">
<? } ?>
<? if($vcfg['btn_reply']) { ?>	
		<input type="button" value="답변" onClick="location.href='<?=$url_reply?>'" class="btn btn-outline-primary">
<? } ?>
<? if($vcfg['btn_vote_yes']) { ?>	
		<input type="button" value="추천" onClick="location.href='<?=$url_vote_yes?>'" class="btn btn-outline-primary">
<? } ?>
<? if($vcfg['btn_vote_no']) { ?>	
		<input type="button" value="반대" onClick="location.href='<?=$url_vote_no?>'" class="btn btn-outline-primary">
<? } ?>
	</div>
	<div style="float:right">
<? if($vcfg['btn_list']) { ?>
		<input type="button" value="목록보기" onClick="location.href='<?=$url_list?>'" class="btn btn-outline-primary">
<? } ?>
	</div>
</div>

<? if($vcfg['view_list']) { ?>
<br>
<br>
<div style="width:100%">
<? include('list_main_process.php'); ?>
</div>
<? } ?>
<? if($vcfg['view_syntaxhighlight']) { ?>
<script type="text/javascript">
	SyntaxHighlighter.all();
</script>
<!-- SyntaxHighlighter wrap 적용시 높이 구함 start --> 
<?php /*?> 출처 : https://bitbucket.org/alexg/syntaxhighlighter/issue/182/version-3-making-code-wrap<?php */?>
<script type="text/javascript"> 
function lineWrap(){ 
    var wrap = function () { 
        var elems = document.getElementsByClassName('syntaxhighlighter'); 
        for (var j = 0; j < elems.length; ++j) { 
            var sh = elems[j]; 
            var gLines = sh.getElementsByClassName('gutter')[0].getElementsByClassName('line'); 
            var cLines = sh.getElementsByClassName('code')[0].getElementsByClassName('line'); 
            var stand = 15; 
            for (var i = 0; i < gLines.length; ++i) { 
                var h = $(cLines[i]).height(); 
                if (h != stand) { 
                    console.log(i); 
                    gLines[i].setAttribute('style', 'height:' + h + 'px !important;'); 
                    cLines[i].setAttribute('style', 'height:' + h + 'px !important;'); 
                } 
            } 
        } 
    }; 
    var whenReady = function () { 
        if ($('.syntaxhighlighter').length === 0) { 
            setTimeout(whenReady, 800); 
        } else { 
            wrap(); 
        } 
    }; 
    whenReady(); 
};
$(window).load(function(e) {lineWrap()});
$(window).resize(function(){lineWrap()}); 
</script> 
<!-- SyntaxHighlighter wrap 적용시 높이 구함 end --> 
<? } ?>
<!-- 이미지 크기 조절 -->
<script language="JavaScript" type="text/JavaScript">
$(window).load(function(e) {
	set_img_width_init($(".bbs_view > div > .subject"),-40);
});
</script>