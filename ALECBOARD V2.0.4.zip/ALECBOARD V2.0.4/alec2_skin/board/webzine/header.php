<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<div id="bbs_default">
<div class="gallery_bbs_title"><?=$_group_info['gr_name']?> > <?=$_bbs_info['bbs_name']?></div>