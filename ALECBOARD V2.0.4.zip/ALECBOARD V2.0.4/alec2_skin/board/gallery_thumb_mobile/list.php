<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
/* =====================================================
  : ALECBOARDV2 V4 게시판스킨

파일설명 : 게시판 글 목록

변수설명
$_bbs_info['use_category'] : 카테고리 사용유무
$_category_info : 카테고리정보

$lcfg['view_vote_yes'] : 글목록에 추천을 보여줄지
$lcfg['view_vote_no'] : 글목록에 반대를 조여줄지

$page_info['total_rows'] : 페이징 정보, 총게시물수
$page_info['page'] : 페이징 정보, 현재페이지
$page_info['total_page'] : 페이징 정보, 총페이지수
$_post_param[0] : POST방식의 기본정보, 게시판코드만
$_post_param[3] : POST방식의 기본정보, 전체(게시판코드,키워드,필터,정렬,페이지)

$_bbs_auth['cart'] : 카트사용여부
$_bbs_auth['write'] : 글쓰기권한여부
$_bbs_auth['admin'] : 관리자여부

$bd_delete : 삭제여부
$bd_secret : 비밀글여부
$bd_notice : 공지사항여부
$o_bd_num : 최근본글번호
$bd_num : 현재글번호
$_url['bbs'] : 게시판URL

$ss['cat'] : 검색 카테고리선택
$url_all_list : 검색 action URL(list.php를 의미)
$kw : 검색키워드
===================================================== */
?>
<div class="btn-toolbar" style="margin:0px 5px">
	<div class="btn-group" style="margin-left:0">
<? if($_bbs_info['use_category']) { ?>
		<div class="btn-group">
			<button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
				분류 : <?=$ss['cat']==''?"전체":$_category_name_array[$ss['cat']]?> &nbsp; <span class="caret"></span>
			</button>
			<ul class="dropdown-menu">
				<li <?=$ss['cat']==''?"class='active'":""?>><a href="list.php?<?=$_get_param[0]?>">전체</a></li>
<? foreach($_category_name_array as $key => $val) { ?>
      	<li <?=$ss['cat']==$key?"class='active'":""?>><a href="list.php?<?=$_get_param[0]?>&ss[cat]=<?=$key?>"><?=$val?></a></li>
<? } ?>
			</ul>
		</div>
<? } ?>
<? if($_bbs_auth['write']) { ?>
		<button type="button" class="btn btn-primary" onClick="location.href='write.php?<?=$_get_param[3]?>'"><span class="glyphicon glyphicon-pencil"></span> 글쓰기</button>
<? } ?>
	</div>
	<div class="btn-group pull-right">
		<button type="button" class="btn btn-primary" onClick="$('#search_sel').toggle()"><span class="glyphicon glyphicon-search"></span> 검색</button>
	</div>
</div>
<form name="search_form" action="<?=$url_all_list?>" method="get" enctype="multipart/form-data" onsubmit="return validate(this)" style="margin-top:5px;margin-bottom:10px">
<?=$_post_param[0]?>
<? if(isset($ss['cat'])) { ?>
<input type="hidden" name="ss[cat]" value="1">
<? } ?>
<div class="input-group" id="search_sel" style="display:none">
	<div class="input-group-btn">
		<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
			Search <span class="caret"></span>
		</button>
		<ul class="dropdown-menu" role="menu">
			<li><label><input type="checkbox" name="ss[st]" value="1" <?=$checked_st?>> 제목</label></li>
			<li><label><input type="checkbox" name="ss[sc]" value="1" <?=$checked_sc?>> 내용</label>	</li>		
			<li><label><input type="checkbox" name="ss[sn]" value="1" <?=$checked_sn?>> 작성자</label></li>
<? if($_bbs_auth['admin']) { ?>
			<li><label><input type="checkbox" name="ss[si]" value="1" <?=$checked_si?>>아이디</label></li>
<? } ?>
		</ul>
	</div>
	<input name="kw" type="text" id="kw" value="<?=$kw?>" class="form-control" hname="검색어" required>
	<span class="input-group-btn">
		<button type="submit" class="btn btn-default">검색</button>
		<button type="button" class="btn btn-outline-primary"onclick="location.href='?<?=$_get_param[0]?>'">취소</button>
	</span>
</div>
</form>
<script>
$('.dropdown-menu input, .dropdown-menu label').click(function(e) {
    e.stopPropagation();
});
</script>

<form name="list_form" method="post" enctype="multipart/form-data" action="?">
<?=$_post_param[3]?>
<input name="mode" type="hidden" value="">
<div class="list-group no-radius">
<?
/*	if($rs_list->num_rows()<1) {
		echo "
	<tr height=\"100\">
		<td align=\"center\" colspan=\"10\"><B>등록(검색) 된 자료가 없습니다.</td>
	</tr>";
	}*/

	$no = $page_info['start_no'];
	if(isset($bd_num)) $o_bd_num=$bd_num;
	while($data=$rs_list->fetch()) {
		$i_no=--$no;
		include("list_data_process.php");
		
		if($bd_delete > 0) include($_skin_list_delete); // 삭제글	
		else if($bd_secret > 0) include($_skin_list_secret); // 비밀글
		else if($bd_notice > 0) include($_skin_list_notice); // 공지사항		
		else if(isset($o_bd_num) && $o_bd_num==$bd_num) include($_skin_list_current); // 현재글
		else include($_skin_list_main);
	}
?>
</div>
</form>
<div style="text-align:center">
<?=rg_navi_mobile($page_info,$_get_param[2]); ?>
</div>