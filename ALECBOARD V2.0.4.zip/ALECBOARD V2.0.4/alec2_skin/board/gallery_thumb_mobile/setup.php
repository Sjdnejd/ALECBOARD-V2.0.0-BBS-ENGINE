<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
/* =====================================================
  : ALECBOARDV2 V4 게시판스킨

파일설명 : 게시판스킨 설정
===================================================== */
	// 글목록
	$_skin['i_reply']="<font color=blue style=font-size:8pt>└</font>"; // 응답글 아이콘
	$_skin['reply_depth']=8; // 응답글 깊이
	$_skin['i_comment_count']='<span class="badge">$bd_comment_count</span>'; // 코멘트수
	$_skin['i_new']=' <span style="color:#F00;font-size:8pt;font-weight:bold">new</span>'; // new 아이콘
	$_skin['i_secret']='<span class=" glyphicon glyphicon-lock"></span>'; // 비밀글 아이콘
	$_skin['i_delete1']='<font color=red>- 삭제된글입니다. -</font>'; // 삭제글
	$_skin['i_delete2']='<font color=red>[삭제]$bd_subject</font>'; // 삭제글(관리자)
	$_skin['i_notice']='<font color=blue>[공지]</font>'; // 공지사항
	$_skin['i_currnet']='->'; // 현재글	
	
	$_list_cfg['page_count']=5;
	
	$_default_skin_path = $_path['bbs_skin'].'default_mobile/';
?>