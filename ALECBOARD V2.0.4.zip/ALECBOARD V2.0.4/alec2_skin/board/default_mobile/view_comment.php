<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
/* =====================================================
  : ALECBOARDV2 V4 게시판스킨

파일설명 : 코멘트루틴

변수설명
$_bbs_auth['comment'] : 코멘트 입력여부
$bd_num : 글번호
$vcfg['input_name'] : 이름입력받을지
$s_bc_name : 기본으로 채워질 이름
$vcfg['spam_chk'] : 스팸체크여부
$spam_chk_img : 스팸이미지
$spam_chk_code : 스팸체크코드(현재는고정)
$comment_delete_chk : 코멘트삭제 가능여부
$comment_delete_url : 코멘트삭제 주소
$bc_write_date : 코멘트 작성일
$bc_content : 코멘트내용
===================================================== */
?>
<div class="view_comment" style="display:none">
<form name="cmt_list_form" method="post" enctype="multipart/form-data" action="?">
<?=$_post_param[3]?>
<input name="mode" type="hidden" value="">
<input name="mode2" type="hidden" value="">
<input type="hidden" name="bd_num" value="<?=$bd_num?>">
<input type="hidden" name="token" value="<?=$token?>">
<?
	// 코멘트 목록을 뿌려주는 부분
	include("clist_pre_process.php");
	$comment_cnt = $rs_comment->num_rows();
	while($data_comment=$rs_comment->fetch()) {
		include("clist_data_process.php");
?>
	<div class="list">
		<? if($_bbs_auth['admin']) { ?><input type=checkbox name="chk_cnums[]" value="<?=$bc_num?>"><? } ?>
		<?=$bc_name?> <span style="color:#999"> <span class='split'>|</span> <?=$bc_write_date?></span>
		<? if($comment_delete_chk) { ?> - <a href="<?=$comment_delete_url?>"><i class="fa fa-trash-o"></i></a><? } ?>
		<div><?=$bc_content?></div>
	</div>
	<div class="line"></div>
<? } ?>	
<? if($_bbs_auth['admin']) { ?>
<script>
function comment_delete_select(){
	if(!chk_checkbox(cmt_list_form,'chk_cnums[]',true)){
		alert('한개이상 선택 하세요.');
		return;
	}
	if(!confirm('삭제하시겠습니까?')){
		return;
	}
	
	document.cmt_list_form.mode.value='comment_delete';
	document.cmt_list_form.mode2.value='select';
	document.cmt_list_form.submit();
}
</script>
<label style="margin-left:10px"><input type="checkbox" onClick="set_checkbox(cmt_list_form,'chk_cnums[]',this.checked)"> 전체댓글선택</label>
<input type="button" value="선택 코멘트삭제" class="btn btn-sm btn-default" onclick="comment_delete_select();">
<div class="line"></div>
<? } ?>
</form>
<? if($_bbs_auth['comment']) { // 코멘트 쓰기 ?>
<div class="write">
<form name="comment_form" action="?" method="post" onSubmit="return validate(this)" role="form">
<?=$_post_param[3]?>
<input type="hidden" name="mode" value="comment_write">
<input type="hidden" name="bd_num" value="<?=$bd_num?>">
<input type="hidden" name="token" value="<?=$token?>">
<? if($vcfg['input_name']) { ?>
	<div class="form-group" style="float:left">
		작성자 : 
		<input type="text" name="bc_name" value="<?=$s_bc_name?>" class="form-control form1" required hname="작성자" size="10" placeholder="User Name">
	</div>
	<div class="form-group" style="float:left;padding-left:10px">
		암호 :
		<input type="password" name="bc_pass" class="form-control form1" size="10" placeholder="Password">
	</div>
<? } else { ?>
	<div>
    작성자 : <?=$s_bc_name?>
	</div>
<? } ?>
<div style="clear:both"></div>
<div class="form-group">
  <textarea name="bc_content" rows="3" class="form-control" required hname="내용" placeholder="Comment"></textarea>
</div>
<div style="clear:both"></div>
<? if($vcfg['spam_chk']) { ?>
<div class="form-group" style="margin-bottom:5px;overflow:auto">
	<div style="float:left">
	<?=$spam_chk_img?>
	</div>
	<div style="overflow:hidden;padding-left:5px;">
	스팸방지코드 입력 : 
	<input name="spam_chk" type="text" class="form-control" size="10" required hname="스팸방지코드" placeholder="스팸방지 코드를 입력해주세요.">
	</div>
</div>
<? } ?>
<div style="clear:both"></div>
<div class="line"></div>
<div style="text-align:center;">
  <button type="submit" class="btn btn-default">코멘트 등록하기</button>
</div>
</form>
</div>
<div class="line"></div>
<? } ?>
</div>
