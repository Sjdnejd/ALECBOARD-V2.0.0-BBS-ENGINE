<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
/* =====================================================
  : ALECBOARDV2 V4 게시판스킨

파일설명 : 글작성

변수설명
$mode : 글작성모드(write,modify,replay)
$bd_num : 글수정,답변글 일 경우 글번호
$old_pass : 글수정시 원래 암호
$wcfg['use_notice'] : 공지사항
$wcfg['use_secret'] : 비밀글
$wcfg['use_reply_mail'] : 응답글
$wcfg['input_name'] : 이름입력여부
$wcfg['input_pass'] : 암호입력여부
$wcfg['input_email'] : 이메일입력여부
$wcfg['use_home'] : 홈페이지
$wcfg['use_category'] : 카테고리
$wcfg['use_html'] : html사용
$wcfg['use_link'] : 링크사용
$wcfg['use_upload'] : 업로드
$vcfg['spam_chk'] : 스팸체크여부
$spam_chk_img : 스팸이미지
$spam_chk_code : 스팸체크코드(현재는고정)
===================================================== */
	if($wcfg['use_editor'] && $bd_html != '1') 
		$bd_content = rg_conv_text($bd_content,$bd_html);
?>
<div class="write_form">
	<h4 class="text-center"> 
<?
	switch($mode) {
		case 'write' :
?>글등록<?
		break;
		case 'reply' :
?>답변글<?
		break;
		case 'modify' :
?>글수정<?
		break;
	}
?>
	</h3>
<form name="write_form" method="post" action="?<?=$_get_param[3]?>" onSubmit="return write_form_chk(this);" enctype="multipart/form-data" role="form">
<input type="hidden" name="mode" value="<?=$mode?>">
<input type="hidden" name="act" value="ok">
<input type="hidden" name="bd_num" value="<?=$bd_num?>">
<input type="hidden" name="old_pass" value="<?=$old_pass?>">
<input type="hidden" name="token" value="<?=$token?>">
<? if($wcfg['use_notice'] || $wcfg['use_secret'] || $wcfg['use_reply_mail']) { ?>
<div class="form-group">
	<? if($wcfg['use_notice']) { ?>
	<label class="checkbox-inline"><input type="checkbox" name="bd_notice" value="1" <?=$chk_bd_notice?>> 공지사항</label>
	<? } ?>
	<? if($wcfg['use_secret']) { ?>
	<label class="checkbox-inline"><input type="checkbox" name="bd_secret" value="1" <?=$chk_bd_secret?>> 비밀글</label>
	<? } ?>
	<? if($wcfg['use_reply_mail']) { ?>
	<label class="checkbox-inline"><input type="checkbox" name="bd_reply_mail" value="1" <?=$chk_bd_reply_mail?>> 답변메일수신</label>
	<? } ?>
</div>
<? } ?>
<? if($wcfg['input_name']) { ?>
	<div class="form-group">
		<label for="f_bd_name">작성자</label>
		<input name="bd_name" id="f_bd_name" type="text" value="<?=$bd_name?>" class="form-control" required hname="작성자" placeholder="작성자">
  </div>
<? } ?>
<? if($wcfg['input_pass']) { ?>
<div class="form-group">
	<label for="f_bd_pass">암호</label>
	<input name="bd_pass" id="f_bd_pass" type="password" value="<?=$bd_name?>" class="form-control" placeholder="암호">
</div>
<? } ?>
<? if($wcfg['input_email']) { ?>
<div class="form-group">
	<label for="f_bd_email">이메일</label>
	<input name="bd_email" id="f_bd_email" type="text" value="<?=$bd_email?>" class="form-control" placeholder="이메일 주소">
</div>
<? } ?>
<? if($wcfg['use_home']) { ?>
<div class="form-group">
	<label for="f_bd_home">홈페이지</label>
	<input name="bd_home" id="f_bd_home" type="text" value="<?=$bd_home?>" class="form-control" placeholder="홈페이지 주소">
</div>
<? } ?>
<? if($wcfg['use_category']) { ?>
<div class="form-group">
	<label for="f_cat_num">분류</label>
	<select name="cat_num" id="f_cat_num" class="form-control">
	<option value="">==선택==</option>
	<?=rg_html_option($_category_info,$cat_num,'cat_num','cat_name')?>
	</select>
</div>
<? } ?>
  <div class="form-group">
    <label for="f_bd_subject">제목</label>
		<input name="bd_subject" id="f_bd_subject" type="text" class="form-control" value="<?=$bd_subject?>" size="60" required hname="제목" placeholder="제목">
  </div>
<? if($wcfg['use_html']) { ?>
  <div class="form-group">
		<label for="f_bd_html">HTML</label>
		<select name="bd_html" id="f_bd_html" class="form-control">
		<?=rg_html_option(array("0"=>"사용안함","1"=>"HTML사용","2"=>"HTML+&lt;BR&gt;"),$bd_html)?>
		</select>
  </div>
<? } ?>
  <div class="form-group">
		<label for="f_bd_content">내용</label>
		<textarea name="bd_content" id="f_bd_content" cols="60" rows="10" required hname="내용" placeholder="내용" class="form-control"><?=$bd_content?></textarea>
  </div>
<?
	if($wcfg['use_link']) { 
		for($i=0;$i<$wcfg['link_count'];$i++) {
?>
	<div class="pull-left" style="padding-right:5px">링크 #<?=($i+1)?></div>
	<div class="form-group" style="overflow:hidden">
		<label class="inline" for="f_bd_links_<?=$i?>_name">이름 : </label>
		<input name="bd_links[<?=$i?>][name]" id="f_bd_links_<?=$i?>_name" type="text" class="form-control" value="<?=$bd_links[$i]['name']?>">
		<label for="f_bd_links_<?=$i?>_url">URL : </label>
		<input name="bd_links[<?=$i?>][url]" id="f_bd_links_<?=$i?>_url" type="text" class="form-control" value="<?=$bd_links[$i]['url']?>">
	</div>
<?
		}
	}
?>
<?
	if($wcfg['use_upload']) {
		for($i=0;$i<$wcfg['upload_count'];$i++) {
?>
	<div class="form-group">
		<label for="f_bd_files_<?=$i?>">첨부파일 #<?=($i+1)?></label>
		<input type="file" name="bd_files[<?=$i?>]" id="f_bd_files_<?=$i?>" class="form-control">
		<? if($bd_files[$i][name]!='') { ?>
		<label><?=$bd_files[$i][name]?> 삭제
		<input type="checkbox" name="bd_files_del[<?=$i?>]" value="1" /></label>
		<? } ?>
	</div>
<?
		}
	}
?>
<? if($wcfg['spam_chk']) { ?>
	<div class="pull-left" style="padding-right:5px"><?=$spam_chk_img?></div>
	<div class="form-group" style="overflow:hidden">
		<label for="f_spam_chk">스팸방지코드</label>
		<input name="spam_chk" id="f_spam_chk" type="text" class="form-control" size="10" required hname="스팸방지코드" placeholder="스팸방지코드">
		<p class="help-block">좌측의 문자를 입력해주세요</p>
	</div>
<? } ?>

<div class="text-center">
<div class="btn-group">
		<button type="submit" class="btn btn-default"><i class="fa fa-pencil"></i> 
<?
	switch($mode) {
		case 'reply' :
		case 'write' : echo " 등 록 "; break;
		case 'modify' :
		case 'write' : echo " 수 정 "; break;
	}
?></button>
		<button type="button" class="btn btn-outline-primary" onClick="history.back();"><i class="fa fa-ban"></i>  취 소 </button>
</div>
</div>
</form>
</div>
<? if($wcfg['use_editor']) { ?>
<script src="<?=$_url['site']?>ckeditor/ckeditor.js"></script>
<script>
	CKEDITOR.replace( 'bd_content',
		{
			height: '400px',
			customConfig: '<?=$_url['bbs']?>ckeditor_config.php?bbs_code=<?=$bbs_code?>'
		}
	);
</script>
<? } ?>
<script>
function write_form_chk(f) {
<? if($wcfg['use_editor']) { ?>
	if(CKEDITOR.instances.bd_content.getData().trim() == '') {
		alert('내용을 입력해주세요.');
		CKEDITOR.instances.bd_content.focus();
		return false;
	}
<? } ?>
	return validate(f);
}
</script>