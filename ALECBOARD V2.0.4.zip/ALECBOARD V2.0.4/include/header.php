<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<body>
<div id="wrap">
	<div id="header">
		<div class="logo"><a href="../main/index.php"><img src="../images/logo.gif" width="120" height="55" border="0" /></a></div>
		<ul class="menu"> 
				<li class="first"><a href="../main/index.php">HOME</a></li>
<? if($_mb) { ?>
				<li><a href="<?=$_url['member']?>modify.php">정보수정</a></li>
		    <li><a href="<?=$_url['member']?>login.php?logout">로그아웃</a></li>
<? } else { ?>
				<li><a href="<?=$_url['member']?>join.php">회원가입</a></li>
				<li><a href="<?=$_url['member']?>login.php">로그인</a></li>
<? } ?>
<?php /*?>				<li><a href="">마이페이지</a></li>
				<li><a href="../shop/cart.php">장바구니</a></li>
				<li><a href="../shop/wish.php">관심상품</a></li>
				<li><a href="../shop/order_list.php">주문/배송조회</a></li>
				<li><a href="">고객센터</a></li><?php */?>
		</ul>
	</div>
	<div id="topmenu">
		<ul>
<?
	$rs_group = new $rs_class($dbcon);
	$rs_group->clear();
	$rs_group->set_table($_table['group']);
	$rs->set_table($_table['bbs_cfg']);
	$i=0;
	while($tmp_group=$rs_group->fetch()) {
		$rs->clear();
		$rs->add_where("gr_num={$tmp_group['gr_num']}");
		$tmp_bbs=$rs->fetch();
		
		$i++;
?>
				<li class="<?=$i==1?"first":""?>"><a href="<?=$_url['bbs']?>list.php?bbs_code=<?=$tmp_bbs['bbs_code']?>" class="menu"><?=$tmp_group['gr_name']?></a></li>
<?
	}
?>
            <li><a href="../main/board_search.php" class="menu" target="_top">통합검색</a></li>
<script>
function a() {
window.open('http://rgro.net/main/pg_order.php?pg_from=ALECBOARDV24','program','width=700,height=600,scrollbars=yes');
}
</script>
		</ul>
	</div>