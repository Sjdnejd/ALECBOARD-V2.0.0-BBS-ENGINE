<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
  </div>
 <!-- // 우측 컨텐츠 -->
</div>
<!-- // 메인 컨텐츠 -->
<? include('../include/footer.php'); ?>