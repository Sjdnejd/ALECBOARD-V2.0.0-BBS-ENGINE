<?
	$_GET['chg_site']='pc';
	include_once("../include/header_code.php");
?>

</script>
<? include_once("_header.php"); ?>
<?=rg_lastest_style('default')// 최신글 스킨에 사용하는 스타일을 미리 읽어온다 ?>
<?=rg_lastest_style('gallery_thumbnail') ?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>bxSlider</title>
<link href="jquery.bxslider/jquery.bxslider.css" rel="stylesheet" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<script src="jquery.bxslider/jquery.bxslider.js"></script>
<!-- 부트스트랩 -->
    <!--link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css"-->

    <link rel="stylesheet" href="./main/css/sandstone.css">
    <!--link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css"-->
<style>
h1 {color:white;}
</style>
<script type="text/javascript">
//<![CDATA[
$(document).ready(function(){
	//$('.bxslider').bxSlider();

     $('.bxslider').bxSlider({
        auto: true,
        speed: 500,
        pause: 4000,
        mode:'fade',
        autoControls: true,
        pager: true,
    });
});
//]]>
</script>
</head>
<body>
<!--
<div style="max-width:1000px;">
<ul class="bxslider">
    <li><img src="images/img01.jpg" title="캡션이 보여집니다." /></li>
    <li><img src="images/img02.jpg" title="캡션이 보여집니다." /></li>
    <li><img src="images/img03.jpg" title="캡션이 보여집니다." /></li>
    <li><img src="images/img04.jpg" title="캡션이 보여집니다." /></li>
</ul>
</div>
-->

<div style="max-width:1000px;">
<ul class="bxslider">
    <li>
        <div style="position:absolute;"></div>
        <img src="images/img01.jpg" />
    </li>
    <li>
        <div style="position:absolute;"></div>
        <img src="images/img02.jpg" />
    </li>
    <li>
        <div style="position:absolute;"></div>
        <img src="images/img03.jpg" />
    </li>
    <li>
        <div style="position:absolute;"></div>
        <img src="images/img04.jpg" />
    </li>
</ul>
</div>

</body>
</html>
<?
	$rs_bbs = new $rs_class($dbcon);
	$rs_group = new $rs_class($dbcon);
	$rs_group->clear();
	$rs_group->set_table($_table['group']);
	$rs_group->add_where("gr_state=1");
	$rs_group->add_order("gr_num");
	while($g_info=$rs_group->fetch()) {
		$rs_bbs->clear();
		$rs_bbs->set_table($_table['bbs_cfg']);
		$rs_bbs->add_where("gr_num={$g_info['gr_num']}");
		$rs_bbs->add_order("bbs_num");
		$i=0;
?>
* <?=$g_info['gr_name']?>
	<div style="margin:0 auto; text-align:center;">
<?
		$gallery=array();
		while($bbs_info=$rs_bbs->fetch()) {
			if($bbs_info['bbs_code']=='gallery') { // bbs_code 가 gallery 인 게시판은 따로 출력
				$gallery[]=$bbs_info;
				continue;
			}
			$i++;
?>
		<div style="width:50%;margin:0 -3px;<?=$i % 2 == 1?"float:left;clear:both":"float:right"?>">
				<?=rg_lastest($bbs_info['bbs_code'],'default',5,45)?>
		</div>
<?
		}
		foreach($gallery as $bbs_info) {
?>
	<div style="clear:both"></div>
	<?=rg_lastest($bbs_info['bbs_code'],'gallery_thumbnail',"5x2",20,'','','','130x130')?>
<?
		}
	}
?>
	</div>
<? include_once($_path['site']."alec2_popup/popup.inc.php"); ?>
<? include_once("_footer.php"); ?>