<?

	include_once("../alec2_include/lib.php");
	
	if($_SESSION['ss_login_ok']) {
		if($ret_url=='') $ret_url='../main/index.php';
		rg_href($ret_url);
	}
	$mb_agree = rg_get_setup('mb_agree');
	$mb_privacy = rg_get_setup('mb_privacy');
?>
<? include_once($_path['member'].'_header.php'); ?>
<? include_once($_path['skin']."site/".$_site_mode."/join.php"); ?>
<? include_once($_path['member'].'_footer.php'); ?>