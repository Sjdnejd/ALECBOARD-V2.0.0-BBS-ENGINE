<?

	include_once("../alec2_include/lib.php");
	$is_use=false;
?>
<? include('../include/header_win.php'); ?>
<body>
<div class="title">닉네임 중복확인</div>
		<form name="login_form" method="post" action="?" onSubmit="return validate(this)" enctype='multipart/form-data'>
		<input type="hidden" name="form_info" value="<?=$form_info?>">
		<table width="300" align="center" border="0" cellpadding="0" cellspacing="6" style="margin:0 auto">
			<tr>
			  <td align="center">
<?
	if($mb_nick!='') { 
		if(!$validate->userid($mb_nick)) {
?> (<?=$mb_nick?>)는 닉네임로 사용할 수 없습니다.<? 
		} else {
			$rs->clear();
			$rs->set_table($_table['member']);
			$rs->add_where("mb_nick='".$dbcon->escape_string($mb_nick)."'");
			$rs->select();
			if(!$rs->num_rows()) { 
				$is_use=true;
?> (<?=$mb_nick?>)는 사용가능한 닉네임 입니다.<? 
			} else {
?> (<?=$mb_nick?>)는 이미사용중인 닉네임 입니다.<br>다른 닉네임를 입력하세요.<? 
			}
		}
	} else { 
?> 사용할 닉네임를 입력 해주세요.<?
	}
?>
				</td>
			  </tr>
			</table>
		<table width="300" align="center" border="0" cellpadding="0" cellspacing="6" style="margin:0 auto">
			<tr>
				<td width="50" align="right"><strong>닉네임</strong>&nbsp;</td>
				<td width="120"><input type="text" class="input" name="mb_nick" size="18" maxlength="12" hname="닉네임" required option="nick"  value="<?=$mb_nick?>"></td>
				<td><input name="submit" type="submit" class="btn btn-outline-primary" value="중복확인"></td>
			</tr>
		</table>
		<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td align="center">
<? if($is_use) { ?>
<?
	list($form_name,$f_mb_nick)=explode('|',$form_info);
	$form_mb_nick="opener.$form_name.$f_mb_nick";
?>
<script language="javascript">
function id_use() {
	if(window.opener.document.getElementById('<?=$f_mb_nick?>') != null) {
		obj=window.opener.document.getElementById('<?=$f_mb_nick?>');
	} else {
		obj=window.opener.document.<?=$form_name?>.<?=$f_mb_nick?>
	}

	obj.value='<?=$mb_nick?>';
	obj.focus();
	self.close()
}
</script>
				<input type="button" class="btn btn-outline-primary" value=" 사용하기 " onClick="id_use()">
<? } ?>
				<input type="button" class="btn btn-outline-primary" value="  닫  기  " onClick="self.close()">
					</td>
			</tr>
		</table>
		</form>
</body>
<? include('../include/header_win.php'); ?>
