<?php
/*
 * login_with_facebook.php
 *
 * @(#) $Id: login_with_facebook.php,v 1.3 2013/07/31 11:48:04 mlemos Exp $
 *
 */

	/*
	 *  Get the http.php file from http://www.phpclasses.org/httpclient
	 */
	$site_path="../../";
	$site_url="../../";
	include_once($site_path."include/header_code.php");
	$sns_name = "네이버";
	if($_site_info['sl_naver']!='Y') {
		rg_href("","잘못된 접근\n\n{$sns_name}로그인 연동기능이 활성화 되어 있지 않습니다.","close");
	}
	
	$sns_cfg = rg_get_setup('sns_api_info');

	require('http.php');
	require('oauth_client.php');

	$client = new oauth_client_class;
	$client->debug = false;
	$client->debug_http = true;
	$client->server = 'Naver';
	$client->redirect_uri = 'http://'.$_SERVER['HTTP_HOST'].
		dirname(strtok($_SERVER['REQUEST_URI'],'?')).'/login_with_naver.php';

	$client->client_id = $sns_cfg['naver_key']; $application_line = __LINE__;
	$client->client_secret = $sns_cfg['naver_secret'];

	if(strlen($client->client_id) == 0
	|| strlen($client->client_secret) == 0)
		die('네이버연동 오류 관리자에게 문의해주세요.(연동정보 미입력)');


	if($login=='Y') {
		unset($_SESSION['OAUTH_STATE']);
		$client->ResetAccessToken();
//		print_r($_SESSION);
	}
	
	/* API permissions
	 */
	if(($success = $client->Initialize()))
	{
		if(($success = $client->Process()))
		{
			if(strlen($client->access_token))
			{
				$success = $client->CallAPI(
					'http://apis.naver.com/nidlogin/nid/getHashId_v2.xml', 
					'POST', array('mode'=>'userinfo'), array('FailOnAccessError'=>true), $user);
			}
		}
		$success = $client->Finalize($success);
	}
	if($client->exit)
		exit;
	if($success)
	{
		$xml = simplexml_load_string($user);
		if($xml->result->resultcode == '00') {
			$client->GetAccessToken($AccessToken);
			$gubun_cd = '04';
			$id = $xml->response->enc_id;
			$name = $xml->response->nickname;
			$data1 = $AccessToken['value'];
			$data2 = $AccessToken['refresh'];
			$token=rg_get_token();
			include_once("./sns_login.php");
		}
	}
	rg_href('',"네이버 로그인중 오류가 발생했습니다.",'close');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Naver OAuth client results</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<?php
		echo '<h1>', HtmlSpecialChars($user->name), 
			' you have logged in successfully with Naver!</h1>';
		echo '<pre>', 
		HtmlSpecialChars(str_replace("><",">\n<",$user)),
		var_dump($xml),"<br>",
		"ID : ", $xml->response->enc_id,"<br>",
		"NICK : " , $xml->response->nickname,"<br>",
		HtmlSpecialChars($user),
		print_r($_SESSION),
		print_r($_COOKIE),
		print_r($AccessToken),
		 '</pre>';
?>
</body>
</html>
<?php

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>OAuth client error</title>
</head>
<body>
<h1>OAuth client error</h1>
<pre>Error: <?php echo HtmlSpecialChars($client->error); ?></pre>
</body>
</html>
<?php

?>