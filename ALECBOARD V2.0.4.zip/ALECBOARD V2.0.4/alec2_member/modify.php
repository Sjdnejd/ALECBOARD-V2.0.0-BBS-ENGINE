<?

	include_once("../alec2_include/lib.php");
	
	if(!$_mb)
		rg_href($_url['member'].'login.php');
	
	if($form_mode == 'member_modify') {
		if($_mb['mb_pass']==rg_password_encode($mb_pass_confirm)) {
			$_SESSION["MODIFY_CHK"]=time();
			rg_href($_url['member']."modify_form.php");
		} else {
			rg_href($_SERVER['PHP_SELF'],'암호를 확인해주세요.');
		}
	}
	
	// sns 계정연결정보 삭제
	unset($_SESSION['SNS_BIND_DATA']);
	unset($_SESSION['OAUTH_STATE']);
	unset($_SESSION['OAUTH_ACCESS_TOKEN']);
?>
<? include_once($_path['member'].'_header.php'); ?>
<? include_once($_path['skin']."site/".$_site_mode."/modify.php"); ?>
<? include_once($_path['member'].'_footer.php'); ?>