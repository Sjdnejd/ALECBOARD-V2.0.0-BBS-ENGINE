<?

	include_once("../alec2_include/lib.php");
	
	if(isset($logout)) {
		$ss_mb_id='';
		$ss_mb_num='';
		$ss_login_ok='';
		$ss_hash='';
		$_SESSION['ss_mb_id']=$ss_mb_id;
		$_SESSION['ss_mb_num']=$ss_mb_num;
		$_SESSION['ss_login_ok']=$ss_login_ok;
		$_SESSION['ss_hash']=$ss_hash;
		unset($_SESSION['ss_mb_id']);
		unset($_SESSION['ss_mb_num']);
		unset($_SESSION['ss_login_ok']);
		unset($_SESSION['ss_hash']);
		if($ret_url=='') 
		{
			if($_site_mode=='pc') 
			{
				$ret_url='../main/index.php';
			}
			else
			{
				$ret_url='../m/index.php';
			}
		}
		rg_href($ret_url);
	}

	if($_SESSION['ss_login_ok']) {
		if($ret_url=='') 
		{
			if($_site_mode=='pc') 
			{
				$ret_url='../main/index.php';
			}
			else
			{
				$ret_url='../m/index.php';
			}
		}
		rg_href($ret_url);
	}
	
	if($_SERVER['REQUEST_METHOD']=='POST' && $form_mode=='member_login_ok') {
		$mb_id=strtolower($mb_id);
		if($ret_url_login=='')
			$ret_url_login='?ret_url=' . urlencode($ret_url);
		
		if(!$validate->userid($mb_id))
			rg_href($ret_url_login,'아이디를 확인해주세요.');
			
		if(!$validate->strlen_chk($mb_pass,4,12))
			rg_href($ret_url_login,'암호를 확인해주세요.');
		
		$mb_pass = rg_password_encode($mb_pass);
		
		$rs->clear();
		$rs->set_table($_table['member']);
		$rs->add_where("mb_id='".$dbcon->escape_string($mb_id)."'");
		$rs->select();
		if(!$rs->num_rows()) //
			rg_href($ret_url_login,'가입되지 않은 아이디 입니다.');			
		
		$data=$rs->fetch();
		if($data['mb_pass']!=$mb_pass) {
			rg_href($ret_url_login,'암호를 정확히 입력하세요.');
		}

		switch($data['mb_state']) {
			case 1 : // 승인된 아이디
				break;
			case '0' : 
				rg_href($ret_url_login,'승인대기중입니다.');		
				break;
			case '2' : 
				rg_href($ret_url_login,'미승인된 아이디 입니다.');		
				break;
			case '3' : 
				rg_href($ret_url_login,'탈퇴된 아이디입니다.\n재가입을 원할경우 관리자에게 메일주십시요.');	
				break;
			default :
				rg_href($ret_url_login,'알수없는 오류 관리자에게 연락 바랍니다.');	
				break;
		}
		$login_date=time();
		$rs->clear();
		$rs->set_table($_table['member']);
		$rs->add_field("login_count",$data['login_count']+1);
		$rs->add_field("login_date",$login_date);
		$rs->add_field("login_ip",$_SERVER['REMOTE_ADDR']);
		$rs->add_where("mb_num={$data['mb_num']}");
		$rs->update();
		$data['login_date'] = $login_date;

		// 지난 로그인 날자와 현재 로그인 날자가 다르다면 로그인 포인트 올린다. 
		if(floor($data['login_date']/86400) < floor(time()/86400))
			rg_set_point($data['mb_num'],$_po_type_code['etc'],
								$_site_info['login_point'],'로그인','로그인포인트','');
			
		$ss_mb_id = $data['mb_id'];
		$ss_mb_num = $data['mb_num'];
		$ss_login_ok = 'ok';
		
		$_SESSION['ss_mb_id']=$ss_mb_id;
		$_SESSION['ss_mb_num']=$ss_mb_num;
		$_SESSION['ss_login_ok']=$ss_login_ok;
		
		rg_set_login_hash($data);
		
		if($from == 'sns' && $_SESSION['SNS_BIND_DATA']) { // SNS계정연결
			list($sns_gubun,$sns_num,$sns_id) = explode("||",$_SESSION['SNS_BIND_DATA']);
			// 기존연결 끊기
			$rs->clear();
			$rs->set_table($_table['member_sns']);
			$rs->add_where("gubun_cd='$sns_gubun'");
			$rs->add_where("mb_num='{$data['mb_num']}'");
			$rs->delete();
			
			$rs->clear();
			$rs->set_table($_table['member_sns']);
			$rs->add_field("mb_num",$data['mb_num']); // 로그인된 회원과 연결
			$rs->add_where("gubun_cd='$sns_gubun'");
			$rs->add_where("id='$sns_id'");
			$rs->add_where("num='$sns_num'");
			$rs->update();
			
			unset($_SESSION['SNS_BIND_DATA']);
			unset($_SESSION['OAUTH_STATE']);
			unset($_SESSION['OAUTH_ACCESS_TOKEN']);
		}
		
		$rs->commit();
		if($ret_url=='') 
		{
			if($_site_mode=='pc') 
			{
				$ret_url='../main/index.php';
			}
			else
			{
				$ret_url='../m/index.php';
			}
		}
		rg_href($ret_url);
	}
?>
<? include_once($_path['member'].'_header.php'); ?>
<? include_once($_path['skin']."site/".$_site_mode."/login.php"); ?>
<? include_once($_path['member'].'_footer.php'); ?>