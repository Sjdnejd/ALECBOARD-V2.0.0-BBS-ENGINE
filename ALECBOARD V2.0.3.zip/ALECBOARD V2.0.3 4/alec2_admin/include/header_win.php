<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ALECBOARDV2 - ver <?=ALECBOARDV2_VERSION?> (<?=DB_TYPE?>)</title>
<link rel="stylesheet" type="text/css" href="../css/style.css">
<script src="<?=$_url['js']?>common.js"></script>
<script src="<?=$_url['js']?>lib.validate.js"></script>
<link rel="stylesheet" type="text/css" href="//code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
<script>
	// 회원아이디 목록창
	function member_list_popup(url_path,form_info)
	{
		// 다중선택여부|폼네임|key필드명|값받을폼이름|표시될폼이름|표시형식$mb_id($mb_name)
		window_open(url_path+'member_list_popup.php?form_info='+form_info,'member_list_popup','scrollbars=yes,width=600,height=600');
	}
</script>
</head>
