<?
	header("location: main/index.php");
?>