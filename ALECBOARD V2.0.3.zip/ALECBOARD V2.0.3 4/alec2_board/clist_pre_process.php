<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	if(isset($_REQUEST['skin_path'])) exit;
	
	$rs_comment = new $rs_class($dbcon);
	$rs_comment->clear();
	$rs_comment->set_table($_table['bbs_comment']);
	$rs_comment->add_where("bd_num=$bd_num");
	$rs_comment->add_order("bc_num");
?>