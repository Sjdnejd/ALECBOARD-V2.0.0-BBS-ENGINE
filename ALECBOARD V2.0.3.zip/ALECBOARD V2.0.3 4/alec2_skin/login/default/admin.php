<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<table width="95%" align="center" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td align="center"><input type="button" class="button" value=" 관리자접속 " onClick="window_open('<?=$_url['admin']?>')"></td>
	</tr>
</table>