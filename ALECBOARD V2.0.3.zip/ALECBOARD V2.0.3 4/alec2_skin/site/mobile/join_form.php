<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<div class="content">
<div class="title">&nbsp;&nbsp;회원가입 <small>(<span style="color:#F00">*</span> 표시가 있는 항목은 필수 입력입니다.)</small></div>
		<br>
		<form name="member_form" method="post" action="?" onsubmit="return validate(this)" enctype='multipart/form-data'>
		<input type="hidden" name="form_mode" value="member_join_ok">
		<input type="hidden" name="ret_url" value="../main/index.php">
		<input type="hidden" name="from" value="<?=$from?>">
		<input type="hidden" name="token" value="<?=$token?>">
		<? include('member_form.php') ?>
		<div style="text-align:center">
		<input type="submit" value="  회원가입  " class="btn btn-default">
		</div>
		</form>
</div>
<script language='Javascript'>
	if(typeof(document.member_form.mb_id) != "undefined")
		document.member_form.mb_id.focus();
</script>