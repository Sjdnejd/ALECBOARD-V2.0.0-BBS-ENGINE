<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	/*
	$view_url : 글보기 링크
	$bd_name : 작성자명
	$bd_subject : 제목
	$i_comment_count : 코멘트 갯수
	$i_new : 새글 아이콘
	$bd_write_date : 작성일
	$bd_view_count : 조회수
	*/
?>
<a href="<?=$view_url?>" class="list-group-item">
<?=$i_comment_count?>
<h5 class="list-group-item-heading"><?=$bd_subject?> <?=$i_new?></h5>  
<p class="list-group-item-text" style="color:#999;font-size:small">
<?=$bd_name?> <span class='split'>|</span> <?=$bd_write_date?> <span class='split'>|</span> 조회 : <?=$bd_view_count?> 
<?	
		if($lcfg['view_vote_yes'] && $lcfg['view_vote_no']) {
			echo "<span class='split'>|</span> <span class=\"glyphicon glyphicon-thumbs-up\"></span> $bd_vote_yes / <span class=\"glyphicon glyphicon-thumbs-down\"></span> $bd_vote_no";
		} else if($lcfg['view_vote_yes']) {
			echo "<span class='split'>|</span> <span class=\"glyphicon glyphicon-thumbs-up\"></span> ".$bd_vote_yes;
		} else if($lcfg['view_vote_no']) {
			echo "<span class='split'>|</span> <span class=\"glyphicon glyphicon-thumbs-down\"></span> ".$bd_vote_no;
		}
?>
</p>
</a>
