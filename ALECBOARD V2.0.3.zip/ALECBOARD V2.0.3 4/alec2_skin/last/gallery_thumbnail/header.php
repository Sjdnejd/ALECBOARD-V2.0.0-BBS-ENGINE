<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	/*
	$more_url : 더보기 링크(게시판)
	$_bbs_info['bbs_name'] : 게시판 정보중 게시판 이름
	*/
?>
<? $li=0; ?>
<div class="last_gallery_thumbnail">
<a href="<?=$more_url?>" class="titlel">
	<span class="subject">ㆍ<?=$_bbs_info['bbs_name']?></span>
  <span class="more">more</span>
</a>
<table class="listl" width="100%">