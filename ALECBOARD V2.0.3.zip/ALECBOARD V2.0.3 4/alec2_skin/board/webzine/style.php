<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<link href="<?=$skin_url?>style.css?20140210" rel="stylesheet" type="text/css">