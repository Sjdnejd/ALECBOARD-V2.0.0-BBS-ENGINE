<?
	if($site_path == '' || $_REQUEST['site_path']!='') $site_path="../";
	if($site_url == '' || $_REQUEST['site_url']!='') $site_url="../";
	include_once($site_path."alec2_include/lib.php");
?>