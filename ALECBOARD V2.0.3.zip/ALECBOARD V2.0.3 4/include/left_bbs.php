<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
	<div class="sub_title">
	- <?=$_group_info['gr_name']!=''?$_group_info['gr_name']:"게시판"?> -
	</div>
	<ul class="sub_menu">
<?
	$rs->clear();
	$rs->set_table($_table['bbs_cfg']);
	if($_group_info['gr_num']!='') 
		$rs->add_where("gr_num={$_group_info['gr_num']}");
	while($tmp_bbs=$rs->fetch()) {
?>
		<li><a href="../alec2_board/list.php?bbs_code=<?=$tmp_bbs['bbs_code']?>"><?=$tmp_bbs['bbs_name']?></a></li>
<?
	}
?>
</ul>