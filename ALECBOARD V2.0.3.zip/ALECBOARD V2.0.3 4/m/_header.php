<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<? include('../include/m_header_win.php'); ?>
<? include('../include/m_header.php'); ?>
