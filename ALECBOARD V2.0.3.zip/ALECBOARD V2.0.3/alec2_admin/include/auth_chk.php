<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	if (!defined('ALECBOARDV2_VERSION')) exit;

	if(!$_mb) {
		rg_href("../main/login.php");
	}
	
	if(!$_auth['admin']) {
		rg_href($_url['member']."login.php?logout&ret_url=".urlencode($_url['admin']));
	}
	
	// 파라메타 처리
	$p_str="";
	$_get_param[0]=$p_str;

	if(is_array($ss)) {
		foreach($ss as $__k => $__v) {
			$p_str.="&ss[$__k]=".$__v;
		}
	}
	if($kw!='') $p_str.="&kw=".$kw;
	$_get_param[1]=$p_str;
	
  if($ot != '') $p_str.="&ot=".$ot;
	$_get_param[2]=$p_str;
	$_get_param[3]=$p_str."&page=$page";
?>