<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<body>
<a name=top></a>
<!-- Begin Wrapper -->
<div id="wrapper">
	<!-- Begin Header -->
	<div id="header">
		
		<div id="headerlogo">
			<div id="headerlogoimg">
				<div><a href="../main/index.php"><img src="../images/logo.gif" width="120" height="55" /></a></div>
			</div>
		</div>
		<div style="float:left;height:60px;line-height:60px"><a href="<?=$site_url?>" target="_blank">[HOME]</a></div>
		<div id="headeruser">
			<div id="headerusera1">
			<div id="headeruserinfo">
				<div>
			접속아이디 : <?=$_mb['mb_id']?><br>
			관리자레벨 : <?=$_level_info[$_mb['mb_level']]?>
				</div>
			</div>
			</div>
		</div>
		
		<div style="clear:both"></div>
		<ul>
<? foreach($_MENU_ADM as $k => $v) { ?>
			<li onMouseOver="$('#top_sub_menu<?=$k?>').show();" onMouseOut="$('.top_submenu > div').hide();"><a href="<?=$v[$k.'00'][1]?>"><?=$v[$k.'00'][0]?></a>
			<? if(count($_MENU_ADM[$k])>1) { ?>
				<div class="top_submenu">
					<div id="top_sub_menu<?=$k?>" style="z-index:10">
						<ul onmouseover="list_over_color2(event,'#EEEEEE',0)" onmouseout='list_out_color2(event)'>
						<? foreach($_MENU_ADM[$k] as $k1 => $v1) { ?>
						<?
							if(substr($k1,2,2) == '00') continue;
						?>
								<li><nobr><a href="<?=$v1[1]?>" <?=$v1[2]!=''?" target='$v1[2]'":""?>><?=$v1[0]?></a></nobr></li>
						<? } ?>
						</ul>
					</div>
				</div>
			<? } ?>
			</li>
<? } ?>
		</ul>	 
	</div>

 <!-- End Header -->
<?
	$SUBMENU=substr($_MENU,0,2);
	$LINKMENU=substr($_MENU,2,2);
?>
<? if($_MENU != '') { ?>
<?
	$_TITLE = $_MENU_ADM[$SUBMENU][$SUBMENU.'00']['0'];
	if($LINKMENU!='00') $_TITLE .= " > ".$_MENU_ADM[$SUBMENU][$SUBMENU.$LINKMENU]['0'];
?>
 <div id="main">
 <!-- Begin Left Column -->
	<div id="mainleft">
		<div id="mainlefttitle">- <?=$_MENU_ADM[$SUBMENU][$SUBMENU.'00']['0']?> -</div>
		<ul>
<? foreach($_MENU_ADM[$SUBMENU] as $k => $v) { ?>
<?
	if(substr($k,2,2) == '00') continue;
?>
				<li><a href="<?=$v[1]?>"><?=$v[0]?></a></li>
<? } ?>
		</ul>
	</div>
 <!-- End Left Column -->
 <!-- Begin Right Column -->
	<div id="mainright">
<? } else { ?>
  <div id="mainindex">
<? } ?>
<?
	unset($_MENU_ADM);
?>
