<?
/* =====================================================
	프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com
	
  최종수정일 : 
 ===================================================== */
	$_MENU='0202';
	include_once("../include/header_code.php");

	// 메일발송
	if ($mode=="send" ) {
		if(!rg_verify_token($_POST['token'])) {
			rg_href('','정상적인 접근이 아닙니다.\n\n새로고침후 다시 시도해보세요.','back');
		}

		$target_no=0;

		$content = rg_conv_text($content,1);

		if($recv_level != '') {
			$rs_list->clear();
			$rs_list->set_table("$_table[member]");
			$rs_list->add_where('mb_is_mailing=1');
			if ( $recv_level != "all") $rs_list->add_where("mb_level='$recv_level'");
			while($R = $rs_list->fetch()) {
				if($R['mb_email']!='') {
					rg_mail($R['mb_email'],$subject,$content,$sender_email);
					$target_no++;   // 발송횟수 증가
				}
			}
		}
    
    // 추가 발송
    if ( $recv_email ) {
        $array_rcv = split(",",$recv_email);
        for ( $i=0; $i< count($array_rcv); $i++ ) {
            # 수신자 설정 / 메일전송
            if ( trim($array_rcv[$i]) != '' ) {
								rg_mail($array_rcv[$i],$subject,$content,$sender_email);
                $target_no++;   // 발송횟수 증가
            }
        }
    }

    $msg = "총 $target_no 통의 메일을 발송하였습니다";
		rg_href($_SERVER['PHP_SELF'],$msg);
	}
	$token=rg_get_token();
?>
<? include("../include/header_win.php"); ?>
<script>
var editorConfig_upload='Y';
$(document).ready(function(e) {
	CKEDITOR.replace( 'content', {height: '400px'});
});
</script>
<script src="<?=$_path['site']?>ckeditor/ckeditor.js"></script>
<? include("../include/header.php"); ?>
				<script language="JavaScript" type="text/JavaScript">
<!--
function form_chk() {
    var obj = document.forms['mail_form'];
    if ( obj.recv_level.value == "" &&
         obj.recv_email.value == "" ) {
        alert ( "e-mail 수신자가 존재하지 않습니다." );
        obj.recv_level.focus();
        return false;
    }
		if(validate(obj)) {
			if(confirm("발송한 이메일은 취소가 불가능합니다.\n대량으로 메일을 보낼경우 스팸발송지로 등록되어 수신이 되지 않을수도 있습니다.\n확실합니까?")) {
				return true;
			}
		}
}
//-->
</script>
				<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
						<tr>
								<td bgcolor="#F7F7F7"><?=$_TITLE?></td>
						</tr>
				</table>
				<br>
				<form method="post" name="mail_form" onSubmit ="return form_chk()" ENCTYPE="MULTIPART/FORM-DATA">
						<input type="hidden" name="mode" value="send">
						<input type="hidden" name="token" value="<?=$token?>">
						<table width="700"  border="0" cellspacing="0" cellpadding="0">
								<tr>
										<td><table width="100%"  border="0"  class="site_content">
										<col width="150">
														<tr>
																<th>수신자 레벨</th>
																<td><select name="recv_level">
																				<option value="">선택하세요</option>
																				<option value="all">전체</option>
																				<?=rg_html_option($_level_info)?>
																		</select>
																		
																		* 회원 가입시 메일수신에 동의한 회원에게만 메일이 발송됩니다. </td>
														</tr>
														<tr>
																<th>추가 수신자 이메일</th>
																<td><input type="text" name="recv_email" value="<?=$recv_email?>" size=60>
																		* 여러명 입력시에는 , 으로 구분 </td>
														</tr>
														<tr>
																<th>발신자 이메일</th>
																<td><? // =$_site_info['site_name']?>
																		
																		<input name="sender_email" type="text" value="<?=htmlspecialchars($_site_info['mail_from'])?>">
																		<input name="sender_name" type="hidden" value="<?=$_site_info['site_name']?> 관리자"></td>
														</tr>
														<tr>
																<th>제목</th>
																<td><input name="subject" type="text" value="<?=$subject?>" size="90" required hanme="제목"></td>
														</tr>
														<tr>
																<td colspan="2" align="center">
																		<textarea name="content" class="ckeditor" cols="90" rows="24" required hanme="내용"><?=$content?></textarea></td>
														</tr>
												</table></td>
								</tr>
						</table>
						<table width="700">
								<tr>
										<td height="50" align="center"><input type="submit" value="보내기" class="button" onClick="this.form.mode.value='send'"></td>
								</tr>
						</table>
				</form>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>