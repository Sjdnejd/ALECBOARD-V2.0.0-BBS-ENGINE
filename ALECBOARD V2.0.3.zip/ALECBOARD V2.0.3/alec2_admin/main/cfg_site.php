<?
/* =====================================================
	프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com
	
  최종수정일 : 
 ===================================================== */
	$_MENU='0101';
	include_once("../include/header_code.php");
	
	if($_SERVER['REQUEST_METHOD']=="POST" && $mode == "update"){
		if(!rg_verify_token($_POST['token'])) {
			rg_href('','정상적인 접근이 아닙니다.\n\n새로고침후 다시 시도해보세요.','back');
		}

		$rs->clear();
		$rs->set_table($_table['setup']);
		$rs->add_field("ss_content",serialize($site_info));
		$rs->add_where("ss_name='site_info'");
		$rs->update();
		rg_href('?');
	}

	// 사이트 설정
	$rs->clear();
	$rs->set_table($_table['setup']);
	$rs->add_field("ss_content");
	$rs->add_where("ss_name='site_info'");
	$rs->select();
	if($rs->num_rows()<1) {
		$rs->clear_field();
		$rs->add_field("ss_name","site_info");
		$rs->insert();

		$rs->clear_field();
		$rs->add_field("ss_content");
		$rs->select();
	}
	$rs->fetch('tmp');
	$site_info = unserialize($tmp);
	
	// 레벨 정보
	$level_info = rg_get_setup('level_info');

	$token=rg_get_token();
?>
<? include("../include/header_win.php"); ?>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?></td>
  </tr>
</table>
<br>
<form name=form1 method=post action="?" onSubmit="return validate(this)">
  <input type=hidden name=mode value="update">
	<input type="hidden" name="token" value="<?=$token?>">
  <table border="0" cellspacing="0" cellpadding="0" width="600" align="center">
    <tr>
      <td class="a_sub_title">사이트 환경설정</td>
    </tr>
  </table>
  <table border="0" cellpadding="0" cellspacing="0" width="600" class="site_content">
    <tr>
      <th width="120">사이트 이름</th>
      <td><input name="site_info[site_name]" type="text" class="input" value="<?=$site_info['site_name']?>" size="50" required hname='사이트이름'></td>
    </tr>
    <tr>
      <th width="120">운영자 이름</th>
      <td><input name="site_info[admin_name]" type="text" class="input" value="<?=$site_info['admin_name']?>" size="50" required hname='운영자이름'></td>
    </tr>
    <tr>
      <th align="center">운영자 이메일</th>
      <td><input name="site_info[admin_email]" type="text" class="input" value="<?=$site_info['admin_email']?>" size="50" required hname="운영자이메일" option="email"></td>
    </tr>
    <tr>
      <th align="center">운영자 연락처</th>
      <td><input type="text" class="input" name="site_info[admin_tel]" value="<?=$site_info['admin_tel']?>"></td>
    </tr>
    <tr>
      <th align="center">발송이메일주소</th>
      <td><input name="site_info[mail_from]" type="text" class="input" value="<?=$site_info['mail_from']?>" size="50" hname="발송이메일주소"></td>
    </tr>
    <tr>
      <th align="center">회신이메일주소</th>
      <td><input name="site_info[mail_return]" type="text" class="input" value="<?=$site_info['mail_return']?>" size="50" option="email" hname="회신이메일주소"></td>
    </tr>
    <?php /*?>		<tr>
			<td align="center">상호</td>
			<td><input type="text" class="input" name="site_info[company_name]" value="<?=$site_info['company_name']?>">
				상호를 입력하세요.</td>
		</tr>
		<tr>
			<td align="center">사업자 주소</td>
			<td><input type="text" class="input" name="site_info[address]" value="<?=$site_info['address']?>" size=50>
				주소를 입력하세요.</td>
<?php */?>
  </table>
  <br>
  <table border="0" cellspacing="0" cellpadding="0" width="600" align="center">
    <tr>
      <td class="a_sub_title">포인트설정</td>
    </tr>
  </table>
  <table border="0" cellpadding="0" cellspacing="0" width="600" class="site_content">
    <tr>
      <th width="120" align="center">신규가입시</th>
      <td><input type="text" class="input" name="site_info[join_point]" value="<?=$site_info['join_point']?>" size=10 option="number" hname="가입포인트" dir="rtl"> 
      숫자로만 입력 </td>
    </tr>
    <tr>
      <th width="120" align="center">로그인시</th>
      <td><input type="text" class="input" name="site_info[login_point]" value="<?=$site_info['login_point']?>" size=10 option="number" hname="로그인포인트" dir="rtl"> 
      숫자로만 입력 </td>
    </tr>
  </table>
  <br>
  <table border="0" cellspacing="0" cellpadding="0" width="600" align="center">
    <tr>
      <td class="a_sub_title">회원 환경설정</td>
    </tr>
  </table>
  <table border="0" cellpadding="0" cellspacing="0" width="600" class="site_content">
    <tr>
      <th width="120" align="center">회원 기본 상태 </th>
      <td><?=rg_html_radio("site_info[join_state]",$_const['member_states'],$site_info['join_state'],NULL,NULL,'','','','&nbsp;&nbsp;')?>			
			</td>
    </tr>
    <tr>
      <th align="center">회원 기본 레벨</th>
      <td><select name="site_info[join_level]">
<?=rg_html_option($level_info,$site_info['join_level'],NULL,NULL,NULL)?>
</select></td>
    </tr>
    <tr>
      <th align="center">탈퇴상태</th>
      <td><?=rg_html_radio("site_info[leave_state]",array(1=>"회원정보 즉시삭제","탈퇴 상태로 변경"),$site_info['leave_state'],NULL,NULL,'','','','&nbsp;&nbsp;')?>
			</td>
    </tr>
    <tr>
    		<th align="center">로그인 설정</th>
    		<td><span style="width:130px;display:inline-block">가입후 자동로그인 : </span>
				<label><input type="radio" name="site_info[join_login]" value="1" <?=(($site_info['join_login']=='1')?'checked':'')?>> 예</label> &nbsp;
				<label><input type="radio" name="site_info[join_login]" value="0" <?=(($site_info['join_login']!='1')?'checked':'')?>> 아니요</label> 
				</td>
 		</tr>
    <tr>
    		<th align="center">SNS로그인 설정</th>
    		<td>
				<span style="width:130px;display:inline-block">네이버 로그인 연동 : </span>
				<label><input type="radio" name="site_info[sl_naver]" value="Y" <?=(($site_info['sl_naver']=='Y')?'checked':'')?>> 예</label> &nbsp;
				<label><input type="radio" name="site_info[sl_naver]" value="N" <?=(($site_info['sl_naver']!='Y')?'checked':'')?>> 아니요</label> 
    		<br>
				<span style="width:130px;display:inline-block">구글 로그인 연동 : </span>
				<label><input type="radio" name="site_info[sl_google]" value="Y" <?=(($site_info['sl_google']=='Y')?'checked':'')?>> 예</label> &nbsp;
				<label><input type="radio" name="site_info[sl_google]" value="N" <?=(($site_info['sl_google']!='Y')?'checked':'')?>> 아니요</label> 
				<br>
				<span style="width:130px;display:inline-block">페이스북 로그인 연동 : </span>
				<label><input type="radio" name="site_info[sl_facebook]" value="Y" <?=(($site_info['sl_facebook']=='Y')?'checked':'')?>> 예</label> &nbsp;
				<label><input type="radio" name="site_info[sl_facebook]" value="N" <?=(($site_info['sl_facebook']!='Y')?'checked':'')?>> 아니요</label> 
				<br>
				<span style="width:130px;display:inline-block">트위터 로그인 연동 : </span>
				<label><input type="radio" name="site_info[sl_twitter]" value="Y" <?=(($site_info['sl_twitter']=='Y')?'checked':'')?>> 예</label> &nbsp;
				<label><input type="radio" name="site_info[sl_twitter]" value="N" <?=(($site_info['sl_twitter']!='Y')?'checked':'')?>> 아니요</label> 
 				<br></td>
    		</tr>
    <tr>
    		<th align="center">로그인검증방법</th>
    		<td>
    				<select name="site_info[auth_chk]">
						<?=rg_html_option(array(1=>"정보수정일시(중복로그인 가능)",2=>"로그인일시(중복로그인 불가능)",),$site_info['auth_chk'],NULL,NULL,NULL)?>
						</select>
						<br>
						<br>
    				아이피 추가인증 (아이피가 바뀌면 다시 로그인 해야 합니다.)<br>
				<span style="width:50px;display:inline-block">PC : </span>
				<label><input type="radio" name="site_info[auth_ip_pc]" value="Y" <?=(($site_info['auth_ip_pc']=='Y')?'checked':'')?>> 예</label> 
				&nbsp;<span style="color:#F00">(아이피까지 검증하므로 CSRF 방어에 효과가 있습니다.)</span>
				<br>
				<span style="width:50px;display:inline-block"></span>
				<label><input type="radio" name="site_info[auth_ip_pc]" value="N" <?=(($site_info['auth_ip_pc']!='Y')?'checked':'')?>> 아니요</label> 
				<br>
				<span style="width:50px;display:inline-block">모바일 : </span>
				<label><input type="radio" name="site_info[auth_ip_mobile]" value="Y" <?=(($site_info['auth_ip_mobile']=='Y')?'checked':'')?>> 예</label>
				<br>
				<span style="width:50px;display:inline-block"></span>
				<label><input type="radio" name="site_info[auth_ip_mobile]" value="N" <?=(($site_info['auth_ip_mobile']!='Y')?'checked':'')?>> 아니요</label> 
				&nbsp;<span style="color:#F00">(아이피가 자주 바뀌므로 사용안하는것이 편리합니다.)</span>
<br>
<br>
모바일,PC는 웹브라우저로 구분 합니다.<br>
로그인 검증방법을 변경시 다시 로그인 하셔야 합니다.
						 </td>
    		</tr>
  </table>
  <br>
  <table width="600" align="center">
    <tr>
      <td align=center><input type="submit" value=" 저  장 " class="button">
      </td>
    </tr>
  </table>
</form>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>