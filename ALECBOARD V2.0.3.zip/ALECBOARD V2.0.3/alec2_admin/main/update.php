<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	$_MENU='0505';
	include_once("../include/header_code.php");
?>
<? include("../include/header_win.php"); ?>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?></td>
  </tr>
</table>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="center">
        <br>
          <table border="0" cellspacing="0" cellpadding="0" width="70%" class="site_content">
          <tr> 
            <td height="30" align="center" valign="middle" bgcolor="f7f7f7"><a href="update_4.3.2_4.3.3.php">4.3.2 에서 4.3.3 로 업데이트 합니다.</a></td>
          </tr>
        </table>
        <br>
          <table border="0" cellspacing="0" cellpadding="0" width="70%" class="site_content">
          <tr> 
            <td height="30" align="center" valign="middle" bgcolor="f7f7f7"><a href="update_4.3.1_4.3.2.php">4.3.1 에서 4.3.2 로 업데이트 합니다.</a></td>
          </tr>
        </table>
        <br>
          <table border="0" cellspacing="0" cellpadding="0" width="70%" class="site_content">
          <tr> 
            <td height="30" align="center" valign="middle" bgcolor="f7f7f7"><a href="update_4.3.0_4.3.1.php">4.3.0 에서 4.3.1 로 업데이트 합니다.</a></td>
          </tr>
        </table>
        <br>
          <table border="0" cellspacing="0" cellpadding="0" width="70%" class="site_content">
          <tr> 
            <td height="30" align="center" valign="middle" bgcolor="f7f7f7"><a href="update_4.2.1_4.3.0.php">4.2.1 에서 4.3.0 로 업데이트 합니다.</a></td>
          </tr>
        </table>
        <br>
          <table border="0" cellspacing="0" cellpadding="0" width="70%" class="site_content">
          <tr> 
            <td height="30" align="center" valign="middle" bgcolor="f7f7f7"><a href="update_4.2.0_4.2.1.php">4.2.0 에서 4.2.1 로 업데이트 합니다.</a></td>
          </tr>
        </table>
        <br>
        </p>
		</td>
  </tr>
</table>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>