<?

define('ALECBOARDV2_VERSION', 'install 4.3');

set_magic_quotes_runtime(0);
error_reporting(E_ALL ^ E_NOTICE);

if(isset($_REQUEST['site_path'])) exit;
$site_path='../../';
$site_url='../../';

// 메인 라이브러리
include_once($site_path.'alec2_include/config.php');
include_once($_path['inc'].'func_comm.php');
include_once($_path['inc'].'validate.php');
include_once($_path['inc'].'class_db.php');

header("Content-type: text/html; charset={$_const[charset]}");

clearstatcache();

if (file_exists($_path['data'].'db_info.php')) { // 이미 설치되어 있음
    $msg="
이미 데이터베이스 설정파일이 있습니다.<br>
재설치 하시려면 해당 파일과 데이터베이스를 초기화 하신후 실행 하시기 바랍니다.";
    include("../include/error.inc.php");
}

if(!is_dir($_path['data'])) {
    $msg="데이터디렉토리를 찾을 수 없습니다.<br>
확인해주세요.";
    include("../include/error.inc.php");
}

$data_chk_perms = @fileperms($_path['data']);
$data_chk_perms=decoct($data_chk_perms);
$data_chk_perms=substr($data_chk_perms,-1);
if($data_chk_perms!='7') {
    $msg="
데이터디렉토리(alec2_data)의 권한을 707또는 777으로 변경해주시기 바랍니다.<br>
변경방법은 ftp 를 이용하셨을 경우 권한 설정시 Owner(소유자) 와 Group(그룹), Other(모든사용자) 의 권한을 읽기,쓰기,실행이 가능하도록 체크해시고, <br>
telnet 또는 SSH를 이용하실경우 명령어 \"chmod 707 데이터디렉토리명(alec2_data)\" 로 변경하실 수 있습니다.<br><br>
변경하셨으면 확인 버튼을 눌러주세요.<br>
<input type=\"button\" onclick=\"location.reload()\" value=\" 확 인 \">
";
    include("../include/error.inc.php");
}

if($_POST['act']) {
    $db_type=trim($_POST[db_type]);
    $db_port=trim($_POST[db_port]);
    $db_host=trim($_POST[db_host]);
    $db_user=trim($_POST[db_user]);
    $db_password=trim($_POST[db_password]);
    $db_database_name=trim($_POST[db_database_name]);

//		if(!$mysql_host || !$mysql_user || !$mysql_password || !$mysql_database_name) {
//			rg_href('','mysql정보를 빠짐없이 입력해주세요.','','back');
//		}

    switch($db_type) { // db종류
        case 'CUBRID' :
            if(!function_exists('cubrid_connect')) {
                $msg="CUBRID 데이터베이스를 지원하지 않는 서버입니다.<br>
	서버관리자에게 문의하세요.<br>";
                include("../include/error.inc.php");
                exit;
            }
            include_once($_path['inc'].'class_db_cubrid.php');
            include_once('../schema/cubrid_schema.inc.php');
            define('DB_TYPE', 'cubrid');
            break;
        case 'ORACLE' :
            if(!function_exists('OCILogon')) {
                $msg="오라클 데이터베이스를 지원하지 않는 서버입니다.<br>
	서버관리자에게 문의하세요.<br>";
                include("../include/error.inc.php");
                exit;
            }
            include_once($_path['inc'].'class_db_oracle.php');
            include_once('../schema/oracle_schema.inc.php');
            define('DB_TYPE', 'oracle');
            break;
        case 'MYSQL' :
            if(!function_exists('mysql_connect')) {
                $msg="MYSQL 데이터베이스를 지원하지 않는 서버입니다.<br>
	서버관리자에게 문의하세요.<br>";
                include("../include/error.inc.php");
                exit;
            }
            include_once($_path['inc'].'class_db_mysql.php');
            include_once('../schema/mysql_schema.inc.php');
            define('DB_TYPE', 'mysql');
            break;
    }

    $db_class=DB_TYPE.'_db_class';
    $rs_class=DB_TYPE.'_rs_class';

    $dbcon = new $db_class();
    $dbcon->set_debug(0);
    $dbcon->connect($db_host, $db_user, $db_password,$db_database_name);

    if(!$dbcon->dbcon) {
        $msg="데이터베이스 서버에 접속할수 없습니다.<br>
접속정보를 확인해주세요.<br>
에러 : ".$dbcon->error();
        include("../include/error.inc.php");
        exit;
    }

    if($_const[charset]=='euc-kr') @mysql_query('set names euckr');
    else if($_const[charset]=='utf-8') @mysql_query('set names utf8');

    $rs = new $rs_class($dbcon);

    $table_list = $dbcon->list_tables();
    $tmp=@array_diff($_table,$table_list);
    $chk=@array_diff($_table,$tmp);
    unset($tmp);

    if(count($chk) > 0) {
        $msg='데이터베이스에 이미 테이블이 있습니다.<br>
재설치 하시려면 ALECBOARDV2보드관련 테이블을 모두 삭제해주신후 실행해주세요.<br>
'.implode('<br>',$chk)."<br>
<br>
<br>
<input type=\"button\" onclick=\"history.back()\" value=\" 확 인 \">";
        include("../include/error.inc.php");
    }

    $table_array=array('member_sns','member','group','gmember','bbs_cfg',
        'bbs_body','bbs_comment','bbs_category','bbs_file','setup',
        'point','note','popup','comm_code');
    foreach($table_array as $v)
        $dbcon->query("CREATE TABLE {$_table[$v]} \n {$db_schema[$v]}");
//			$dbcon->query("CREATE TABLE {$_table[$v]} {$db_schema[$v]} DEFAULT CHARSET=euckr");

    if($db_type=='CUBRID') {
        // 인덱스, 시리얼, 트리거 생성
        foreach($table_array as $v)	{
            if(is_array($db_schema_index[$v])) {
                foreach($db_schema_index[$v] as $v1) {
                    $dbcon->query("CREATE INDEX {$v1}_idx on {$_table[$v]} ({$v1})");
                }
            }

            if($db_schema_serial_field[$v] != '') {
                $serial_name="{$_table[$v]}__{$db_schema_serial_field[$v]}";
                $dbcon->query("CREATE SERIAL $serial_name START WITH 10");
            }
        }
    }

    if($db_type=='ORACLE') {
        // 인덱스, 시퀀스 생성
        $i=0;
        foreach($table_array as $v)	{
            if(is_array($db_schema_index[$v])) {
                foreach($db_schema_index[$v] as $v1) {
                    $i++;
                    $dbcon->query("CREATE INDEX i{$i}_{$v1}_idx on {$_table[$v]} ({$v1})");
                }
            }

            if($db_schema_serial_field[$v] != '') {
                $serial_name="{$_table[$v]}__{$db_schema_serial_field[$v]}";
                $dbcon->query("CREATE SEQUENCE $serial_name START WITH 10");
            }
        }
    }

    $table_array=array('counter_day','counter_etc','counter_host',
        'counter_log','counter_search');
    foreach($table_array as $v)
        $dbcon->query("CREATE TABLE {$_table['prefix']}{$v} \n {$db_schema[$v]}");
//			$dbcon->query("CREATE TABLE {$_table['prefix']}{$v} {$db_schema[$v]} DEFAULT CHARSET=euckr");

    if($db_type=='CUBRID') {
        // 인덱스, 시리얼, 트리거 생성
        foreach($table_array as $v)	{
            if(is_array($db_schema_index[$v])) {
                foreach($db_schema_index[$v] as $v1) {
                    $dbcon->query("CREATE INDEX {$v1}_idx on {$_table['prefix']}{$v} ({$v1})");
                }
            }

            if($db_schema_serial_field[$v] != '') {
                $serial_name="{$_table['prefix']}{$v}__{$db_schema_serial_field[$v]}";
                $dbcon->query("CREATE SERIAL $serial_name START WITH 10");
            }
        }
    }

    if($db_type=='ORACLE') {
        // 인덱스, 시퀀스 생성
        foreach($table_array as $v)	{
            if(is_array($db_schema_index[$v])) {
                foreach($db_schema_index[$v] as $v1) {
                    $i++;
                    $dbcon->query("CREATE INDEX i{$i}_{$v1}_idx on {$_table['prefix']}{$v} ({$v1})");
                }
            }

            if($db_schema_serial_field[$v] != '') {
                $serial_name="{$_table['prefix']}{$v}__{$db_schema_serial_field[$v]}";
                $dbcon->query("CREATE SEQUENCE $serial_name START WITH 10");
            }
        }
    }

    $tmp=array();
    $tmp[0] = "손님";
    $tmp[1] = "레벨1";
    $tmp[2] = "레벨2";
    $tmp[3] = "레벨3";
    $tmp[4] = "레벨4";
    $tmp[5] = "레벨5";
    $tmp[6] = "레벨6";
    $tmp[7] = "레벨7";
    $tmp[8] = "레벨8";
    $tmp[9] = "레벨9";
    $tmp[50] = "그룹관리자";
    $tmp[90] = "운영자";
    $tmp = serialize($tmp);
    $dbcon->query(
        "INSERT INTO {$_table['group']} 
				(gr_num, gr_id, gr_name, gr_desc, gr_header_file,
					gr_header_tag, gr_footer_tag, gr_footer_file, gr_state,
					gr_default_state, gr_default_level, gr_level_type, gr_level_info,
					gr_ext_cfg, gr_admin_memo, gr_reg_date, gr_reg_mb,mgr_header_file,mgr_footer_file)
				VALUES 
(1,'main','메인그룹','기본그룹','../include/header_bbs.php','','','../include/footer_bbs.php',1,1,1,0,'$tmp','','기본그룹임',".time().",1,'../include/m_header.php','../include/m_footer.php')");
    unset($tmp);

    // 사이트 기본정보
    $tmp1=array();
    $tmp1["site_name"] = "사이트이름";
    $tmp1["admin_name"] = "운영자명";
    $tmp1["admin_email"] = "master@aa.aa";
    $tmp1["admin_tel"] = "000-0000-0000";
    $tmp1["mail_from"] = "발송이메일";
    $tmp1["mail_return"] = "master@aa.aa";
    $tmp1["join_point"] = "10";
    $tmp1["login_point"] = "1";
    $tmp1["join_state"] = "1";
    $tmp1["join_level"] = "1";
    $tmp1["leave_state"] = "2";
    $tmp1["join_login"] = "1";
    $tmp1["sl_facebook"] = "";
    $tmp1["sl_twitter"] = "";
    $tmp1["sl_google"] = "";
    $tmp1["sl_naver"] = "";
    $tmp1["auth_chk"] = "1";
    $tmp1["auth_ip_pc"] = "Y";
    $tmp1["auth_ip_mobile"] = "";
    $tmp1 = serialize($tmp1);
    $dbcon->query(
        "INSERT INTO {$_table['setup']} 
				(ss_num, ss_name, ss_content)
				VALUES (1,'site_info','$tmp1')");
    unset($tmp1);

    // 레벨정보
    $tmp2=array();
    $tmp2["0"] = "손님";
    $tmp2["1"] = "레벨1";
    $tmp2["2"] = "레벨2";
    $tmp2["3"] = "레벨3";
    $tmp2["4"] = "레벨4";
    $tmp2["5"] = "레벨5";
    $tmp2["6"] = "레벨6";
    $tmp2["7"] = "레벨7";
    $tmp2["8"] = "레벨8";
    $tmp2["9"] = "레벨9";
    $tmp2["50"] = "그룹관리자";
    $tmp2["90"] = "운영자";
    $tmp2 = serialize($tmp2);
    $dbcon->query(
        "INSERT INTO {$_table['setup']} 
				(ss_num, ss_name, ss_content)
				VALUES (2,'level_info','$tmp2')");
    unset($tmp2);

    // 회원입력폼
    $tmp=array();
    $tmp["mb_name"] = "2";
    $tmp["mb_nick"] = "1";
    $tmp["mb_email"] = "1";
    $tmp["mb_jumin"] = "0";
    $tmp["mb_tel1"] = "1";
    $tmp["mb_tel2"] = "1";
    $tmp["mb_address"] = "1";
    $tmp["mb_signature"] = "1";
    $tmp["mb_introduce"] = "1";
    $tmp["photo1"] = "1";
    $tmp["icon1"] = "1";
    $tmp = serialize($tmp);
    $dbcon->query(
        "INSERT INTO {$_table['setup']} 
				(ss_num, ss_name, ss_content)
				VALUES (3,'member_form','$tmp')");
    unset($tmp);

    // SNS 로그인
    $tmp=array();
    $tmp["facebook_key"] = "";
    $tmp["facebook_secret"] = "";
    $tmp["twitter_key"] = "";
    $tmp["twitter_secret"] = "";
    $tmp["google_key"] = "";
    $tmp["google_secret"] = "";
    $tmp["naver_key"] = "";
    $tmp["naver_secret"] = "";
    $tmp = serialize($tmp);
    $dbcon->query(
        "INSERT INTO {$_table['setup']} 
				(ss_num, ss_name, ss_content)
				VALUES (4,'sns_api_info','$tmp')");
    unset($tmp);

    // 이용약관
    $dbcon->query(
        "INSERT INTO {$_table['setup']} 
				(ss_num, ss_name, ss_content)
				VALUES (5,'mb_agree','<strong>제 1 장 총칙</strong><br />\n<br />\n제 1 조 목적<br />\n이 약관은 ALECBOARDV2보드(이하 &ldquo;회사&rdquo;라 한다)이 제공하는 정보제공 서비스 (이하 &ldquo;서비스&rdquo;라 한다)의 이용조건 및 절차에 관한 사항을 규정함을 목적으로 합니다.&nbsp;<br />\n<br />\n제 2 조 (정의)<br />\n1. &ldquo;ALECBOARDV2보드&rdquo;이라 함은 php를 이용하는 이용자들의 php관련 정보제공 및 ALECBOARDV2보드게시판을 제공하는 웹사이트를 의미한다.<br />\n2. &ldquo;회원&rdquo;이라 함은 서비스를 이용하고자 회사가 요구하는 정보를 기재하고, 이 약관에 동의한 개인 또는 법인을 의미합니다.<br />\n3. &ldquo;이용자&rdquo;라 함은 ALECBOARDV2보드(ALECBOARDV2.com)에 접속하여 회사가 제공하는 서비스를 받는 회원 또는 비회원을 의미합니다.<br />\n4. &ldquo;아이디(ID)&rdquo;라 함은 회원의 식별과 서비스 이용을 위하여 회원이 정하고 회사가 승인하는 문자와 숫자의 조합을 의미합니다.<br />\n5. &ldquo;비밀번호(Password)&rdquo;라 함은 회원이 부여 받은 아이디와 일치되는 회원임을 확인하고, 회원이 자신의 비밀보호를 위해 정한 문자 또는 숫자의 조합을 의미합니다.<br />\n<br />\n제 3 조 약관의 효력 및 변경<br />\n1. 이 약관은 서비스를 통하여 이를 공지하거나 전자우편, 기타의 방법으로 이용자에게 공지함으로써 약관 시행일로부터 그 효력이 발생합니다.<br />\n2. 회사는 이 약관을 변경할 수 있으며, 약관을 개정할 경우에는 적용일자 및 개정사유를 명시하여 현행약관과 함께 회사의 서비스 초기화면에 적용일 7일전부터 적용일자 전일까지 게시하는 방법으로 그 내용을 공지합니다.<br />\n3. 이용자가 변경된 약관에 동의하지 아니하는 경우에는 서비스의 이용을 차단할 수 있으며, 계속 사용의 경우에는 본 약관의 변경내용에 동의한 것으로 간주됩니다.<br />\n<br />\n제 4 조 약관외 준칙<br />\n이 약관에서 정하지 않은 사항과 이 약관의 해석에 관하여는 온라인디지털콘텐츠산업발전법, 전자상거래등에서의 소비자보호에 관한 법률, 약관의 규제에 관한 법률, 기타 관계법령의 규정에 따릅니다.<br />\n<br />\n<strong>제 2 장 회원가입</strong><br />\n<br />\n제 5 조 (회원가입신청)<br />\n1. 회원가입은 이용자의 회원가입신청 및 이 약관과 회사의 개인정보취급방침에 대한 동의의 표시로써 이루어집니다.<br />\n2. 회원가입은 아이디(ID) 단위로 신청하는 것을 원칙으로 하며, 이용자는 회원가입시 실명인증 및 서비스의 원활한 운영을 위하여 회사가 요청하는 아래의 필수입력사항들에 대하여 기재하여야 합니다. 그 외의 정보들은 선택사항으로 합니다.<br />\n가. 성명<br />\n나. 아이디(ID)<br />\n다. 비밀번호<br />\n3. 회사는 필요한 경우 위2항의 내용 이외에도 새로운 내용을 추가할 수 있습니다.<br />\n4. 회사는 이용자가 회원가입시 기재한 모든 정보가 사실인 것으로 간주합니다. 이에 고의 과실 여부와 상관없이 허위의 정보를 기재한 이용자는 법적인 보호를 받을 수 없을 뿐 아니라, 회사의 서비스 제공을 제한 받으실 수 있습니다.<br />\n<br />\n제 6 조 (회원가입신청에 대한 승낙 및 거부)<br />\n1. 회사는 제5조의 회원가입신청에 대하여 특별한 사정이 없는 한 접수순서에 따라 이를 승낙합니다.&nbsp;<br />\n2. 회사는 다음 각 호에 해당하는 경우 회원가입신청에 대한 승낙을 제한할 수 있고, 그 사유가 해소될 때까지 승낙을 유보할 수 있습니다.&nbsp;<br />\n가. 서비스 관련 설비의 용량이 부족한 경우&nbsp;<br />\n나. 기술상 장애사유가 있는 경우&nbsp;<br />\n다. 가입신청자가 본 약관 제8조2항에 의거하여 이전에 회원 자격을 상실한 적이 있는 경우&nbsp;<br />\n라. 등록내용에 허위, 기재누락, 오기가 있는 경우&nbsp;<br />\n마. 기타 회사가 필요하다고 인정되는 경우&nbsp;<br />\n<br />\n제 7 조 (회원정보의 변경)&nbsp;<br />\n회원은 언제든지 서비스를 이용하여 자신의 가입 정보들을 변경할 수 있습니다.&nbsp;<br />\n<br />\n제 8 조 (회원 탈퇴 및 자격상실)<br />\n1. 회원은 회사에 언제든지 탈퇴를 요청할 수 있으며, 회원의 탈퇴요청이 있을 시에 회사는 즉시 해당 회원을 탈퇴 처리합니다.<br />\n2. 회사는 다음 각호에 해당하는 경우 회원의 자격을 제한 및 삭제할 수 있습니다.&nbsp;<br />\n가. 회원가입 신청시 허위의 정보를 기재한 경우<br />\n나. 설비에 여유가 없거나 기술상 지장이 있는 경우&nbsp;<br />\n다. 기타 회사가 필요하다고 인정되는 경우<br />\n<br />\n제 9 조 (회원에 대한 통지)<br />\n1. 회사는 서비스 초기화면에 대한 공지, 회원이 가입신청 당시 기재한 이메일주소, 전화번호 등을 이용한 방법으로 회원에 통지할 수 있습니다.<br />\n2. 회사는 불특정 다수에 대한 통지의 경우 서비스 초기 화면에 1주일간 해당 내용을 기재함으로써, 개별통지에 갈음할 수 있습니다.<br />\n<br />\n<strong>제 3 장 서비스 종류 및 이용</strong><br />\n<br />\n제 10 조 (서비스 종류 및 변경)<br />\n1. 회사가 제공하는 서비스의 종류는 아래와 같습니다.<br />\n가. php 관련 정보의 제공<br />\n나. 회원간의 커뮤니케이션 창구제공(글쓰기, 수정, 검색, 삭제, 쪽지보내기 등)<br />\n2. 회사가 제공하는 서비스의 종류는 회사의 경영 정책상 변경할 수 있으며, 변경된 내용은 제9조의 방법으로 공지합니다.<br />\n<br />\n제 11 조 (서비스 이용)<br />\n1. 서비스 이용은 회사가 회원의 가입신청을 승낙한 때로부터 즉시 가능해집니다. 단, 제13조에 한하여 그 시점이 연기될 수 있습니다.<br />\n2. 서비스의 이용시간은 회사의 업무상 또는 기술상 장애, 기타 특별한 사유가 없는 한 연중 무휴, 1일 24시간 이용할 수 있습니다. 단, 제13조에 한하여 이용을 제한할 수 있습니다.<br />\n<br />\n제 12 조 (서비스 이용 요금)<br />\n1. 회사의 서비스는 유료와 무료로 구분이 가능하며, 유료 서비스의 경우 해당 요금의 세부내역은 서비스내에 별도 명기합니다.<br />\n2. 서비스 이용 요금은 회사의 정책에 의하여 변경될 수 있습니다.&nbsp;<br />\n<br />\n제 13 조 (서비스 제공의 중지)<br />\n회사는 아래 각 호에 해당하는 경우 서비스의 일부 혹은 전부의 제공을 중지할 수 있습니다.<br />\n가. 서비스용 설비의 보수 등 공사로 인한 부득이한 경우<br />\n나. 전기통신사업법에 규정된 기간통신사업자가 전기통신서비스를 중지했을 경우<br />\n다. 국가비상사태, 정전, 서비스 설비의 장애 또는 서비스 이용의 폭주 등으로 정상적인 서비스 이용에 지장이 있는 때<br />\n라. 네트워크상의 위험성에 기초한 타인의 서비스 제공 음해 행위가 있는 때<br />\n<br />\n<strong>제 4 장 개인정보보호 및 저작권</strong><br />\n<br />\n제 14 조 (이용자의 개인정보보호)&nbsp;<br />\n1. 회사는 서비스 이용자의 정보 수집 시 반드시 당해 이용자의 동의를 얻어 필요한 최소한의 정보만을 수집하며, 이용자는 온라인을 통해서 수시로 본인의 신상정보를 열람, 정정 또는 삭제할 수 있습니다.<br />\n2. 회사는 이용자의 개인 신상정보를 본인의 동의 없이는 절대 제3자에게 제공, 분실 또는 유출하여서는 안되며 이를 지키지 않아서 발생하는 이용자의 모든 피해에 대한 책임은 회사에 있습니다. 단, 다음과 같은 경우에는 예외로 합니다.<br />\n가. 전기통신기본법 등 관계법령에 의하여 국가기관 등의 요구가 있는 경우&nbsp;<br />\n나. 범죄에 대한 수사상의 목적이 있거나 정보통신윤리위원회의 요청이 있는 경우&nbsp;<br />\n다. 배송 업무상 배송 업체에 고객의 정보를 알려주는 경우&nbsp;<br />\n라. 은행업무상 관련사항에 한하여 일부 정보를 공유하는 경우&nbsp;<br />\n마. 특정인을 식별할 수 없는 통계작성, 홍보자료, 학술연구 등의 목적인 경우&nbsp;<br />\n바. 이용자의 동의 없이 개인정보가 유출되는 등 부당한 사례를 발견했을 때에는 전화 02-2627-6637, 이메일(E-mail) : desk@phpschool.com, 한국소비자보호원, 경실련 등을 통해 신고할 수 있으며, 이에 대해 회사는 적절한 조치를 취할 의무가 있습니다<br />\n3. &ldquo;회사&rdquo;는 &quot;서비스&quot;에 등록된 회원의 ID와 이력서 정보(이름,주소,연락처등 모두 포함)를 관리합니다.<br />\n<br />\n제 15 조 (회사의 의무)<br />\n1. &quot;회사&quot;는 법령과 본 약관이 금지하거나 공서양속에 반하는 행위를 하지 않으며 본 약관이 정하는 바에 따라 지속적이고, 안정적으로 서비스를 제공하기 위해서 노력합니다.&nbsp;<br />\n2.. &quot;회사&quot;는 &quot;회원&quot;이 안전하게 서비스를 이용할 수 있도록 &quot;회원&quot;의 개인정보(신용정보 포함)보호를 위한 보안 시스템을 구축합니다.&nbsp;<br />\n3. &quot;회사&quot;는 &quot;회원&quot;이 원하지 않는 영리목적의 광고성 전자우편을 발송하지 않습니다.&nbsp;<br />\n<br />\n제 16 조 (저작권의 귀속 및 이용제한)<br />\n1. 회사가 작성한 저작물에 대한 저작재산권은 회사에 있습니다.<br />\n2. 이용자는 서비스를 이용함에 있어 취득한 정보를 회사의 사전 승낙 없이 제3자에게 제공하거나, 복제, 출판 등의 방법으로 배포할 수 없습니다.<br />\n<br />\n<strong>제 5 장 손해배상 및 면책조항</strong><br />\n<br />\n제 17 조 (손해배상)<br />\n1. 회사는 무료인 서비스와 정보 서비스 이용과 관련하여 이용자에게 발생한 어떠한 손해도 책임지지 않습니다.<br />\n2. 회사는 유료인 서비스의 이용과 관련하여 발생하는 이용자의 손해에 대하여 관계법령이 정하는 한도내에서 배상책임을 집니다. 단, 이용자의 과실이 있는 경우에는 해당 부분에 대한 책임이 면제됩니다.<br />\n<br />\n제 18 조 (연결서비스와 피연결서비스간의 관계)<br />\n1. 상위 서비스와 하위 서비스가 링크(예: 링크의 대상에는 문자 및 그림 등이 포함됨)방식 등으로 연결된 경우, 전자를 연결 서비스(웹 사이트)이라고 하고 후자를 피연결서비스(웹사이트)라고 합니다.<br />\n2. 연결서비스는 피연결서비스가 독자적으로 제공하는 재화 용역에 의하여 발생된 이용자와의 거래에 대해서 보증 책임을 지지 않습니다<br />\n<br />\n제 19 조 (면책)<br />\n1. 회사는 본 약관에서 달리 정한 것을 제외하고는 각 쇼핑몰에 게재된 어떠한 상품이나 정보에 대하여도 권한과 책임을 가지지 않습니다.<br />\n2. 쇼핑몰 고객은 각 쇼핑몰에 게재된 상품정보를 스스로의 판단하에서 자유롭게 이용할 권리가 있습니다. 또한, 회사는 어떠한 경우라도 쇼핑몰 고객이 쇼핑몰에 게재된 상품정보에 의해 입은 손해에 대해 책임이 없습니다.<br />\n3. 관리자가 회사와 제휴된 외부서비스를 이용하는 중, 외부 서비스 제공사의 일방적인 정책 변경에 따라 발생하는 관리자의 손해는 서비스 제공사에게 책임이 있으며, 이에 대해 회사는 면책됩니다.<br />\n<br />\n<strong>제 6 장 기타사항</strong><br />\n<br />\n제 20 조 (개인정보 위탁처리)<br />\n① 회사는 업무진행에 있어 필요에 의하여 고객정보 처리를 외부기관에 위탁 처리하고 있습니다.<br />\n② 회사는 수탁 업체에게 고객의 민원사항 처리를 위해 필요한 범위 내에서 정보를 제공할 수 있으며, 회사의 개인정보보호정책을 준수할 수 있는 자를 수탁자로 선정합니다.<br />\n③ 회사는 위탁계약서상의 회사의 개인정보보호 관련 지시엄수, 개인정보에 관한 비밀유지, 제3자 제공의 금지, 사고시의 책임 및 손해배상 등에 대한 사항을 명확히 규정하고 당해 계약내용을 서면 또는 전자적 기록으로 보존하여야 합니다.<br />\n<br />\n제 21 조 (권리의 양도금지)&nbsp;<br />\n관리자는 회사의 서면동의 없이 본 약관상의 권리와 의무를 제3자에게 양도, 증여하거나 이를 담보로 제공할 수 없습니다.<br />\n<br />\n제 22 조 (기타사항)<br />\n① 이 약관에 규정되어 있지 아니한 사항은 관계 법령 및 일반적인 상관례에 따릅니다.<br />\n② 이 약관으로 발생한 분쟁에 대하여 소송이 제기될 경우 서울중앙지방법원을 관할 법원으로 합니다.<br />\n<br />\n<br />\n* 부칙<br />\n이 약관은 2014년 1월 1일부터 시행합니다.')");
    unset($tmp);

    // 개인정보취급방침
    $dbcon->query(
        "INSERT INTO {$_table['setup']} 
				(ss_num, ss_name, ss_content)
				VALUES (6,'mb_privacy','<em>&lt;ALECBOARDV2보드&gt;(&#39;http://ALECBOARDV2.com&#39;이하 &#39;ALECBOARDV2보드&#39;)</em>은(는) 개인정보보호법에 따라 이용자의 개인정보 보호 및 권익을 보호하고 개인정보와 관련한 이용자의 고충을 원활하게 처리할 수 있도록 다음과 같은 처리방침을 두고 있습니다.<br />\r\n<em>&lt;ALECBOARDV2보드&gt;</em>은(는) 회사는 개인정보처리방침을 개정하는 경우 웹사이트 공지사항(또는 개별공지)을 통하여 공지할 것입니다.<br />\r\n○ 본 방침은부터&nbsp;<em>2014</em>년&nbsp;<em>1</em>월&nbsp;<em>1</em>일부터 시행됩니다.<br />\r\n<strong>1. 개인정보의 처리 목적&nbsp;<em>&lt;ALECBOARDV2보드&gt;(&#39;http://ALECBOARDV2.com&#39;이하 &#39;ALECBOARDV2보드&#39;)</em>은(는) 개인정보를 다음의 목적을 위해 처리합니다. 처리한 개인정보는 다음의 목적이외의 용도로는 사용되지 않으며 이용 목적이 변경될 시에는 사전동의를 구할 예정입니다.</strong><br />\r\n가. 홈페이지 회원가입 및 관리<br />\r\n회원 가입의사 확인, 회원제 서비스 제공에 따른 본인 식별&middot;인증, 회원자격 유지&middot;관리 등을 목적으로 개인정보를 처리합니다.<br />\r\n나. 재화 또는 서비스 제공<br />\r\n콘텐츠 제공 등을 목적으로 개인정보를 처리합니다.<br />\r\n다. 마케팅 및 광고에의 활용<br />\r\n인구통계학적 특성에 따른 서비스 제공 및 광고 게재 , 서비스의 유효성 확인, 접속빈도 파악 또는 회원의 서비스 이용에 대한 통계 등을 목적으로 개인정보를 처리합니다.<br />\r\n<br />\r\n<br />\r\n<strong>2. 개인정보 파일 현황</strong><br />\r\n<br />\r\n1. 개인정보 파일명 :&nbsp;<br />\r\n- 개인정보 항목 : 쿠키<br />\r\n- 수집방법 : 홈페이지<br />\r\n- 보유근거 :&nbsp;<br />\r\n- 보유기간 : 지체없이 파기<br />\r\n- 관련법령 :<br />\r\n<br />\r\n<br />\r\n<strong>3. 개인정보처리 위탁</strong><br />\r\n<br />\r\n①&nbsp;<em>&lt;ALECBOARDV2보드&gt;(&#39;ALECBOARDV2보드&#39;)</em>은(는) 원활한 개인정보 업무처리를 위하여 다음과 같이 개인정보 처리업무를 위탁하고 있습니다.<br />\r\n②&nbsp;<em>&lt;ALECBOARDV2보드&gt;(&#39;http://ALECBOARDV2.com&#39;이하 &#39;ALECBOARDV2보드&#39;)</em>은(는) 위탁계약 체결시 개인정보 보호법 제25조에 따라 위탁업무 수행목적 외 개인정보 처리금지, 기술적?관리적 보호조치, 재위탁 제한, 수탁자에 대한 관리?감독, 손해배상 등 책임에 관한 사항을 계약서 등 문서에 명시하고, 수탁자가 개인정보를 안전하게 처리하는지를 감독하고 있습니다.<br />\r\n<br />\r\n③ 위탁업무의 내용이나 수탁자가 변경될 경우에는 지체없이 본 개인정보 처리방침을 통하여 공개하도록 하겠습니다.<br />\r\n<br />\r\n<br />\r\n<strong>4. 정보주체의 권리,의무 및 그 행사방법 이용자는 개인정보주체로서 다음과 같은 권리를 행사할 수 있습니다.</strong><br />\r\n① 정보주체는 ALECBOARDV2보드(&lsquo;http://ALECBOARDV2.com&rsquo;이하 &lsquo;ALECBOARDV2보드) 에 대해 언제든지 다음 각 호의 개인정보 보호 관련 권리를 행사할 수 있습니다.<br />\r\n1. 개인정보 열람요구<br />\r\n2. 오류 등이 있을 경우 정정 요구<br />\r\n3. 삭제요구<br />\r\n4. 처리정지 요구<br />\r\n② 제1항에 따른 권리 행사는ALECBOARDV2보드(&lsquo;http://ALECBOARDV2.com&rsquo;이하 &lsquo;ALECBOARDV2보드) 에 대해 개인정보 보호법 시행규칙 별지 제8호 서식에 따라 서면, 전자우편, 모사전송(FAX) 등을 통하여 하실 수 있으며 &lt;기관/회사명&gt;(&lsquo;사이트URL&rsquo;이하 &lsquo;사이트명) 은(는) 이에 대해 지체 없이 조치하겠습니다.<br />\r\n③ 정보주체가 개인정보의 오류 등에 대한 정정 또는 삭제를 요구한 경우에는 &lt;기관/회사명&gt;(&lsquo;사이트URL&rsquo;이하 &lsquo;사이트명) 은(는) 정정 또는 삭제를 완료할 때까지 당해 개인정보를 이용하거나 제공하지 않습니다.<br />\r\n④ 제1항에 따른 권리 행사는 정보주체의 법정대리인이나 위임을 받은 자 등 대리인을 통하여 하실 수 있습니다. 이 경우 개인정보 보호법 시행규칙 별지 제11호 서식에 따른 위임장을 제출하셔야 합니다.<br />\r\n<br />\r\n<strong>5. 처리하는 개인정보의 항목 작성&nbsp;</strong><br />\r\n<br />\r\n①&nbsp;<em>&lt;ALECBOARDV2보드&gt;(&#39;http://ALECBOARDV2.com&#39;이하 &#39;ALECBOARDV2보드&#39;)</em>은(는) 다음의 개인정보 항목을 처리하고 있습니다.<br />\r\n1&lt;홈페이지 회원가입 및 관리&gt;<br />\r\n- 필수항목 : 비밀번호, 로그인ID, 이름<br />\r\n- 선택항목 : 이메일<br />\r\n<br />\r\n<br />\r\n<strong>6. 개인정보의 파기<em>&lt;ALECBOARDV2보드&gt;(&#39;ALECBOARDV2보드&#39;)</em>은(는) 원칙적으로 개인정보 처리목적이 달성된 경우에는 지체없이 해당 개인정보를 파기합니다. 파기의 절차, 기한 및 방법은 다음과 같습니다.</strong><br />\r\n-파기절차<br />\r\n이용자가 입력한 정보는 목적 달성 후 별도의 DB에 옮겨져(종이의 경우 별도의 서류) 내부 방침 및 기타 관련 법령에 따라 일정기간 저장된 후 혹은 즉시 파기됩니다. 이 때, DB로 옮겨진 개인정보는 법률에 의한 경우가 아니고서는 다른 목적으로 이용되지 않습니다.<br />\r\n-파기기한<br />\r\n이용자의 개인정보는 개인정보의 보유기간이 경과된 경우에는 보유기간의 종료일로부터 5일 이내에, 개인정보의 처리 목적 달성, 해당 서비스의 폐지, 사업의 종료 등 그 개인정보가 불필요하게 되었을 때에는 개인정보의 처리가 불필요한 것으로 인정되는 날로부터 5일 이내에 그 개인정보를 파기합니다.<br />\r\n-파기방법<br />\r\n전자적 파일 형태의 정보는 기록을 재생할 수 없는 기술적 방법을 사용합니다.<br />\r\n<br />\r\n<strong>7. 개인정보의 안전성 확보 조치&nbsp;<em>&lt;ALECBOARDV2보드&gt;(&#39;ALECBOARDV2보드&#39;)</em>은(는) 개인정보보호법 제29조에 따라 다음과 같이 안전성 확보에 필요한 기술적/관리적 및 물리적 조치를 하고 있습니다.</strong><br />\r\n1. 개인정보의 암호화<br />\r\n이용자의 개인정보는 비밀번호는 암호화 되어 저장 및 관리되고 있어, 본인만이 알 수 있으며 중요한 데이터는 파일 및 전송 데이터를 암호화 하거나 파일 잠금 기능을 사용하는 등의 별도 보안기능을 사용하고 있습니다.<br />\r\n<br />\r\n<br />\r\n<br />\r\n<strong>8. 개인정보 보호책임자 작성&nbsp;</strong><br />\r\n① ALECBOARDV2보드(&lsquo;http://ALECBOARDV2.com&rsquo;이하 &lsquo;ALECBOARDV2보드) 은(는) 개인정보 처리에 관한 업무를 총괄해서 책임지고, 개인정보 처리와 관련한 정보주체의 불만처리 및 피해구제 등을 위하여 아래와 같이 개인정보 보호책임자를 지정하고 있습니다.<br />\r\n<br />\r\n▶ 개인정보 보호책임자<br />\r\n성명 :<br />\r\n연락처 :<br />\r\n<br />\r\n② 정보주체께서는 ALECBOARDV2보드(&lsquo;http://ALECBOARDV2.com&rsquo;이하 &lsquo;ALECBOARDV2보드) 의 서비스(또는 사업)을 이용하시면서 발생한 모든 개인정보 보호 관련 문의, 불만처리, 피해구제 등에 관한 사항을 개인정보 보호책임자 및 담당부서로 문의하실 수 있습니다. ALECBOARDV2보드(&lsquo;http://ALECBOARDV2.com&rsquo;이하 &lsquo;ALECBOARDV2보드) 은(는) 정보주체의 문의에 대해 지체 없이 답변 및 처리해드릴 것입니다.<br />\r\n<br />\r\n<strong>9. 개인정보 처리방침 변경&nbsp;</strong><br />\r\n①이 개인정보처리방침은 시행일로부터 적용되며, 법령 및 방침에 따른 변경내용의 추가, 삭제 및 정정이 있는 경우에는 변경사항의 시행 7일 전부터 공지사항을 통하여 고지할 것입니다.')");

    // 회사소개
    $dbcon->query(
        "INSERT INTO {$_table['setup']} 
				(ss_num, ss_name, ss_content)
				VALUES (7,'page_company','<strong>▣ ALECBOARDV2보드제작사의 소개 내용이며 ALECBOARDV2보드를 다운받아 사용할경우 아래 내용을 수정하셔서 사용해주시기 바랍니다. </strong><br />\r\n&nbsp;&nbsp;▣ 회사개요\r\n<ul>\r\n</ul>\r\n&nbsp;&nbsp;▣ 사업영역\r\n\r\n<ul>\r\n	<li>도메인 포워딩<br />\r\n	인터넷 방송국<br />\r\n	응용프로그램 개발<br />\r\n	웹프로그램 개발<br />\r\n	웹호스팅<br />\r\n	전자상거래 및 중개</li>\r\n</ul>\r\n&nbsp;&nbsp;▣ 연혁\r\n\r\n<ul>\r\n	<li>2000년 10월 2차 도메인 포워딩솔루션 개발<br />\r\n	2001년 3월 DDNS솔루션 개발<br />\r\n	2001년 8월 DVR과 DDNS연계, 리눅스용 DDNS클라이언트 개발<br />\r\n	2001년 11월 윈엠프 방송국을 위한 포트자동등록, 관리시스템 개발<br />\r\n	2002년 9월 DDNS클라이언트 윈도우용 개발<br />\r\n	2002년 11월 웹호스팅 서비스개시<br />\r\n	2002년 11월 2차도메인 무제한 서비스 개시<br />\r\n	2003년 4월 낙장도메인 자동등록기 개발<br />\r\n	2003년 5월 시작페이지 자동생성 솔루션 개발<br />\r\n	2003년 7월 무료공개 게시판 ALECBOARDV2보드제작배포(http://ALECBOARDV2.com)<br />\r\n	그외의 다수의 프로그램 개발 및 제작</li>\r\n</ul>\r\n')");


    // 게시판 공지사항 추가
    $list_cfg=array();
    $write_cfg=array();
    $reply_cfg=array();
    $view_cfg=array();
    $list_cfg["list_count"] = "20";
    $list_cfg["new_time"] = "24";
    $list_cfg["subject_limit"] = "60";
    $list_cfg["page_count"] = "10";
    $list_cfg["date_format"] = "%Y-%m-%d";
    $list_cfg["use_mb_icon"] = "0";
    $list_cfg["col_cnt"] = "4";
    $list_cfg["img_width"] = "150";
    $list_cfg["img_height"] = "150";

    $write_cfg["use_notice"] = "90";
    $write_cfg["use_html"] = "0";
    $write_cfg["use_secret"] = "100";
    $write_cfg["use_home"] = "0";
    $write_cfg["use_link"] = "100";
    $write_cfg["link_count"] = "2";
    $write_cfg["use_upload"] = "90";
    $write_cfg["upload_count"] = "2";
    $write_cfg["use_editor"] = "0";
    $write_cfg["use_syntaxhighlight"] = "0";
    $write_cfg["writer_name"] = "3";
    $write_cfg["writer_modify"] = "100";
    $write_cfg["spam_chk"] = "1";
    $write_cfg["write_deny_time"] = "5";
    $write_cfg["use_reply_mail"] = "0";
    $write_cfg["reply_delete"] = "4";

    $reply_cfg["subject_prefix"] = "[답변]";
    $reply_cfg["quote_use"] = "1";
    $reply_cfg["quote_subject"] = "{NAME} 님의 글입니다.";
    $reply_cfg["quote_mark"] = ">";

    $view_cfg["view_comment"] = "0";
    $view_cfg["view_image"] = "0";
    $view_cfg["use_download"] = "0";
    $view_cfg["view_signature"] = "0";
    $view_cfg["view_list"] = "0";
    $view_cfg["btn_list"] = "0";
    $view_cfg["btn_prev_next"] = "0";
    $view_cfg["btn_modify"] = "90";
    $view_cfg["btn_del"] = "90";
    $view_cfg["btn_reply"] = "100";
    $view_cfg["vote_yes"] = "100";
    $view_cfg["vote_no"] = "100";
    $view_cfg["date_format"] = "%Y-%m-%d %H:%M:%S";
    $view_cfg["c_date_format"] = "%Y-%m-%d %H:%M:%S";

    $list_cfg = serialize($list_cfg);
    $write_cfg = serialize($write_cfg);
    $reply_cfg = serialize($reply_cfg);
    $view_cfg = serialize($view_cfg);

    $dbcon->query(
        "INSERT INTO {$_table['bbs_cfg']}
					(bbs_num, bbs_code, bbs_db, bbs_db_num, gr_num, bbs_name, bbs_skin,
					use_category, default_content, auth_list, auth_view, auth_write,
					auth_reply, auth_modify, auth_delete, auth_comment, auth_secret,
					list_cfg, write_cfg, reply_cfg, view_cfg, mailing_mb_id, admin_mb_id,
					point_write, point_reply, point_comment, header_file, header_tag,
					footer_tag, footer_file, reg_date, bbs_ext1, bbs_ext2, bbs_ext3,
					bbs_ext4, bbs_ext5, admin_memo, deny_word, deny_html, deny_ip,
					m_bbs_skin
					)
				VALUES
(1,'notice','notice',1,1,'공지사항','default',0,'',0,0,90,100,90,90,100,100,'$list_cfg','$write_cfg','$reply_cfg','$view_cfg','','',0,0,0,'','','','',".time().",'','','','','','','8억,새끼,개새끼,소새끼,병신,지랄,씨팔,십팔,니기미,찌랄,지랄,쌍년,쌍놈,빙신,좆까,니기미,좆같은게,잡놈,벼엉신,바보새끼,씹새끼,씨발,씨팔,시벌,씨벌,떠그랄,좆밥,추천인,추천id,추천아이디,추천id,추천아이디,추/천/인,쉐이,등신,싸가지,미친놈,미친넘,찌랄,죽습니다,님아,님들아,씨밸넘','script,xml','','default_mobile')");
    unset($list_cfg);
    unset($write_cfg);
    unset($reply_cfg);
    unset($view_cfg);

    // 게시판 자유게시판 추가
    $list_cfg=array();
    $write_cfg=array();
    $reply_cfg=array();
    $view_cfg=array();
    $list_cfg["list_count"] = "20";
    $list_cfg["new_time"] = "24";
    $list_cfg["subject_limit"] = "60";
    $list_cfg["page_count"] = "10";
    $list_cfg["date_format"] = "%Y-%m-%d";
    $list_cfg["use_mb_icon"] = "0";
    $list_cfg["col_cnt"] = "4";
    $list_cfg["img_width"] = "150";
    $list_cfg["img_height"] = "150";

    $write_cfg["use_notice"] = "90";
    $write_cfg["use_html"] = "0";
    $write_cfg["use_secret"] = "100";
    $write_cfg["use_home"] = "0";
    $write_cfg["use_link"] = "100";
    $write_cfg["link_count"] = "2";
    $write_cfg["use_upload"] = "100";
    $write_cfg["upload_count"] = "2";
    $write_cfg["use_editor"] = "0";
    $write_cfg["use_syntaxhighlight"] = "0";
    $write_cfg["writer_name"] = "3";
    $write_cfg["writer_modify"] = "100";
    $write_cfg["spam_chk"] = "1";
    $write_cfg["write_deny_time"] = "5";
    $write_cfg["use_reply_mail"] = "0";
    $write_cfg["reply_delete"] = "4";

    $reply_cfg["subject_prefix"] = "[답변]";
    $reply_cfg["quote_use"] = "1";
    $reply_cfg["quote_subject"] = "{NAME} 님의 글입니다.";
    $reply_cfg["quote_mark"] = ">";

    $view_cfg["view_comment"] = "0";
    $view_cfg["view_image"] = "0";
    $view_cfg["use_download"] = "0";
    $view_cfg["view_signature"] = "0";
    $view_cfg["view_list"] = "0";
    $view_cfg["btn_list"] = "0";
    $view_cfg["btn_prev_next"] = "0";
    $view_cfg["btn_modify"] = "0";
    $view_cfg["btn_del"] = "0";
    $view_cfg["btn_reply"] = "100";
    $view_cfg["vote_yes"] = "100";
    $view_cfg["vote_no"] = "100";
    $view_cfg["date_format"] = "%Y-%m-%d %H:%M:%S";
    $view_cfg["c_date_format"] = "%Y-%m-%d %H:%M:%S";

    $list_cfg = serialize($list_cfg);
    $write_cfg = serialize($write_cfg);
    $reply_cfg = serialize($reply_cfg);
    $view_cfg = serialize($view_cfg);
    $dbcon->query(
        "INSERT INTO {$_table['bbs_cfg']}
					(bbs_num, bbs_code, bbs_db, bbs_db_num, gr_num, bbs_name, bbs_skin,
					use_category, default_content, auth_list, auth_view, auth_write,
					auth_reply, auth_modify, auth_delete, auth_comment, auth_secret,
					list_cfg, write_cfg, reply_cfg, view_cfg, mailing_mb_id, admin_mb_id,
					point_write, point_reply, point_comment, header_file, header_tag,
					footer_tag, footer_file, reg_date, bbs_ext1, bbs_ext2, bbs_ext3,
					bbs_ext4, bbs_ext5, admin_memo, deny_word, deny_html, deny_ip,
					m_bbs_skin)
				VALUES				(2,'free','free',2,1,'자유게시판','default',1,'',0,0,0,100,0,0,0,50,'$list_cfg','$write_cfg','$reply_cfg','$view_cfg','','',1,1,1,'','','','',".time().",'','','','','','','8억,새끼,개새끼,소새끼,병신,지랄,씨팔,십팔,니기미,찌랄,지랄,쌍년,쌍놈,빙신,좆까,니기미,좆같은게,잡놈,벼엉신,바보새끼,씹새끼,씨발,씨팔,시벌,씨벌,떠그랄,좆밥,추천인,추천id,추천아이디,추천id,추천아이디,추/천/인,쉐이,등신,싸가지,미친놈,미친넘,찌랄,죽습니다,님아,님들아,씨밸넘','script,xml','','default_mobile')");
    unset($list_cfg);
    unset($write_cfg);
    unset($reply_cfg);
    unset($view_cfg);

    $dbcon->query(
        "INSERT INTO {$_table['bbs_category']}
					(cat_num, bbs_db_num, cat_order, cat_name, cat_count)
				VALUES
					(1,2,1,'질문',0)");
    $dbcon->query(
        "INSERT INTO {$_table['bbs_category']}
					(cat_num, bbs_db_num, cat_order, cat_name, cat_count)
				VALUES
					(2,2,2,'답변',0)");
    $dbcon->query(
        "INSERT INTO {$_table['bbs_category']}
					(cat_num, bbs_db_num, cat_order, cat_name, cat_count)
				VALUES					
					(3,2,3,'잡담',0)");


    // 게시판 갤러리 추가
    $list_cfg=array();
    $write_cfg=array();
    $reply_cfg=array();
    $view_cfg=array();
    $list_cfg["list_count"] = "20";
    $list_cfg["new_time"] = "24";
    $list_cfg["subject_limit"] = "60";
    $list_cfg["page_count"] = "10";
    $list_cfg["date_format"] = "%Y-%m-%d";
    $list_cfg["use_mb_icon"] = "0";
    $list_cfg["col_cnt"] = "4";
    $list_cfg["img_width"] = "150";
    $list_cfg["img_height"] = "150";

    $write_cfg["use_notice"] = "90";
    $write_cfg["use_html"] = "0";
    $write_cfg["use_secret"] = "100";
    $write_cfg["use_home"] = "0";
    $write_cfg["use_link"] = "100";
    $write_cfg["link_count"] = "2";
    $write_cfg["use_upload"] = "1";
    $write_cfg["upload_count"] = "2";
    $write_cfg["use_editor"] = "0";
    $write_cfg["use_syntaxhighlight"] = "100";
    $write_cfg["writer_name"] = "3";
    $write_cfg["writer_modify"] = "100";
    $write_cfg["spam_chk"] = "1";
    $write_cfg["write_deny_time"] = "5";
    $write_cfg["use_reply_mail"] = "0";
    $write_cfg["reply_delete"] = "4";

    $reply_cfg["subject_prefix"] = "[답변]";
    $reply_cfg["quote_use"] = "1";
    $reply_cfg["quote_subject"] = "{NAME} 님의 글입니다.";
    $reply_cfg["quote_mark"] = ">";

    $view_cfg["view_comment"] = "0";
    $view_cfg["view_image"] = "0";
    $view_cfg["use_download"] = "0";
    $view_cfg["view_signature"] = "0";
    $view_cfg["view_list"] = "0";
    $view_cfg["btn_list"] = "0";
    $view_cfg["btn_prev_next"] = "0";
    $view_cfg["btn_modify"] = "1";
    $view_cfg["btn_del"] = "1";
    $view_cfg["btn_reply"] = "100";
    $view_cfg["vote_yes"] = "100";
    $view_cfg["vote_no"] = "100";
    $view_cfg["date_format"] = "%Y-%m-%d %H:%M:%S";
    $view_cfg["c_date_format"] = "%Y-%m-%d %H:%M:%S";

    $list_cfg = serialize($list_cfg);
    $write_cfg = serialize($write_cfg);
    $reply_cfg = serialize($reply_cfg);
    $view_cfg = serialize($view_cfg);
    $dbcon->query(
        "INSERT INTO {$_table['bbs_cfg']}
					(bbs_num, bbs_code, bbs_db, bbs_db_num, gr_num, bbs_name, bbs_skin,
					use_category, default_content, auth_list, auth_view, auth_write,
					auth_reply, auth_modify, auth_delete, auth_comment, auth_secret,
					list_cfg, write_cfg, reply_cfg, view_cfg, mailing_mb_id, admin_mb_id,
					point_write, point_reply, point_comment, header_file, header_tag,
					footer_tag, footer_file, reg_date, bbs_ext1, bbs_ext2, bbs_ext3,
					bbs_ext4, bbs_ext5, admin_memo, deny_word, deny_html, deny_ip,
					m_bbs_skin)
				VALUES				(3,'gallery','gallery',3,1,'갤러리','gallery_thumbnail',0,'',0,0,1,100,1,1,1,50,'$list_cfg','$write_cfg','$reply_cfg','$view_cfg','','',1,1,1,'','','','',".time().",'','','','','','','8억,새끼,개새끼,소새끼,병신,지랄,씨팔,십팔,니기미,찌랄,지랄,쌍년,쌍놈,빙신,좆까,니기미,좆같은게,잡놈,벼엉신,바보새끼,씹새끼,씨발,씨팔,시벌,씨벌,떠그랄,좆밥,추천인,추천id,추천아이디,추천id,추천아이디,추/천/인,쉐이,등신,싸가지,미친놈,미친넘,찌랄,죽습니다,님아,님들아,씨밸넘','script,xml','','gallery_thumb_mobile')");
    unset($list_cfg);
    unset($write_cfg);
    unset($reply_cfg);
    unset($view_cfg);

    // 공통코드저장
    $dbcon->query(
        "INSERT INTO {$_table['comm_code']}
					(cd_num,cd_type1, cd_type2, cd_code, cd_name, cd_ord, cd_data1, cd_data2)
				VALUES
					(1,'comm', 'yns', 'Y', '예', 1, '사용', '')");
    $dbcon->query(
        "INSERT INTO {$_table['comm_code']}
					(cd_num,cd_type1, cd_type2, cd_code, cd_name, cd_ord, cd_data1, cd_data2)
				VALUES
					(2,'comm', 'yns', 'N', '아니요', 2, '사용안함', '')");
    $dbcon->query(
        "INSERT INTO {$_table['comm_code']}
					(cd_num,cd_type1, cd_type2, cd_code, cd_name, cd_ord, cd_data1, cd_data2)
				VALUES
					(3,'popup', 'win_type', '01', '일반팝업', 0, '', '')");
    $dbcon->query(
        "INSERT INTO {$_table['comm_code']}
					(cd_num,cd_type1, cd_type2, cd_code, cd_name, cd_ord, cd_data1, cd_data2)
				VALUES
					(4,'popup', 'win_type', '02', '레이어팝업', 0, '', '')");
    $dbcon->query(
        "INSERT INTO {$_table['comm_code']}
					(cd_num,cd_type1, cd_type2, cd_code, cd_name, cd_ord, cd_data1, cd_data2)
				VALUES
					(5,'popup', 'cont_type', '01', '이미지업로드', 0, '', '')");
    $dbcon->query(
        "INSERT INTO {$_table['comm_code']}
					(cd_num,cd_type1, cd_type2, cd_code, cd_name, cd_ord, cd_data1, cd_data2)
				VALUES
					(6,'popup', 'cont_type', '02', 'html링크', 0, '', '')");
    $dbcon->query(
        "INSERT INTO {$_table['comm_code']}
					(cd_num,cd_type1, cd_type2, cd_code, cd_name, cd_ord, cd_data1, cd_data2)
				VALUES
					(7,'popup', 'cont_type', '03', 'html직접입력', 0, '', '')");

    // db정보저장		
    $fp = fopen($_path['data'].'db_info.php', "wb");
    if(!$fp) {
        $msg="
데이터베이스 정보를 저장할수 없습니다.<br>
서버관리자에게 문의해주세요.<br>
";
        include("../include/error.inc.php");
    }
    $dbcfg="<"."?
echo \"<script>alert('잘못된 접근입니다.(ALECBOARDV2보드로 ...)');location='http://ALECBOARDV2.com'</script>\";exit;
//$db_host
//$db_user
//$db_password
//$db_database_name
//$db_type
//$db_port
?".">		
";
    if(!fputs($fp, $dbcfg)) {
        $msg="
데이터베이스 정보를 저장할수 없습니다.<br>
서버관리자에게 문의해주세요.<br>
";
        include("../include/error.inc.php");
    }
    fclose($fp);

    // 기본 데이터디렉토리 설정
    @mkdir($_path['member_data']);
    @chmod($_path['member_data'],0707);

    @mkdir($_path['bbs_data']);
    @chmod($_path['bbs_data'],0707);

    @mkdir($_path['session']);
    @chmod($_path['session'],0707);

    @mkdir($_path['popup']);
    @chmod($_path['popup'],0707);

    @mkdir($_path['data'].'editor/');
    @chmod($_path['data'].'editor/',0707);

    @mkdir($_path['data'].'tmp/');
    @chmod($_path['data'].'tmp/',0707);

    @mkdir($_path['bbs_thumb']);
    @chmod($_path['bbs_thumb'],0707);

    $dbcon->commit();
    rg_href('install_1.php');
}
?>
<? include("../include/header_win.php"); ?>
    <script language="javascript">
        var db_dport= new Array();
        <? foreach($_const['db_type'] as $v) { ?>
        db_dport['<?=$v['code']?>']='<?=$v['default_port']?>';
        <? } ?>
    </script>
    <body>
    <div style="margin:0 auto;width:500px">
        <form name="form1" method="post" action="">
            <input name="act" type="hidden" value="ok">
            <br>
            <br>
            <br>
            <table border="0" width="500" cellspacing="0" cellpadding="0" class="site_content" align="center">
                <tr>
                    <td align="center">ALECBOARDV2 데이터베이스 정보 입력 </td>
                </tr>
            </table>
            <br>
            <table border="0" cellpadding="0" cellspacing="0" width="500" class="site_content" align="center">
                <tr>
                    <td height="24" align="right" bgcolor="#F7F7F7">사용db :&nbsp;</td>
                    <td><select name="db_type" class="input" id="db_type" required itemname="db type" onChange="form1.db_port.value=db_dport[this.value]">
                            <?=rg_html_option($_const['db_type'],"MYSQL",'code','hname')?>
                        </select>
                        <font color="#FF0000"> db형태</font></td>
                </tr>
                <tr>
                    <td height="24" align="right" bgcolor="#F7F7F7">Port :&nbsp;</td>
                    <td><input name="db_port" type="text" id="db_port" value="3306" required itemname="Port">
                        <font color="#FF0000"> 접속포트</font></td>
                </tr>
                <tr>
                    <td height="24" align="right" bgcolor="#F7F7F7">Host Name :&nbsp;</td>
                    <td><input name="db_host" type="text" id="db__host" value="localhost" required itemname="Host Name">
                        <font color="#FF0000"> 호스트 명</font></td>
                </tr>
                <tr>
                    <td width="150" height="24" align="right" bgcolor="#F7F7F7">User ID :&nbsp;</td>
                    <td><input name="db_user" type="text" id="db_user" required itemname="User ID">
                        <font color="#FF0000"> 접속 사용자명</font></td>
                </tr>
                <tr>
                    <td height="24" align="right" bgcolor="#F7F7F7">User Password :&nbsp;</td>
                    <td><input name="db_password" type="password" id="db_password" required itemname="User Password">
                        <font color="#FF0000"> 사용자 암호</font></td>
                </tr>
                <tr>
                    <td height="24" align="right" bgcolor="#F7F7F7">DB Name :&nbsp;</td>
                    <td><input name="db_database_name" type="text" id="db_database_name" required itemname="DB Name">
                        <font color="#FF0000"> 사용데이터베이스명</font></td>
                </tr>
            </table>
            <br>
            <center>
                <input type="submit" class="button1" value=" 확  인 ">
            </center>
        </form>
    </div>
    </body>
<? include("../include/footer_win.php"); ?>