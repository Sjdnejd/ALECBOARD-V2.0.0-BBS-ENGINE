<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$_const['charset']?>" />
<title></title>
</head>
<body>
<table width="400" align="center" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
		<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td height="3" bgcolor="#54A8BA"><img width="1" height="1"></td>
			</tr>
			<tr>
				<td height="28" bgcolor="#F4FAFB">&nbsp;회원아이디조회결과</td>
			</tr>
			<tr>
				<td height="1" bgcolor="#54A8BA"><img width="1" height="1"></td>
			</tr>
		</table>
		<table width="100%" align="center" border="0" cellpadding="0" cellspacing="6">
			<tr>
			  <td align="center">입력하신 정보와 일치하는  아이디 입니다. </td>
			  </tr>
			<tr>
				<td height="1" bgcolor="#ECECEC"><img width="1" height="1"></td>
				</tr>
			<tr>
			  <td align="center"><font style="font-size:8px">◆</font> <?=$mb_id?></td>
			  </tr>
		</table>
		<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td height="1" bgcolor="#54A8BA"><img width="1" height="1"></td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</body>
</html>