<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	if($sns_name=='') {
		exit;
	}
	if(trim($id)=='' || trim($data1)=='') {
		rg_href('',"$sns_name 로그인중 오류가 발생했습니다.",'close');
	}
	if(!rg_verify_token($token)) {
		rg_href('','정상적인 접근이 아닙니다.\n\n새로고침후 다시 시도해보세요.','close');
	}

	$result = array();
	$rs=new $rs_class($dbcon);
	$sns_data = rg_db_data_one($_table['member_sns'],"gubun_cd='$gubun_cd' AND id='$id'");
	if($sns_data) {
		$rs->clear();
		$rs->set_table($_table['member_sns']);
		$rs->add_field("name","$name"); // sns로그인이름
		$rs->add_field("data1","$data1"); // 데이터1
		$rs->add_field("data2","$data2"); // 데이터2
		$rs->add_field("login_date",time()); // 접속일시
		$rs->add_field("login_ip",$_SERVER['REMOTE_ADDR']); // 접속아이피
		$rs->add_where("num='$sns_data[num]'");
		$rs->update();
	} else {
		$rs->clear();
		$rs->set_table($_table['member_sns']);
		$rs->add_field("gubun_cd","$gubun_cd"); // sns구분
		$rs->add_field("id","$id"); // sns로그인아이디
		$rs->add_field("name","$name"); // sns로그인이름
		$rs->add_field("data1","$data1"); // 데이터1
		$rs->add_field("data2","$data2"); // 데이터2
		$rs->add_field("login_date",time()); // 접속일시
		$rs->add_field("login_ip",$_SERVER['REMOTE_ADDR']); // 접속아이피
		$rs->add_field("join_date",time()); // 등록일시
		$rs->add_field("join_ip",$_SERVER['REMOTE_ADDR']); // 등록아이피
		$rs->insert();
		$sns_data['num']=$rs->get_insert_id();
	}
	
	if($_mb) { // 로그인 상태면
		if($sns_data['mb_num'] != $_mb['mb_num']) { // 다른 아이디로 연결되 있으면 바꾼다.
			// 기존연결 끊기
			$rs->clear();
			$rs->set_table($_table['member_sns']);
			$rs->add_where("gubun_cd='$gubun_cd'");
			$rs->add_where("mb_num='$_mb[mb_num]'");
			$rs->delete();
			
			$rs->clear();
			$rs->set_table($_table['member_sns']);
			$rs->add_field("mb_num","$_mb[mb_num]"); // 로그인된 회원과 연결
			$rs->add_where("num='$sns_data[num]'");
			$rs->update();
		}
		unset($_SESSION['OAUTH_STATE']);
		unset($_SESSION['OAUTH_ACCESS_TOKEN']);
//		$result['result']='success';
//		return $result;// 회원연결성공
		rg_href($_url['member'].'modify_form.php',"{$sns_name}의 계정 {$name}으로 로그인 연결 되었습니다.",'close','opener');
	} else { // 로그인전이면
		if($sns_data['mb_num']>0) { // 로그인처리
			$data = rg_db_data_one($_table['member'],"mb_num='{$sns_data['mb_num']}'");
			switch($data['mb_state']) {
				case 1 : // 승인된 아이디
					$result['result']='login';
					break;
				case '0' : 
					$result['result']='failure';
					$result['msg']='승인대기중입니다.';
					break;
				case '2' : 
					$result['result']='failure';
					$result['msg']='미승인된 아이디 입니다..';
					break;
				case '3' : // 탈퇴된 아이디는 재가입의 기회를 줘야한다.
					$result['result']='';
					$result['msg']='';
					break;
				default :
					$result['result']='failure';
					$result['msg']='알수없는 오류 관리자에게 연락 바랍니다.';
					break;
			}
			// 실패면 종료
			if($result['result']=='failure') {
				unset($_SESSION['OAUTH_STATE']);
				unset($_SESSION['OAUTH_ACCESS_TOKEN']);
				rg_href($site_url,$result['msg'],'close','opener');
			}
			if($result['result']=='login') {
				$login_date=time();
				$rs->clear();
				$rs->set_table($_table['member']);
				$rs->add_field("login_count",$data['login_count']+1);
				$rs->add_field("login_date",$login_date);
				$rs->add_field("login_ip",$_SERVER['REMOTE_ADDR']);
				$rs->add_where("mb_num={$data['mb_num']}");
				$rs->update();
				$data['login_date']=$login_date;
				
				// 지난 로그인 날자와 현재 로그인 날자가 다르다면 로그인 포인트 올린다. 
				if(floor($data['login_date']/86400) < floor(time()/86400))
					rg_set_point($data['mb_num'],$_po_type_code['etc'],
										$_site_info['login_point'],'로그인','로그인포인트','');
					
				$ss_mb_id = $data['mb_id'];
				$ss_mb_num = $data['mb_num'];
				$ss_login_ok = 'ok';

				$_SESSION['ss_mb_id']=$ss_mb_id;
				$_SESSION['ss_mb_num']=$ss_mb_num;
				$_SESSION['ss_login_ok']=$ss_login_ok;
				rg_set_login_hash($data);

				unset($_SESSION['OAUTH_STATE']);
				unset($_SESSION['OAUTH_ACCESS_TOKEN']);
				$rs->commit();
				$result['result']='success';
				rg_href($site_url,$result['msg'],'close','opener');
			}
		}
		// 로그인도 되있지 않고 연결된 계정도 없으면 아이디,이름만 입력받아 가입시킨다.
		// 가입을 시키기 위해서 세션에 임시로 데이터 저장
		$_SESSION['SNS_BIND_DATA']="$gubun_cd||$sns_data[num]||$id";
?>
<script language="javascript">
if(confirm("가입되있지 않은 SNS계정입니다.\n가입을 하시려면 확인을 \n기존계정에 연결을 하시려면 취소를 눌러주세요.")) {
	opener.location.replace('<?=$_path['member']?>join.php?from=sns');
} else {
	opener.location.replace('<?=$_path['member']?>login.php?from=sns');
}
self.close();
</script>
<?
		exit;
		rg_href($_path['member']."join.php?from=sns","가입되있지 않은 SNS계정입니다.\n가입후 이용가능합니다.",'close','opener');
	}

?>