<?
	$site_path='./';
	$site_url='./';
	ob_start();
	include_once($site_path."alec2_include/lib.php");
	ob_end_clean();
/*
	$LastModified = gmdate("D d M Y H:i:s", filemtime($_SERVER['SCRIPT_FILENAME'])); 
	header("Last-Modified: $LastModified GMT");
	header("ETag: \"$LastModified\""); */
	
	if($_site_mode=='mobile') {
		$index_url='m/index.php';
	} else {
		$index_url='main/index.php';
	}
	header("Location: $index_url"); 
?>
<html>
<head>
<title><?=$_site_info['site_name']?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$_const['charset']?>">
</head>
<body alink="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" text="#FFFFFF" onLoad="location.href='<?=$index_url?>'" bgcolor="#FFFFFF">
<a href="<?=$index_url?>">메인화면으로</a>
</body>
</html>
