<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	$_list_cfg['img_width'] = round($_list_cfg['img_width']*0.5);
	$_list_cfg['img_height'] = round($_list_cfg['img_height']*0.5);
?>
<div id="bbs_default">