<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
/* =====================================================
 프로그램명 : ALECBOARDV2 V4 게시판스킨

파일설명 : 글작성

변수설명
$mode : 글작성모드(write,modify,replay)
$bd_num : 글수정,답변글 일 경우 글번호
$old_pass : 글수정시 원래 암호
$wcfg['use_notice'] : 공지사항
$wcfg['use_secret'] : 비밀글
$wcfg['use_reply_mail'] : 응답글
$wcfg['input_name'] : 이름입력여부
$wcfg['input_pass'] : 암호입력여부
$wcfg['input_email'] : 이메일입력여부
$wcfg['use_home'] : 홈페이지
$wcfg['use_category'] : 카테고리
$wcfg['use_html'] : html사용
$wcfg['use_link'] : 링크사용
$wcfg['use_upload'] : 업로드
$vcfg['spam_chk'] : 스팸체크여부
$spam_chk_img : 스팸이미지
$spam_chk_code : 스팸체크코드(현재는고정)
===================================================== */
	if($wcfg['use_editor'] && $bd_html != '1') 
		$bd_content = rg_conv_text($bd_content,$bd_html);
?>
	<div> * 
<?
	switch($mode) {
		case 'write' :
?>글등록<?
		break;
		case 'reply' :
?>답변글<?
		break;
		case 'modify' :
?>글수정<?
		break;
	}
?>
	</div>
<form name="write_form" method="post" action="?<?=$_get_param[3]?>" onSubmit="return write_form_chk(this);" enctype="multipart/form-data">
<input type="hidden" name="mode" value="<?=$mode?>">
<input type="hidden" name="act" value="ok">
<input type="hidden" name="bd_num" value="<?=$bd_num?>">
<input type="hidden" name="old_pass" value="<?=$old_pass?>">
<input type="hidden" name="token" value="<?=$token?>">
<div class="bbs_write">
	<div>
<ul class="write_form">
<? if($wcfg['use_notice'] || $wcfg['use_secret'] || $wcfg['use_reply_mail']) { ?>
	<li>
	<span class="wtitle">옵션</span>
	<label>
		<? if($wcfg['use_notice']) { ?><input type="checkbox" name="bd_notice" value="1" <?=$chk_bd_notice?>> 공지사항&nbsp;&nbsp;<? } ?>
	</label>
	<label>
		<? if($wcfg['use_secret']) { ?><input type="checkbox" name="bd_secret" value="1" <?=$chk_bd_secret?>> 비밀글&nbsp;&nbsp;<? } ?>
	</label>
	<label>
		<? if($wcfg['use_reply_mail']) { ?><input type="checkbox" name="bd_reply_mail" value="1" <?=$chk_bd_reply_mail?>> 답변메일수신&nbsp;&nbsp;<? } ?>
	</label>
	</li>
<? } ?>
<? if($wcfg['input_name']) { ?>
	<li>
	<label><span class="wtitle">작성자</span>
		<input name="bd_name" type="text" value="<?=$bd_name?>" class="input" required hname="작성자">
	</label>
	</li>
<? } ?>
<? if($wcfg['input_pass']) { ?>
	<li>
	<label><span class="wtitle">암호</span>
		<input name="bd_pass" type="password" value="" class="input">
	</label>
	</li>
<? } ?>
<? if($wcfg['input_email']) { ?>
	<li>
	<label><span class="wtitle">이메일</span>
		<input name="bd_email" type="text" class="input" value="<?=$bd_email?>" size="40">
	</label>
	</li>
<? } ?>
<? if($wcfg['use_home']) { ?>
	<li>
	<label><span class="wtitle">홈페이지</span>
		<input name="bd_home" type="text" class="input" value="<?=$bd_home?>" size="60">
	</label>
	</li>
<? } ?>
<? if($wcfg['use_category']) { ?>
	<li>
	<label><span class="wtitle">분류</span>
		<select name="cat_num">
<option value="">==선택==</option>
<?=rg_html_option($_category_info,$cat_num,'cat_num','cat_name')?>
</select>
	</label>
	</li>
<? } ?>
	<li>
	<label><span class="wtitle">제목</span>
		<input name="bd_subject" type="text" class="input" value="<?=$bd_subject?>" size="60" required hname="제목">
	</label>
	</li>
<? if($wcfg['use_html']) { ?>
	<li>
	<span class="wtitle">HTML</span>
		<label><input type="radio" name="bd_html" value="0" <?=$chk_bd_html[0]?>>사용안함&nbsp;&nbsp;</label>
		<label><input type="radio" name="bd_html" value="1" <?=$chk_bd_html[1]?>>HTML사용&nbsp;&nbsp;</label>
		<label><input type="radio" name="bd_html" value="2" <?=$chk_bd_html[2]?>>HTML+&lt;BR&gt;</label>
	</li>
<? } ?>
	<li>
	<label>
		<textarea name="bd_content" cols="60" rows="20" required hname="내용" style="width:99%"><?=$bd_content?></textarea>
	</label>
	</li>
<?
	if($wcfg['use_link']) { 
		for($i=0;$i<$wcfg['link_count'];$i++) {
?>
	<li>
	<span class="wtitle">링크 #<?=($i+1)?></span>
	<label>이름 : <input name="bd_links[<?=$i?>][name]" type="text" class="input" value="<?=$bd_links[$i]['name']?>" size="60"></label>
	<label>URL : <input name="bd_links[<?=$i?>][url]" type="text" class="input" value="<?=$bd_links[$i]['url']?>" size="60"></label>
	</li>
<?
		}
	}
?>
<?
	if($wcfg['use_upload']) {
		for($i=0;$i<$wcfg['upload_count'];$i++) {
?>
	<li>
		<span class="wtitle" style="float:left;line-height:40px;">첨부파일 #<?=($i+1)?></span>
		<span style="float:left;margin-bottom:7px"><input type="file" name="bd_files[<?=$i?>]" class="input" size="40">
		<? if($bd_files[$i][name]!='') { ?>
		<label><?=$bd_files[$i][name]?>
		<input type="checkbox" name="bd_files_del[<?=$i?>]" value="1" />
		삭제</label>
		<? } ?>
		</span>
	</li>
<?
		}
	}
?>
<? if($wcfg['spam_chk']) { ?>
	<li>
	<input name="spam_chk_code" type="hidden" value="<?=$spam_chk_code?>">	
	<label><span class="wtitle">스팸방지</span>
	<?=$spam_chk_img?> 좌측의 문자를 입력해주세요.

		<input name="spam_chk" type="text" class="input" size="10" required hname="스팸방지코드">
	</label>
	</li>
<? } ?>
</ul>
</div>
</div>

<div style="clear:both;padding:10px;text-align:center">
		<button type="submit" class="sbtn"><i class="fa fa-pencil"></i> 
<?
	switch($mode) {
		case 'reply' :
		case 'write' : echo " 등 록 "; break;
		case 'modify' :
		case 'write' : echo " 수 정 "; break;
	}
?></button>
&nbsp;
		<button type="button" class="sbtn" onClick="history.back();"><i class="fa fa-ban"></i>  취 소 </button>
</div>
</form>
<? if($wcfg['use_editor']) { ?>
<script src="<?=$_url['site']?>ckeditor/ckeditor.js"></script>
<script>
	CKEDITOR.replace( 'bd_content',
		{
			height: '400px',
			customConfig: '<?=$_url['bbs']?>ckeditor_config.php?bbs_code=<?=$bbs_code?>'
		}
	);
</script>
<? } ?>
<script>
function write_form_chk(f) {
<? if($wcfg['use_editor']) { ?>
	if(CKEDITOR.instances.bd_content.getData().trim() == '') {
		alert('내용을 입력해주세요.');
		CKEDITOR.instances.bd_content.focus();
		return false;
	}
<? } ?>
	return validate(f);
}
</script>