<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	// 설정파일
	$new_time=24; // new 아이콘이 달릴 시간
	$skin_new_icon = " <font color=red style=font-size:8pt>new</font>"; // new 아이콘
	$skin_comment_cnt = " <font color=blue style=font-size:8pt>[{cnt}]</font>"; // 코멘트 갯수
	$date_format="%Y.%m.%d"; // 보여줄 날자 형식
?>