<?
	for(;$li % $list_col > 0;) {
?>
<? if($li % $list_col == 0) echo "<tr>"; ?>
      <td width="<?=(1/$list_col)*100?>%"></td>
<? if($li % $list_col == ($list_col-1))  echo "</tr>"; ?>
<? $li++; ?>
<?
	}
?>
</table>
</div>