<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	/*
	$view_url : 글보기 링크
	$bd_name : 작성자명
	$bd_subject : 제목
	$i_comment_count : 코멘트 갯수
	$i_new : 새글 아이콘
	$bd_write_date : 작성일
	
	$first_img : 첫번째 이미지 정보(배열)
	$img_view_url : 첫번째 이미지 경로
	$img_width : 이미지 넓이
	$img_height : 이미지 높이
	*/
	list($old_width, $old_height) = getimagesize($_path['bbs_data'].$first_img['sname']);

	// 이미지 비율을 계산한다.
	if($img_height < $old_height || $img_width < $old_width) {
		$new_height = $img_height;
		$new_width = $img_width;
		if(($old_width / $old_height) > ($new_width / $new_height)){ 
			$new_height = ($old_height / ($old_width / $new_width));
		} else {
			$new_width = ($old_width / ($old_height / $new_height));
		}
	} else {
		$new_height = $old_height;
		$new_width = $old_width;
	}
?>
<? if($li % $list_col == 0) echo "<tr>"; ?>
      <td width="<?=(1/$list_col)*100?>%" align="center">
  			<table border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td class="imgl" width="<?=$img_width?>" height="<?=$img_height?>">
						<? if($img_view_url) { ?><a href="<?=$view_url?>"><img src="<?=$img_view_url?>" width="<?=$new_width?>" height="<?=$new_height?>" border="0"></a><? } ?>
						</td>
					</tr>
				</table>
				<div><a href="<?=$view_url?>"><?=$bd_subject?></a></div>
			</td>
<? if($li % $list_col == ($list_col-1))  echo "</tr>"; ?>
<? $li++; ?>