<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	/*
	$view_url : 글보기 링크
	$bd_name : 작성자명
	$bd_subject : 제목
	$i_comment_count : 코멘트 갯수
	$i_new : 새글 아이콘
	$bd_write_date : 작성일
	
	$first_img : 첫번째 이미지 정보(배열)
	$img_view_url : 첫번째 이미지 경로
	$img_width : 이미지 넓이
	$img_height : 이미지 높이
	*/
	if($first_img) {
		list($old_width, $old_height) = getimagesize($_path['bbs_data'].$first_img['sname']);
	
		// 이미지 비율을 계산한다.
		if($img_height < $old_height || $img_width < $old_width) {
			$new_height = $img_height;
			$new_width = $img_width;
			if(($old_width / $old_height) > ($new_width / $new_height)){ 
				$new_height = ($old_height / ($old_width / $new_width));
			} else {
				$new_width = ($old_width / ($old_height / $new_height));
			}
		} else {
			$new_height = $old_height;
			$new_width = $old_width;
		}
	}
?>
  <a href="<?=$view_url?>" class="list-group-item" style="padding:5px 5px;overflow:auto">
<? if($img_thumb_url) { ?>
			<table border="0" cellpadding="0" cellspacing="0" class="pull-left" style="margin-right:5px;">
				<tr>
					<td class="imgl" width="<?=$img_width?>" height="<?=$img_height?>" style="text-align:center !important">
					<img src="<?=$img_thumb_url?>" width="<?=$new_width?>" height="<?=$new_height?>">
					</td>
				</tr>
			</table>
<? } ?>
<div style="overflow:hidden">
		<h5 class="list-group-item-heading">
		<?=$i_secret?>
		<?=$bd_subject?>
		<?=$i_comment_count?>
		<?=$i_new?>
		</h5>
		<div class="list-group-item-text" style="margin-bottom:5px;color:#999;">
		<? if($_bbs_info['use_category'] && $cat_name!='') { ?>
			<?=$cat_name?> <span class='split'>|</span>
		<? } ?>
		<?=$bd_name?> <span class='split'>|</span> <?=$bd_write_date?> <span class='split'>|</span> 조회 : <?=$bd_view_count?> 
<?	
		if($lcfg['view_vote_yes'] && $lcfg['view_vote_no']) {
			echo "<span class='split'>|</span> <span class=\"glyphicon glyphicon-thumbs-up\"></span> $bd_vote_yes / <span class=\"glyphicon glyphicon-thumbs-down\"></span> $bd_vote_no";
		} else if($lcfg['view_vote_yes']) {
			echo "<span class='split'>|</span> <span class=\"glyphicon glyphicon-thumbs-up\"></span> ".$bd_vote_yes;
		} else if($lcfg['view_vote_no']) {
			echo "<span class='split'>|</span> <span class=\"glyphicon glyphicon-thumbs-down\"></span> ".$bd_vote_no;
		}
?>
</div>
		</div>
  </a>
