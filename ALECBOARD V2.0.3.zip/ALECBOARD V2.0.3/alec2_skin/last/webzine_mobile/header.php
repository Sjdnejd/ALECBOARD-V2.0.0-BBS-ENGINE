<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	/*
	$more_url : 더보기 링크(게시판)
	$_bbs_info['bbs_name'] : 게시판 정보중 게시판 이름
	*/
?>
<div class="last_gallery_thumbnail">
	<div class="list-group no-radius">
		<a href="<?=$more_url?>" class="list-group-item active">
			<i class="fa fa-file-text-o"></i> <?=$_bbs_info['bbs_name']?>
			<button class="btn btn-default btn-xs" style="float:right">more</button>
		</a>
