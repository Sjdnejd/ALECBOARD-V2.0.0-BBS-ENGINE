<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<div class="content">
<div class="title">&nbsp;&nbsp;회원정보수정</div>
		<br>
		<form name="member_form" method="post" action="?" onsubmit="return validate(this)" enctype='multipart/form-data'>
		<input type="hidden" name="form_mode" value="member_modify_ok">
		<input type="hidden" name="ret_url" value="../main/index.php">
		<input type="hidden" name="token" value="<?=$token?>">
		<? include('member_form.php') ?>
		<br>
		<div style="text-align:center">
		<input type="submit" value="  회원정보변경  " class="btn btn-default">
		</div>
		</form>
		<br>
<? if($_site_info['sl_naver']=='Y' || $_site_info['sl_facebook']=='Y' || $_site_info['sl_twitter']=='Y' || $_site_info['sl_google']=='Y') { ?>
<div class="title">&nbsp;&nbsp;SNS 연결 설정</div>
<div style="text-align:center">
<? if($_site_info['sl_naver']=='Y') { ?>
<div style="margin:8px auto">
	<? if(isset($sns_login['04'])) { ?>
		<button type="button" class="login_naver" onClick="location.href='<?=$_SERVER['PHP_SELF']?>?mode=sns_disconn&sns_gubun=04'"><div class="sns_login_txt">네이버 아이디 연결끊기</div></button>
		<br>
	<?=$sns_login['04']?>
	<? } else { ?>
	<button type="button" class="login_naver" onClick="login_naver()"><div class="sns_login_txt">네이버 아이디 연결하기</div></button>
	<? } ?>
</div>
<? } ?>
<? if($_site_info['sl_facebook']=='Y') { ?>
<div style="margin:8px auto">
	<? if(isset($sns_login['01'])) { ?>
	<button type="button" class="login_facebook" onClick="location.href='<?=$_SERVER['PHP_SELF']?>?mode=sns_disconn&sns_gubun=01'"><div class="sns_login_txt">페이스북 아이디 연결끊기</div></button>
	<br>
	<?=$sns_login['01']?>
	<? } else { ?>
	<button type="button" class="login_facebook" onClick="login_facebook()"><div class="sns_login_txt">페이스북 아이디 연결하기</div></button>
	<? } ?>
</div>
<? } ?>
<? if($_site_info['sl_twitter']=='Y') { ?>
<div style="margin:8px auto">
	<? if(isset($sns_login['02'])) { ?>
		<button type="button" class="login_twitter" onClick="location.href='<?=$_SERVER['PHP_SELF']?>?mode=sns_disconn&sns_gubun=02'"><div class="sns_login_txt">트위터 아이디 연결끊기</div></button>
		<br>
	<?=$sns_login['02']?>
	<? } else { ?>
	<button type="button" class="login_twitter" onClick="login_twitter()"><div class="sns_login_txt">트위터 아이디 연결하기</div></button>
	<? } ?>
</div>
<? } ?>
<? if($_site_info['sl_google']=='Y') { ?>
<div style="margin:8px auto">
	<? if(isset($sns_login['03'])) { ?>
	<button type="button" class="login_google" onClick="location.href='<?=$_SERVER['PHP_SELF']?>?mode=sns_disconn&sns_gubun=03'"><div class="sns_login_txt">구글 아이디 연결끊기</div></button>
	<br>
	<?=$sns_login['03']?>
	<? } else { ?>
	<button type="button" class="login_google" onClick="login_google()"><div class="sns_login_txt">구글 아이디 연결하기</div></button>
	<? } ?>
</div>
<? } ?>
</div>
<small>
＊현재 로그인된 계정으로 자동연결됩니다.<br>
＊다른 계정으로 연결시 해당 사이트에서 로그아웃 후 연결해주시기 바랍니다.
</small>
<? } ?>
</div>