<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<div class="login_box">
		<div class="title">로그인</div>
		<form name="login_form" method="post" action="?" onSubmit="return validate(this)" enctype='multipart/form-data' role="form">
		<input type="hidden" name="form_mode" value="member_login_ok">
		<input type="hidden" name="from" value="<?=$from?>">
		<input type="hidden" name="ret_url" value="<?=$ret_url?>">
		<div style="width:80%;margin:0 auto">
			<div class="form-group">
				<label for="f_mb_id" class="sr-only">아이디</label>
				<input name="mb_id" id="f_mb_id" type="text" class="form-control" hname="아이디" required placeholder="아이디">
			</div>
			<div class="form-group">
				<label for="f_mb_pass" class="sr-only">암호</label>
				<input name="mb_pass" id="f_mb_pass" type="password" class="form-control" required hname="암호" placeholder="암호">
			</div>
		</div>

		<div style="text-align:center">
		<input name="submit" type="submit" class="btn btn-primary" value=" 로 그 인 " style="width:80%" tabindex="103">
		</div>
		</form>
		<div style="margin:15px 0 5px 0;text-align:center">
			<input type="button" class="btn btn-default" value=" 회원가입 " style="width:38%" onClick="location.href='<?=$_path['member']?>join.php'">
			<input type="button" class="btn btn-default" value=" 암호찾기 " style="width:38%" onClick="location.href='<?=$_path['member']?>find_pass.php'">
		</div>
<? if($_site_info['sl_naver']=='Y' || $_site_info['sl_facebook']=='Y' || $_site_info['sl_twitter']=='Y' || $_site_info['sl_google']=='Y') { ?>
		<div style="margin:10px 0 5px 0;text-align:center">
<? if($_site_info['sl_naver']=='Y') { ?>
	<button type="button" class="login_naver" onClick="login_naver()" style="margin-top:10px"><div class="sns_login_txt">네이버 아이디로 로그인</div></button>
<? } ?>
<? if($_site_info['sl_facebook']=='Y') { ?>
	<button type="button" class="login_facebook" onClick="login_facebook()" style="margin-top:10px"><div class="sns_login_txt">페이스북 아이디로 로그인</div></button>
<? } ?>
<? if($_site_info['sl_twitter']=='Y') { ?>
	<button type="button" class="login_twitter" onClick="login_twitter()" style="margin-top:10px"><div class="sns_login_txt">트위터 아이디로 로그인</div></button>
<? } ?>
<? if($_site_info['sl_google']=='Y') { ?>
	<button type="button" class="login_google" onClick="login_google()" style="margin-top:10px"><div class="sns_login_txt">구글 아이디로 로그인</div></button>
<? } ?>
	</div>
<? } ?>

</div>
<script language='Javascript'>
	if(typeof(document.login_form.mb_id) != "undefined")
		document.login_form.mb_id.focus();
</script>