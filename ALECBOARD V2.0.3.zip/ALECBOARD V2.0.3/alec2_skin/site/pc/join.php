<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<script>
function join_member(){
	if(!document.getElementById("agree").checked) {
		alert('"회원가입약관"에 동의하셔야 회원가입이 가능합니다.');return false;
	}
	if(!document.getElementById("privacy").checked) {
		alert('"개인정보취급방침"에 동의하셔야 회원가입이 가능합니다.');return false;
	}
	location.replace('<?=$_url['member']?>join_form.php?from=<?=$from?>');
}
</script>
<div class="content">
<div class="title">&nbsp;&nbsp;회원가입 &gt; 약관동의</div>
		<br>
		※ 회원가입약관<br>
		<div style="width:100%;height:200px;overflow:auto;border:#CCC 1px solid"> 
		<?=$mb_agree?>
		</div>
		<input id="agree" value="" type="checkbox"> 위의 "회원가입약관"에 동의합니다.
		<br><br>
		※ 개인정보 취급방침<br>
		<div style="width:100%;height:200px;overflow:auto;border:#CCC 1px solid"> 
		<?=$mb_privacy?>
		</div>
		<input id="privacy" value="" type="checkbox"> 위의 "개인정보 취급방침"에 동의합니다.
		<br>
		<br>
		<div style="text-align:center">
		<input type="button" onClick="join_member()" value="  회원가입  " class="button">
		</div>
</div>
