<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	$rs_note = new $rs_class($dbcon);
	$rs_note->clear();
	$rs_note->set_table($_table['note']);
	$rs_note->add_field("count(*) as cnt");
	$rs_note->add_where("mb_num={$_mb['mb_num']}");
	$rs_note->add_where("recv_mb_num={$_mb['mb_num']}");
	$rs_note->add_where("nt_type=2");
	$rs_note->add_where("nt_save=0");
	$tmp=$rs_note->fetch();
	$note_cnt=$tmp['cnt'];
?>
		<div style="border-bottom:#999 1px solid;padding:2px;color:#FFF;background-color:#966;margin-bottom:5px;padding-top:4px">로그인 되어 있습니다.</div>
		<table border="0" cellpadding="0" cellspacing="2" width="85%">
			<tr>
					<td>아이디 : <?=$mb_id?> <a href="<?=$_url['member']?>note_recv.php" title="받은쪽지">(<?=$note_cnt?>)</a></td>
			</tr>
			<tr>
					<td>레벨 : <?=$mb_level_name?></td>
				</tr>
<? if($gr_level_name!='') { ?>
			<tr>
				<td>그룹레벨 : <?=$gr_level_name?></td>
			</tr>
<? } ?>
		</table>
		<div style="padding:3px;">
				<input type="button" class="button" value="로그아웃" onClick="location.href='<?=$logout_url?>'">
				<input type="button" class="button" value="정보수정" onClick="location.href='<?=$modify_url?>'">
		</div>