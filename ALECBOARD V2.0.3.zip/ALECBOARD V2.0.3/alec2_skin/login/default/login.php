<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
		<div style="border-bottom:#999 1px solid;padding:2px;color:#FFF;background-color:#966;margin-bottom:5px;padding-top:4px">회원 로그인</div>
		<form name="skin_login_form" method="post" action="<?=$login_action?>" onSubmit="return validate(this)" enctype='multipart/form-data'>
		<input type="hidden" name="form_mode" value="member_login_ok">
		<input type="hidden" name="ret_url" value="<?=$ret_url?>">
		<table border="0" cellpadding="0" cellspacing="2" width="85%">
			<tr>
					<td><input type='text' name='mb_id' onFocus="if ( this.value == '' ) { this.className='id_focus input' }" onBlur="if ( this.value == '' ) { this.className='id_blur input' }" class='id_blur input' size="20" maxlength="20" hname="아이디" required tabindex="111" /></td>
				<td rowspan="2" style="padding-left:1px"><input type="submit" class="login_btn" value="로그인" tabindex="113" style="height:40px" /></td>
			</tr>
			<tr>
					<td><input type='password' name='mb_pass' onFocus="this.className='pw_focus input'" onBlur="if ( this.value == '' ) { this.className='pw_blur input' }" class='pw_blur input' size="20" required hname="암호" tabindex="112" /></td>
				</tr>
		</table>
		</form>
		<div style="padding:3px;">
				<input type="button" class="button" value="회원가입" onClick="location.href='<?=$join_url?>'">
				<input type="button" class="button" value="암호찾기" onClick="location.href='<?=$password_url?>'">
		</div>
<? if($_site_info['sl_naver']=='Y' || $_site_info['sl_facebook']=='Y' || $_site_info['sl_twitter']=='Y' || $_site_info['sl_google']=='Y') { ?>
		<div style="padding-top:3px;">
		SNS아이디로 로그인 하기<br>
<? if($_site_info['sl_naver']=='Y') { ?><img src="../images/login_snaver.png" width="40" onClick="login_naver()" style="cursor:pointer" title="네이버 아이디로 로그인" alt="네이버"><? } ?>
<? if($_site_info['sl_facebook']=='Y') { ?><img src="../images/login_sfacebook.png" width="40" onClick="login_facebook()" style="cursor:pointer" title="페이스북 아이디로 로그인" alt="페이스북"><? } ?>
<? if($_site_info['sl_twitter']=='Y') { ?><img src="../images/login_stwitter.png" width="40" onClick="login_twitter()" style="cursor:pointer" title="트위터 아이디로 로그인" alt="트위터"><? } ?>
<? if($_site_info['sl_google']=='Y') { ?><img src="../images/login_sgoogle.png" width="40" onClick="login_google()" style="cursor:pointer" title="구글 아이디로 로그인" alt="구글"><? } ?>
		</div>
<? } ?>