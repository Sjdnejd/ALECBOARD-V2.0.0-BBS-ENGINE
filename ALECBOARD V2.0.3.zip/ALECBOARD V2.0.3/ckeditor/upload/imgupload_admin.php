 ===================================================== */
<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	$site_path=realpath("../../")."/";
	$site_url=str_replace("//","/",dirname(dirname(dirname($_SERVER['PHP_SELF'])))."/");
	include_once($site_path."alec2_include/lib.php");
	
	function SendResults($fileUrl,$msg='')
	{
		global $CKEditorFuncNum;
?>
<script type="text/javascript">
	window.parent.CKEDITOR.tools.callFunction(<?=$_REQUEST['CKEditorFuncNum']?>, '<?=$fileUrl?>','<?=$msg?>');
</script>
<?
		exit;
	}
	
	if(!$_auth['admin']) {
		SendResults('',"관리자만 사용가능한 기능입니다.");
	}

	$upload_file = $_FILES['upload'] ;
	list($width, $height, $image_type) = getimagesize($upload_file['tmp_name']);
	if($width == 0 || $height == 0 ||  !in_array($image_type,array(1,2,3))) { // gif,jpg,png 파일이 아니면
		SendResults('',"gif,jpg,png 파일만 업로드 가능합니다.");
	}
	
	$upload_path = $_path['data']."editor/";
	$upload_url = $_url['data']."editor/";

	$fileext=trim(strtolower(substr($upload_file['name'], strrpos($upload_file['name'],'.')+1))); 
	$new_filename = uniqid().".".$fileext;
	
	$icnt=0;
	while (true) {
		$savefile = $upload_path . $new_filename ;
	
		if(file_exists($savefile)) {
			$icnt++ ;
			$new_filename = uniqid().".".$fileext;
		} else {
			if(move_uploaded_file($upload_file['tmp_name'], $savefile)) {;
				$oldumask = umask(0) ;
				chmod( $savefile, 0777 ) ;
				umask( $oldumask ) ;
				$file_url = $upload_url.$new_filename;
			} else {
				SendResults('',"파일업로드중 오류 발생");
			}
			break ;
		}
	}
	SendResults($file_url) ;
?>