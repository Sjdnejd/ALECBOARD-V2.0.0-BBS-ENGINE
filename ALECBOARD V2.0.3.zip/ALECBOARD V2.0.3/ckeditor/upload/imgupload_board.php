<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	$site_path="../../";
	$site_url="../";
	include_once($site_path."alec2_include/lib.php");
	include_once($_path['inc']."lib_bbs.php");

	$tmp_level=$_gmb_info['gm_level'];
	if($tmp_level=='') $tmp_level=0;
	$wcfg['use_editor']=($_write_cfg['use_editor'] <= $tmp_level);
	$wcfg['use_editor_image']=$wcfg['use_editor'] && ($_write_cfg['use_editor_image'] <= $tmp_level);
	$wcfg['use_syntaxhighlight']=($_write_cfg['use_syntaxhighlight'] <= $tmp_level);

	function SendResults($fileUrl,$msg='')
	{
		global $CKEditorFuncNum;
?>
<script type="text/javascript">
	window.parent.CKEDITOR.tools.callFunction(<?=$_REQUEST['CKEditorFuncNum']?>, '<?=$fileUrl?>','<?=$msg?>');
</script>
<?
		exit;
	}
	
	if(!$wcfg['use_editor_image']) {
		SendResults('',"업로드 권한이 없습니다.");
	}
	
	$upload_file = $_FILES['upload'] ;
	list($width, $height, $image_type) = getimagesize($upload_file['tmp_name']);
	if($width == 0 || $height == 0 ||  !in_array($image_type,array(1,2,3))) { // gif,jpg,png 파일이 아니면
		SendResults('',"gif,jpg,png 파일만 업로드 가능합니다.");
	}
	
	// 실제 업로드된 파일을 처리
	$up_sname = uniqid('ckeditor_').".file";
	if (file_exists($_path['bbs_data'].$up_sname)) 
		$up_sname = uniqid('ckeditor_').".file";
		
	if(!move_uploaded_file($upload_file['tmp_name'], $_path['bbs_data'].$up_sname)) {
		return false;
	}
	@chmod($_path['bbs_data'].$up_sname,0777);
	// 여기까지 실제 파일 처리
	
	// db에 넣기
	$rs->clear();
	$rs->set_table($_table['bbs_file']);
	$rs->add_field("session_id",session_id()); // 세션
	$rs->add_field("bbs_db_num",$_bbs_info['bbs_db_num']); // db번호
	$rs->add_field("bd_num","0"); // 글번호
	$rs->add_field("bc_num","0"); // 코멘트번호
	$rs->add_field("mb_num",$_mb['mb_num']); // 등록자번호
	$rs->add_field("gubun","ckeditor"); // 구분(ckeditor)
	$rs->add_field("save_path",""); // 저장경로
	$rs->add_field("save_name",$up_sname); // 저장파일명
	$rs->add_field("file_key",""); // 파일키
	$rs->add_field("file_name",$dbcon->escape_string($upload_file['name'])); // 파일명
	$rs->add_field("file_type",$upload_file['type']); // 타입
	$rs->add_field("file_image_yn",'Y'); // 이미지여부
	$rs->add_field("file_size",filesize($_path['bbs_data'].$up_sname)); // 용량
	$rs->add_field("file_hit","0"); // 다운로드횟수 기존 파일 유지
	$rs->add_field("reg_date",time()); // 등록일
	$rs->insert();
	$num=$rs->get_insert_id();

	SendResults($_url['bbs']."down.php?bbs_code=$bbs_code&mode=view&gubun=ckeditor&num=".$num."&filename=".rg_base64($upload_file['name']));
?>