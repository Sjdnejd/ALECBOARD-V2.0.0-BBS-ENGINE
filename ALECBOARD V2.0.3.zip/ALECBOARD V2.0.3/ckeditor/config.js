/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */
CKEDITOR.editorConfig = function( config ) {
	config.toolbar_ALECBOARDV2 =
	[
		['Source','Preview','-','Bold','Italic','Underline','StrikeThrough','-','OrderedList','UnorderedList','-','Link','Unlink','-','Image','SpecialChar'],
		['Font','FontSize','TextColor','BGColor','About']
	];
	
	try 
	{
		if(editorConfig_Syntaxhighlight=='Y') {
			config.syntaxhighlight_lang = 'php';
			config.extraPlugins = 'syntaxhighlight';        //Add the plugin  
			config.toolbar_ALECBOARDV2.push(['Syntaxhighlight']);
		}
	} catch(err)
	{
	}
	
/*
config.syntaxhighlight_hideGutter = [true|false];
config.syntaxhighlight_hideControls = [true|false];
config.syntaxhighlight_collapse = [true|false];
config.syntaxhighlight_codeTitle = any title; default ''
config.syntaxhighlight_showColumns = [true|false];
config.syntaxhighlight_noWrap = [true|false];
config.syntaxhighlight_firstLine = any numeric value; default 0
config.syntaxhighlight_highlight = i.e. [1,3,9]; default null
config.syntaxhighlight_lang =
'applescript','actionscript3','as3','bash','shell','sh','coldfusion','cf','cpp','c','c#',
'c-sharp','csharp','css','delphi','pascal','pas','diff','patch','erl','erlang','groovy','haxe',
'hx','java','jfx','javafx','js','jscript','javascript','perl','Perl','pl','php','text','plain','powershell',
'ps','posh','py','python','ruby','rails','ror','rb','sass','scss','scala','sql','tap','Tap','TAP',
'ts','typescript','vb','vbnet','xml','xhtml','xslt','html'; default null
config.syntaxhighlight_code = any source code; default ''
*/

	config.toolbar = 'ALECBOARDV2';
	config.skin = 'moonocolor';

//	config.filebrowserBrowseUrl = 		 '/ckeditor/filemanager2';
//	config.filebrowserImageBrowseUrl = '/ckeditor/filemanager2/browser/default/browser.html?Connector=connectors/php/connector.php';
//	config.filebrowserImageBrowseUrl = '/ckeditor/filemanager2';
//	config.filebrowserFlashBrowseUrl = '/ckeditor/filemanager2/browser/default/browser.html?Connector=connectors/php/connector.php&type=Flash';
//	config.filebrowserUploadUrl = 		 '/ckeditor/filemanager2/core/connector/php/connector.php?command=QuickUpload&type=Files';
	try 
	{
		if(editorConfig_upload=='Y') {
			var scriptEls = document.getElementsByTagName( 'script' );
			var thisScriptEl = scriptEls[scriptEls.length - 1];
			var scriptPath = thisScriptEl.src;
			var scriptFolder = scriptPath.substr(0, scriptPath.lastIndexOf( '/' )+1 );
			
			config.filebrowserImageUploadUrl = 	scriptFolder + '/upload/imgupload_admin.php';
		}
	} catch(err)
	{
	}
	config.enterMode = CKEDITOR.ENTER_BR;

//	config.filebrowserFlashUploadUrl = '/ckeditor/filemanager/core/connector/php/connector.php?command=QuickUpload&type=Flash';

/*	config.filebrowserBrowseUrl = '/ckfinder/ckfinder.html';
	config.filebrowserImageBrowseUrl = '/ckfinder/ckfinder.html?type=Images';
	config.filebrowserFlashBrowseUrl = '/ckfinder/ckfinder.html?type=Flash';
	config.filebrowserUploadUrl = '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files';
	config.filebrowserImageUploadUrl = '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images';
	config.filebrowserFlashUploadUrl = '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash';*/
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
};