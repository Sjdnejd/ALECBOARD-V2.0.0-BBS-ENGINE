<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<body>
	<div id="sb_left_menu">
		<div style="padding:10px;border-bottom:1px solid #CCC;background-color:#EEE">
			<div class="btn-group">
				<a href="../m/index.php" class="btn btn-default"><span class="glyphicon glyphicon-home"></span> Home</a>
				<button type="button" class="btn btn-default" onClick="$('#sb_left_menu').hide(200);"><span class="glyphicon glyphicon-remove"></span> 닫기</button>
			</div>
		</div>
	
		<div style="padding:10px;overflow:visible">
			<div class="list-group" style="margin-bottom:15px">
				<a href="#" class="list-group-item active">
				 <span class="glyphicon glyphicon-folder-open" style="margin-right:10px"></span> Member
				</a>
<? if($_mb) { ?>
				<a class="list-group-item" href="<?=$_url['member']?>login.php?logout"><i class="fa fa-angle-right"></i> 로그아웃</a>
				<a class="list-group-item" href="<?=$_url['member']?>modify.php"><i class="fa fa-angle-right"></i> 정보수정</a>
<? if($_auth['admin']) { ?>
				<a class="list-group-item" href="<?=$_url['admin']?>" target="_blank"><i class="fa fa-angle-right"></i> 관리자접속</a>
<? } ?>	
<? } else { ?>
				<a class="list-group-item" href="<?=$_url['member']?>login.php"><i class="fa fa-angle-right"></i> 로그인</a>
				<a class="list-group-item" href="<?=$_url['member']?>join.php"><i class="fa fa-angle-right"></i> 회원가입</a>
<? } ?>
			</div>
<?
	$rs_group = new $rs_class($dbcon);
	$rs_group->clear();
	$rs_group->set_table($_table['group']);
	$rs->set_table($_table['bbs_cfg']);
	$i=0;
	while($tmp_group=$rs_group->fetch()) {
?>
			<div class="list-group" style="margin-bottom:15px">
				<a href="#" class="list-group-item active">
				 <span class="glyphicon glyphicon-folder-open" style="margin-right:10px"></span> <?=$tmp_group['gr_name']?>
				</a>
<?
		$rs->clear();
		$rs->set_table($_table['bbs_cfg']);
		if($tmp_group['gr_num']!='') 
            $rs->add_where("gr_num={$tmp_group['gr_num']}");
		while($tmp_bbs=$rs->fetch()) {
?>
					<a class="list-group-item" href="../alec2_board/list.php?bbs_code=<?=$tmp_bbs['bbs_code']?>"><i class="fa fa-angle-right"></i> <?=$tmp_bbs['bbs_name']?></a>
<?
		}
?>
				</div>
<?
	}
?>	
		</div>
		<div style="height:50px"></div>
	</div>
<div id="site-main">
	<!-- // 상단메뉴 -->
	<div class="navbar navbar-inverse" role="navigation">
		 <div class="container">
        <div class="navbar-header" style="float:none">
					<a href="../m/index.php" class="pull-left navbar-toggle" style="margin-left:15px;display:block !important;color:#FFF;padding: 6px 14px;">
						<i class="fa fa-home" style="font-size:18px"></i>
          </a>
          <div class="navbar-brand" style="padding-left:0px;">
					<?=$_bbs_info['bbs_name']!=''?$_bbs_info['bbs_name']:$_site_info['site_name']?>
					</div>
					<button type="button" class="pull-right navbar-toggle" id="sb_left_btn" style="display:block !important;">
						<span class="sr-only">메뉴</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
          </button>
        </div>
      </div>
	</div>
	<!-- 상단메뉴 // -->
	<div>