<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<? if($_mb) { ?>
	<div class="sub_title">
	- MyPage -
	</div>
	<ul class="sub_menu">
		<li><a href="<?=$_url['member']?>modify.php">정보수정</a></li>
		<li><a href="<?=$_url['member']?>login.php?logout">로그아웃</a></li>
		<li><a href="<?=$_url['member']?>leave.php">회원탈퇴</a></li>
		<li style="background-image:none;" ></li>
		<li><a href="<?=$_url['member']?>point_list.php">포인트내역</a></li>
		<li><a href="<?=$_url['member']?>note_recv.php">받은쪽지함</a></li>
		<li><a href="<?=$_url['member']?>note_sent.php">보낸쪽지함</a></li>
		<li><a href="<?=$_url['member']?>note_save.php">쪽지보관함</a></li>
		<li><a href="javascript:void(0)" onclick="note_write('<?=$_url['member']?>','')">쪽지쓰기</a></li>
</ul>
<? } else { ?>
	<div class="sub_title">
	- Member -
	</div>
	<ul class="sub_menu">
		<li><a href="<?=$_url['member']?>login.php">로그인</a></li>
		<li><a href="<?=$_url['member']?>join.php">회원가입</a></li>
		<li><a href="<?=$_url['member']?>find_id.php">아이디찾기</a></li>
		<li><a href="<?=$_url['member']?>find_pass.php">암호찾기</a></li>
</ul>

<? } ?>