<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	if(isset($_REQUEST['skin_path'])) exit;
	
	if($_bbs_auth['list']) {
		$tmp_level=$_gmb_info['gm_level'];
		if($tmp_level=='') $tmp_level=0;
		$lcfg=array();
		$lcfg['view_vote_yes']=($_view_cfg['vote_yes'] < 100);
		$lcfg['view_vote_no']=($_view_cfg['vote_no'] < 100);
	
		include('list_where.php');
		include('list_pre_process.php');

		if($mode==='list') include("_header.php");
		if(file_exists($skin_path."list.php")) include($skin_path."list.php");
		if($mode==='list') include('_footer.php');
	}
?>