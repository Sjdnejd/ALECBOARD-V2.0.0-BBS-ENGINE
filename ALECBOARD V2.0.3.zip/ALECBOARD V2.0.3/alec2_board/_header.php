<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	if($_site_mode=='mobile') {
		include('../include/m_header_win.php');
		if(file_exists($skin_path."style.php")) include($skin_path."style.php");
		if(file_exists($_group_info['mgr_header_file'])) include($_group_info['mgr_header_file']);
		if(file_exists($_bbs_info['m_header_file'])) include($_bbs_info['m_header_file']);
		echo $_bbs_info['m_header_tag'];
		if(file_exists($skin_path."header.php")) include($skin_path."header.php");
	} else {
		include('../include/header_win.php');
		if(file_exists($skin_path."style.php")) include($skin_path."style.php");
		if(file_exists($_group_info['gr_header_file'])) include($_group_info['gr_header_file']);
		if(file_exists($_bbs_info['header_file'])) include($_bbs_info['header_file']);
		echo $_bbs_info['header_tag'];
		if(file_exists($skin_path."header.php")) include($skin_path."header.php");		
	}
?>
<script>
set_url('<?=$_url['bbs']?>','<?=$_url['member']?>','<?=$skin_path?>');
</script>