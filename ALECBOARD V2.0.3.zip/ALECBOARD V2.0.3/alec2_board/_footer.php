<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	if($_site_mode=='mobile') {
		if(file_exists($skin_path."footer.php")) include($skin_path."footer.php");
		echo $_bbs_info['m_footer_tag'];
		if(file_exists($_bbs_info['m_footer_file'])) include($_bbs_info['m_footer_file']);
		if(file_exists($_group_info['mgr_footer_file'])) include($_group_info['mgr_footer_file']);
		include('../include/m_footer_win.php');
	} else {
		if(file_exists($skin_path."footer.php")) include($skin_path."footer.php");
		echo $_bbs_info['footer_tag'];
		if(file_exists($_bbs_info['footer_file'])) include($_bbs_info['footer_file']);
		if(file_exists($_group_info['gr_footer_file'])) include($_group_info['gr_footer_file']);
		include('../include/footer_win.php');
	}
?>
