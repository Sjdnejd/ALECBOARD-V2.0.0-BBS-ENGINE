<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
2007-07-27 큐브리드에서 다운로드 안되는 현상수정(sql문 버그)
 ===================================================== */
	include_once("../alec2_include/lib.php");
	include_once($_path['inc']."lib_bbs.php");

	$tmp_level=$_gmb_info['gm_level'];
	if($tmp_level=='') $tmp_level=0;
	$vcfg['use_download']=($_view_cfg['use_download'] <= $tmp_level);
	$vcfg['view_image']=($_view_cfg['view_image'] <= $tmp_level);

	if(file_exists($skin_path.'setup.php')) include($skin_path.'setup.php');
	
	$server_file = '';
	$file_type = '';
	$file_name = '';
	
	// 웹에디터에서 불러들임
	if($gubun == 'ckeditor') {
		if($mode != 'view') exit;
		if(!$validate->number_only($num)) exit;
		
		$filename = rg_base64($filename,1);

		$rs->clear();
		$rs->set_table($_table['bbs_file']);
		$rs->add_where("bbs_db_num = {$_bbs_info['bbs_db_num']}"); // db번호
		$rs->add_where("file_name = '".$dbcon->escape_string($filename)."'"); // 파일명
		$rs->add_where("file_key = ''"); // 파일키
		$rs->add_where("num = '$num'"); // 파일번호
		$rs->add_where("gubun = 'ckeditor'"); // 구분(에디터업로드)
		$data = $rs->fetch();
		if(!$data) exit;
		
		$server_file = $_path['bbs_data'].$data['save_name'];
		$file_type = $data['file_type'];
		$file_name = $data['file_name'];
	} // 웹에디터 여기까지 
	else
	{ // 첨부파일 불러오기
		if(!$vcfg['view_image'] && $mode=='view') rg_href('','권한이 없습니다.','back');
		if(!$vcfg['use_download'] && $mode=='down') rg_href('','권한이 없습니다.','back');
		if(!$validate->number_only($bd_num)) {
			exit;
		}
		// 파일정보 불러오기
		
		$rs->clear();
		$rs->set_table($_table['bbs_file']);
		$rs->add_where("bbs_db_num = {$_bbs_info['bbs_db_num']}"); // db번호
		$rs->add_where("bd_num='$bd_num'"); // 글번호
		$rs->add_where("file_key = '".$dbcon->escape_string($key)."'"); // 파일키
		$rs->add_where("gubun = 'attach'"); // 구분(첨부파일)
		$data = $rs->fetch();

		if(!$data) {
			rg_href('','파일정보가 올바르지 못합니다.','back');
		}

		$file_type = $data['file_type'];
		$file_name = $data['file_name'];

		if($mode=='thumb') { // 섬네일 가져오기
			if(!is_dir($_path['bbs_thumb'])) {
				if(!mkdir($_path['bbs_thumb'],0707)) {
					rg_href('',"섬네일 이미지 디렉토리 생성실패 {$_path['data_board_thumb']} 폴더를 만들어주세요.\\n권한(퍼미션)은 707 로 설정",'back');
				}
			}
			if($data['file_image_yn']=='Y') {
				$server_file = rg_thumbnail_create($_path['bbs_data'].$data['save_name'],$_path['bbs_thumb'].$data['save_name'],$_list_cfg['img_width'],$_list_cfg['img_height']);
			} else {
				rg_href('','파일정보가 올바르지 못합니다.','back');
			}
		} else if($mode=='down') { // 다운로드
			// 다운회수 증가
			$rs->clear();
			$rs->set_table($_table['bbs_file']);
			$rs->add_field("file_hit",$data['file_hit']+1); // 다운횟수
			$rs->add_where("num = '{$data['num']}'"); //
			$rs->update();
			$file_type = 'application/octet-stream';
			$server_file = $_path['bbs_data'].$data['save_name'];
		} else if($mode=='view') { // 보기
			if($data['file_image_yn']!='Y') { // 이미지가 아니면
				rg_href('','파일정보가 올바르지 못합니다.','back');
			}
			$server_file = $_path['bbs_data'].$data['save_name'];
		}
	}

	if($server_file != '' && $file_name != '' && $file_type != '') {
		if(!($fp = @fopen($server_file, "rb"))) return false;
		
		$file_name = iconv('utf-8','euc-kr',$file_name);
		$LastModified = gmdate("D d M Y H:i:s", filemtime($server_file)); 
		$filesize = filesize($server_file);

		header("Last-Modified: $LastModified GMT"); 
		header("ETag: \"$LastModified\""); 
		if($mode=='down') {
			header("Content-Type: {$file_type};name=\"$file_name\""); 
			header("Content-Disposition: attachment;filename=\"$file_name\""); 
		} else {
			header("Content-Type: {$file_type};name=\"$file_name\""); 
			header("Content-Disposition: filename=\"$file_name\""); 
		}

		for ($i = 0; $i <= $filesize; $i += 4096) { 
			if(!$body = fread($fp, 4096)) 
				return false;			 
			echo "$body"; // 화일내용을 읽어서 브라우저로 보내준다. 
		} 
		fclose($fp);
	} else {
		rg_href('','파일이 없습니다.','back');
	}
?>