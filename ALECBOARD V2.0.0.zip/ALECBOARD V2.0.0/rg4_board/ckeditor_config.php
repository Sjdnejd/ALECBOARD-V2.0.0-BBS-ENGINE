<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	include_once("../rg4_include/lib.php");
	include_once($_path['inc']."lib_bbs.php");

	$tmp_level=$_gmb_info['gm_level'];
	if($tmp_level=='') $tmp_level=0;
	$wcfg['use_editor']=($_write_cfg['use_editor'] <= $tmp_level);
	$wcfg['use_editor_image']=$wcfg['use_editor'] && ($_write_cfg['use_editor_image'] <= $tmp_level);
	$wcfg['use_syntaxhighlight']=($_write_cfg['use_syntaxhighlight'] <= $tmp_level);
	
	// 웹에디터에서 업로드된 데이타 삭제 및 변수 초기화
	unset($_SESSION['ss_upload']);
	$upload_path = $_path['data']."tmp/".session_id();
	rg_delete_board_file($upload_path);
?>
CKEDITOR.editorConfig = function( config ) {
	config.toolbar_ALECBOARDV2 =
	[
		['Source','Preview','-','Bold','Italic','Underline','StrikeThrough','-','BulletedList','-','Link','Unlink'],
		[ 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock' ],
		['Font','FontSize','TextColor','BGColor'],
		'/',
		['Save','Print','NewPage'],['ShowBlocks','Smiley','Templates','Blockquote','CreateDiv'],['Image','SpecialChar'],
	];
	
	config.font_names = '맑은 고딕; 돋움; 굴림; 궁서; 바탕;' +  config.font_names;

	config.toolbar = 'ALECBOARDV2';
	config.skin = 'moonocolor';
	
<? if($wcfg['use_editor_image']) { ?>
	config.filebrowserImageUploadUrl = '<?=$_url['site']?>ckeditor/upload/imgupload_board.php?bbs_code=<?=$bbs_code?>';
<? } ?>

<? if($wcfg['use_syntaxhighlight']) { ?>
	config.syntaxhighlight_lang = 'php';
	config.extraPlugins = 'syntaxhighlight';        //Add the plugin  
	config.toolbar_ALECBOARDV2.push(['Syntaxhighlight']);
<? } ?>

	config.toolbar_ALECBOARDV2.push(['About']);

	config.enterMode = CKEDITOR.ENTER_BR;
};