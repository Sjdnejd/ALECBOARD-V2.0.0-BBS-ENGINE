<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	include_once("../rg4_include/lib.php");
	include_once($_path['inc']."lib_bbs.php");
	
	$mode='list';
	
	if(file_exists($skin_path.'setup.php')) include($skin_path.'setup.php');
	if(!$_bbs_auth['list']) {
		$_msg_type='list_no_auth';
		include("msg.php");
		exit;
	}	
	include('list_main_process.php');
?>