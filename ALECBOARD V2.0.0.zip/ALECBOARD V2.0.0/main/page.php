<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	include_once("../rg4_include/lib.php");
	
	switch($page_id) {
		case 'agree' : $data = rg_get_setup('mb_agree'); $_title="이용약관"; break;
		case 'privacy' : $data = rg_get_setup('mb_privacy'); $_title="개인정보취급방침"; break;
		case 'company' : $data = rg_get_setup('page_company'); $_title="회사소개"; break;
	}
?>
<? include_once($_path['member'].'_header.php'); ?>
<div class="content">
<div class="title"><?=$_title?></div>
<div style="padding:10px">
		<?=$data?>
</div>
</div>
<? include_once($_path['member'].'_footer.php'); ?>