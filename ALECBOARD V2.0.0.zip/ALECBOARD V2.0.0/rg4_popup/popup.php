<?
	include_once("../rg4_include/lib.php");
?>
<?
	$rs->clear();
	$rs->set_table($_table['popup']);
	$rs->add_where("pp_num=$num");
	$R=$rs->fetch();
	if($R['pp_cont_type_cd']=='02') {
		header("Location:$R[pp_link_url]");
		exit;
	}
	$R['pp_images']=unserialize($R['pp_images']);
?>
<html>
<head>
<title><?=$R[pp_title]?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$_const['charset']?>">
<link href="<?=$_url['css']?>style.css" rel="stylesheet" type="text/css">
<script>
function setCookie(name, value, expiredays) {
	var todayDate = new Date();
	todayDate.setDate(todayDate.getDate() + expiredays);
	document.cookie = name + "=" + escape(value) + "; path=/; expires=" + todayDate.toGMTString() + ";"
}

function check_close() { 
	if (document.closeccc.closechk.checked) 
		setCookie("pop<?=$num?>", "no", 1);
	else
		setCookie("pop<?=$num?>", "yes", 1);
}
try {
opener.window.name='opener';
} catch (Exception) {
}
</script>
</head>
<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">
<?
	if($R['pp_cont_type_cd']=='01') { // 이미지
?>
<?
		if($R['pp_link_url']!='') {
		
?>
<a href="<?=$R['pp_link_url']?>" target="<? if($R['pp_win_type_cd']=='02') { // 레이어팝업 ?>_parent<? } else { ?>opener<? } ?>">
<?
		}
?><img src="<?=$_url['data'].'popup/'.$R['pp_images']['popup']['sname']?>" border="0" />
<?
		if($R['pp_link_url']!='') {
?>
</a>
<?
		}
?>
<?
	} else {
		echo $R['pp_content'];
	}
?>
<?
	$str_close='[닫기]';
	$str_close_chk='오늘하루 열지 않기.';
?>
<center>
<form name="closeccc" style="margin:0 0 0 0">
<input type="checkbox" name="closechk" id="closechk" onclick="check_close()" />
<?=$str_close_chk?>
<? if($R['pp_win_type_cd']=='02') { // 레이어팝업 ?>
<a href="javascript:parent.closeWin_<?=$R[pp_num]?>();"><?=$str_close?></a>
<? } else { ?>
<a href="javascript:self.close();"><?=$str_close?></a>
<? } ?>
</form>
</center>
</body>
</html>