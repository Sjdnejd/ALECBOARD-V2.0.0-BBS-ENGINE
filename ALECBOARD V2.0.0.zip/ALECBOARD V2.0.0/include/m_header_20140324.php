<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<body>
	<!-- // 상단메뉴 -->
	<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		 <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">토글메뉴</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="navbar-brand"><?=$_bbs_info['bbs_name']!=''?$_bbs_info['bbs_name']:$_site_info['site_name']?></div>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="../m/index.php">Home</a></li>
<?
	$rs_group = new $rs_class($dbcon);
	$rs_group->clear();
	$rs_group->set_table($_table['group']);
	$rs->set_table($_table['bbs_cfg']);
	$i=0;
	while($tmp_group=$rs_group->fetch()) {
?>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?=$tmp_group['gr_name']?> <b class="caret"></b></a>
              <ul class="dropdown-menu">
<?
		$rs->clear();
		$rs->set_table($_table['bbs_cfg']);
		if($_group_info['gr_num']!='') 
			$rs->add_where("gr_num={$_group_info['gr_num']}");
		while($tmp_bbs=$rs->fetch()) {
?>
								<li><a href="../rg4_board/list.php?bbs_code=<?=$tmp_bbs['bbs_code']?>"><?=$tmp_bbs['bbs_name']?></a></li>
<?
		}
?>
              </ul>
            </li>
<?
	}
?>
          </ul>
          <ul class="nav navbar-nav navbar-right">
<? if($_mb) { ?>
						<li><a href="<?=$_url['member']?>login.php?logout">로그아웃</a></li>
						<li><a href="<?=$_url['member']?>modify.php">정보수정</a></li>
<? } else { ?>
						<li><a href="<?=$_url['member']?>login.php">로그인</a></li>
						<li><a href="<?=$_url['member']?>join.php">회원가입</a></li>
<? } ?>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
	</div>
	<!-- 상단메뉴 // -->