<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
	<div style="clear:both"></div>
		<div class="footer" style="text-align:center;">
			<div style="text-align:center;margin-bottom:10px">
				<a href="../main/page.php?page_id=company">회사소개</a> | 
				<a href="../main/page.php?page_id=agree">이용약관</a> | 
				<a href="../main/page.php?page_id=privacy">개인정보취급방침</a> |
<?
$pc_url='../main/index.php';
// 게시판,회원,index.page.php 파일이면
if ( preg_match('/rg4\_board|rg4\_member|main\/page\.php/i', $_SERVER['REQUEST_URI']) ){
	$tmp = parse_url($_SERVER['REQUEST_URI']);
	$tmp_path = $tmp['path'];
	$tmp_query = $tmp['query'];
	if($tmp_query != '') {
		$pc_url=$tmp_path."?".$tmp_query."&chg_site=pc";
	} else {
		$mobile_url=$tmp_path."?chg_site=mobile";
	}
}
?>
				<a href="<?=$pc_url?>">PC버전보기</a>
<?php /*?>				<li class="last"><a href="">고객센터</a></li><?php */?>
			</div>
			Copyleft ⓒ 2022-<?=date('Y')?> <a href="http://alexleejw.com" target="_blank"><font color="#0000FF">ALECBOARDV2</font></a>.
				All rights not reserved. <br>
				<IMG height=3 width=1><br>
				ALECBOARDV2는 누구나 다운로드 받아 자유롭게 사용할수 있습니다.<br>
				저작권 표기를 자유롭게 수정/삭제,재배포도 가능합니다.<br></li>
		</div>
	</div>
</div>

<? include($_path['counter']."rg_counter.php"); ?>
</body>