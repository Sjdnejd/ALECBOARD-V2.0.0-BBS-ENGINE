<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
	2007-12-10 $form_info,$dong 변수 XSS 취약점 수정
 ===================================================== */
	include_once("../rg4_include/lib.php");
	$is_use=false;
	$form_info=rg_html_entity($form_info);
	$dong=rg_html_entity($dong);
?>
<? include('../include/header_win.php'); ?>
<body>
<div style="text-align:center;margin-top:10px">
		<a href="search_post.php?form_info=<?=$form_info?>">지번주소로 찾기(기존방식)</a> / <a href="search_post_road.php?form_info=<?=$form_info?>">도로명주소로 찾기</a>
</div>
		<form name="login_form" method="post" action="?" onSubmit="return validate(this)" enctype='multipart/form-data'>
		<input type="hidden" name="form_info" value="<?=$form_info?>">
<div class="title">우편번호찾기(지번주소로 찾기,기존방식)</div>
<? if($dbcon->list_tables($_table['zip'])) { ?>		
		<table width="100%" align="center" border="0" cellpadding="0" cellspacing="6">
			<tr>
			  <td align="center">
찾고자 하는 지역의 '동이름'을 입력해주십시오.<br>
예 : 서울시 강남구 삼성1동이라면 '삼성1'만 입력하시면 됩니다. 
				</td>
			  </tr>
			</table>
		<table width="400" align="center" border="0" cellpadding="0" cellspacing="6">
			<tr>
				<td width="70" align="right"><strong>동이름&nbsp;:</strong></td>
				<td align="center"><input type="text" class="input" name="dong" size="20" maxlength="12" minbyte="4"  hname="동이름" required  value="<?=$dong?>"> 동(읍/면)</td>
				<td width="70">
				  <input type="submit" class="button" value=" 검색 "></td>
			</tr>
		</table>
<? } else { ?>
		<table width="100%" align="center" border="0" cellpadding="0" cellspacing="6">
			<tr>
			  <td align="center">
우편번호테이블이 없습니다.<br>
관리자모드에서 우편번호 테이블을 생성하십시요.<br>
<a href="search_post_road.php?form_info=<?=$form_info?>">도로명주소로 찾기</a>는 지금 이용가능합니다.
				</td>
			  </tr>
			</table>
<? } ?>
<? if($dong!='') { ?>
<?
	list($form_name,$post1,$post2,$addr1,$addr2)=explode('|',$form_info);
?>
<script>
function submit_post(post,addr1) {
post=post.split('-');
addr1 = addr1.trim().replace(/  /gi, ' ').replace(/  /gi, ' ');
<? if($form_name!='') { ?>
		window.opener.document.<?=$form_name?>.<?=$post1?>.value = post[0];
		window.opener.document.<?=$form_name?>.<?=$post2?>.value = post[1];
		window.opener.document.<?=$form_name?>.<?=$addr1?>.value = addr1;
	<? if($addr2!='') { ?>
		window.opener.document.<?=$form_name?>.<?=$addr2?>.focus();
	<? } ?>   
<? } else { ?>
		window.opener.document.getElementById('<?=$post1?>').value = post[0];
		window.opener.document.getElementById('<?=$post2?>').value = post[1];
		window.opener.document.getElementById('<?=$addr1?>').value = addr1;
	<? if($addr2!='') { ?>
		window.opener.document.getElementById('<?=$addr2?>').focus();
	<? } ?>    			    
<? } ?>
self.close()	
}
</script>
		<table width="98%" border="0" cellpadding="0" cellspacing="0" onmouseover="list_over_color(event,'#FFE6E6',1)" onmouseout='list_out_color(event)' class="site_list" style="margin:0 auto">
			<col width="60">
			<tr>
				<th>우편번호</th>
				<th>주소</th>
			</tr>
<?
	$rs_list = new $rs_class($dbcon);
	$rs_list->clear();
	$rs_list->set_table($_table['zip']);
	$rs_list->add_order("seq");
	$rs_list->add_where("dong LIKE '%".$dbcon->escape_string($dong,DB_LIKE)."%' escape '".$dbcon->escape_ch."'");
	$rs_list->select();
	if($rs_list->num_rows()<1) {
		echo "
	<tr height=\"100\">
		<td align=\"center\"><B>등록(검색) 된 자료가 없습니다.</td>
	</tr>";
	}
	$page_info=$rs_list->select_list($page,50,10);
	$no = $page_info['start_no'];
	while($R=$rs_list->fetch()) {
		$no--;
?>
			<tr onClick="submit_post('<?=$R[zipcode]?>','<?=$R[sido]?> <?=$R[gugun]?> <?=$R[dong]?>');" style="cursor:pointer">
				<td align="center"><?=$R[zipcode]?></td>
				<td><?=$R[sido]?> <?=$R[gugun]?> <?=$R[dong]?> <?=$R[bunji]?></td>
			</tr>
<?
	}
?>
		</table>	
	<div style="text-align:center">
		<?=rg_navi_display($page_info,"dong=$dong&form_info=$form_info"); ?>
	</div>
<? } ?>		
<?php /*?>		<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td align="center">
				<input type="button" class="button" value="  닫  기  " onClick="self.close()">
					</td>
			</tr>
		</table><?php */?>
		</form>
</body>
<? include('../include/header_win.php'); ?>
