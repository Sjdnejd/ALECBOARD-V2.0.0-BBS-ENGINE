<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	include_once("../rg4_include/lib.php");
	$is_use=false;
?>
<? include('../include/header_win.php'); ?>
<body>
<div class="title">아이디 중복확인</div>
		<form name="login_form" method="post" action="?" onSubmit="return validate(this)" enctype='multipart/form-data'>
		<input type="hidden" name="form_info" value="<?=$form_info?>">
		<table width="300" align="center" border="0" cellpadding="0" cellspacing="6" style="margin:0 auto">
			<tr>
			  <td align="center">
<?
	if($mb_id!='') { 
		if(!$validate->userid($mb_id)) {
?> (<?=$mb_id?>)는 아이디로 사용할 수 없습니다.<? 
		} else {
			$rs->clear();
			$rs->set_table($_table['member']);
			$rs->add_where("mb_id='".$dbcon->escape_string($mb_id)."'");
			$rs->select();
			if(!$rs->num_rows()) { 
				$is_use=true;
?> (<?=$mb_id?>)는 사용가능한 아이디 입니다.<? 
			} else {
?> (<?=$mb_id?>)는 이미사용중인 아이디 입니다.<br>다른 아이디를 입력하세요.<? 
			}
		}
	} else { 
?> 사용할 아이디를 입력 해주세요.<?
	}
?>
				</td>
			  </tr>
			</table>
		<table width="300" align="center" border="0" cellpadding="0" cellspacing="6" style="margin:0 auto">
			<tr>
				<td width="50" align="right"><strong>아이디</strong>&nbsp;</td>
				<td width="120"><input type="text" class="input" name="mb_id" size="18" maxlength="12" hname="아이디" required option="userid"  value="<?=$mb_id?>"></td>
				<td><input name="submit" type="submit" class="button" value="중복확인"></td>
			</tr>
		</table>
		<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td align="center">
<? if($is_use) { ?>
<?
	list($form_name,$f_mb_id)=explode('|',$form_info);
	$form_mb_id="opener.$form_name.$f_mb_id";
?>
<script language="javascript">
function id_use() {
	if(window.opener.document.getElementById('<?=$f_mb_id?>') != null) {
		obj=window.opener.document.getElementById('<?=$f_mb_id?>');
	} else {
		obj=window.opener.document.<?=$form_name?>.<?=$f_mb_id?>
	}

	obj.value='<?=$mb_id?>';
	obj.focus();
	self.close()
}
</script>
				<input type="button" class="button" value=" 사용하기 " onClick="id_use()">
<? } ?>
				<input type="button" class="button" value="  닫  기  " onClick="self.close()">
					</td>
			</tr>
		</table>
		</form>
</body>
<? include('../include/header_win.php'); ?>
