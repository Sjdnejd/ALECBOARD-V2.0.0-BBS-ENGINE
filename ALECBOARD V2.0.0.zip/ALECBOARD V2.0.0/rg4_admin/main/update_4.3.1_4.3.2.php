<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	$_MENU='0505';
	include_once("../include/header_code.php");

	if($act) {
		switch(DB_TYPE) { // 디비종류
			case 'cubrid' :
				include_once('../schema/cubrid_schema.inc.php');
			break;
			case 'oracle' :
				include_once('../schema/oracle_schema.inc.php');
			break;
			case 'mysql' :
				include_once('../schema/mysql_schema.inc.php');
			break;
		}
		
		$table_array=array('bbs_file');
		foreach($table_array as $k => $v)	{					
			if(!$dbcon->list_tables($_table[$v])) {
				$dbcon->query("CREATE TABLE {$_table[$v]} \n {$db_schema[$v]}");
//			$dbcon->query("CREATE TABLE {$_table[$v]} {$db_schema[$v]} DEFAULT CHARSET=euckr");
			} else {
				rg_href("update.php","이미 테이블이 있습니다.");
			}
		}

		if(DB_TYPE=='cubrid') {
			// 인덱스, 시리얼, 트리거 생성
			foreach($table_array as $v)	{
				if(is_array($db_schema_index[$v])) {
					foreach($db_schema_index[$v] as $v1) {
						$dbcon->query("CREATE INDEX {$v1}_idx on {$_table[$v]} ({$v1})");
					}
				}
				
				if($db_schema_serial_field[$v] != '') {
					$serial_name="{$_table[$v]}__{$db_schema_serial_field[$v]}";
					$dbcon->query("CREATE SERIAL $serial_name START WITH 10");
				}
			}
		}

		if(DB_TYPE=='oracle') {
			// 인덱스, 시퀀스 생성
			$i=0;
			foreach($table_array as $v)	{
				if(is_array($db_schema_index[$v])) {
					foreach($db_schema_index[$v] as $v1) {
						$i++;
						$dbcon->query("CREATE INDEX i{$i}_{$v1}_idx on {$_table[$v]} ({$v1})");
					}
				}
				
				if($db_schema_serial_field[$v] != '') {
					$serial_name="{$_table[$v]}__{$db_schema_serial_field[$v]}";
					$dbcon->query("CREATE SEQUENCE $serial_name START WITH 10");
				}
			}
		}
		
		// 게시판 첨부파일 변환
		$rs_list->clear();
		$rs_list->set_table($_table['bbs_body']);
		while($R=$rs_list->fetch()) {
			$files=unserialize($R['bd_files']);
			if(is_array($files)) 
			{
				foreach($files as $k => $v) 
				{
					// 디비에 넣기
					$rs->clear();
					$rs->set_table($_table['bbs_file']);
					$rs->add_field("session_id",""); // 세션
					$rs->add_field("bbs_db_num",$R['bbs_db_num']); // 디비번호
					$rs->add_field("bd_num",$R['bd_num']); // 글번호
					$rs->add_field("bc_num","0"); // 코멘트번호
					$rs->add_field("mb_num",$R['mb_num']); // 등록자번호
					$rs->add_field("gubun","attach"); // 구분(첨부파일)
					$rs->add_field("save_path",""); // 저장경로
					$rs->add_field("save_name",$v['sname']); // 저장파일명
					$rs->add_field("file_key",$dbcon->escape_string($k)); // 파일키
					$rs->add_field("file_name",$dbcon->escape_string($v['name'])); // 파일명
					$rs->add_field("file_type",$v['type']); // 타입
					list($tmp_width, $tmp_height, $image_type) = getimagesize($_path['bbs_data'].$v['sname']);
					if($tmp_width == 0 || $tmp_height == 0 ||  !in_array($image_type,array(1,2,3))) { // gif,jpg,png 파일이 아니면
						$rs->add_field("file_image_yn",'N'); // 이미지여부
					} else {
						$rs->add_field("file_image_yn",'Y'); // 이미지여부
					}
					$rs->add_field("file_size",filesize($_path['bbs_data'].$v['sname'])); // 용량
					$rs->add_field("file_hit",$v['hits']); // 다운로드횟수 기존 파일 유지
					$rs->add_field("reg_date",time()); // 등록일
					$rs->insert();
					// 디비에 넣기 여기까지
				}
			}
		}
		
		$dbcon->query("
			ALTER TABLE  {$_table['bbs_body']} DROP bd_files
		");
		rg_href("update.php","데이타베이스 변환이 완료되었습니다.");
	}

?>
<? include("../include/header_win.php"); ?>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?> > 4.3.1 => 4.3.2</td>
  </tr>
</table>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="center"><br>
    <form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="if(!confirm('확실합니까?')) return false;">
<input name="act" type="hidden" value="ok">
          <table border="0" cellspacing="0" cellpadding="0" width="70%" class="site_content">
          <tr> 
            <td height="30" align="center" valign="middle" bgcolor="f7f7f7">ALECBOARDV2 데이타베이스를 4.3.1 에서 4.3.2 로 변환합니다.<br>
							에러 및 데이타 유실에대한 책임을 지지 않사오니 미리 백업해주시기 바랍니다.<br>
<br>
업데이트 내용<br>
<br>
게시판 업로드 파일 처리방식 변경</td>
          </tr>
        </table>
        <br>
        <input type="submit" value=" 업데이트시작 " class="button">
        <input type="button" value=" 취 소 " class="button" onClick="history.back()">
      </form></td>
  </tr>
</table>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>