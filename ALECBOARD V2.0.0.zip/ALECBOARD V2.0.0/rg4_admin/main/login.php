<?
/* =====================================================
	프로그램명 : ALECBOARDV2 V4
  화일명 : login.php (관리자 로그인)
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com
	
  최종수정일 : 
 ===================================================== */
	$site_path='../../';
	$site_url=str_replace("//","/",dirname(dirname(dirname($_SERVER['PHP_SELF'])))."/");
	include_once($site_path."rg4_include/lib.php");
?>
<? include("../include/header_win.php"); ?>
<body>
<div style="position:absolute;top:50%;left:50%;margin:-130px 0 0 -250px;width:500px;height:230px;text-align:center">
		<div align="center" style="width:400px;display:inline-block">
			<form name="login_form" method="post" action="<?=$_url['member']?>login.php" onSubmit="return validate(this)" enctype="multipart/form-data">
			<input type="hidden" name="form_mode" value="member_login_ok">
			<input type="hidden" name="ret_url" value="<?=$_url['admin']?>main/index.php">
			<input type="hidden" name="ret_url_login" value="<?=$_url['admin']?>main/login.php">
				<table border="0" cellpadding="0" cellspacing="0" width="100%">
					<tr> 
						<td width="100"> <p><img src="../images/logo.gif" width="120" height="55" border="0"></p></td>
						<td align="center"> <p>ALECBOARDV2 관리자 접속을 위한 인증 단계 입니다.<br>
							관리자 아이디와 암호를 정확히 입력해주세요.</p></td>
					</tr>
				</table>
				<br>
				<table width="100%" class="site_content">
					<tr> 
						<th width="130" height=30>관리자 아이디&nbsp;:&nbsp;</th>
						<td width="264" style="text-align:left"><input type="text" name="mb_id" size="20" maxlength="20" minlength="2" required hname="아이디" class="input"></td>
					</tr>
					<tr> 
						<th height=30>관리자 암호&nbsp;:&nbsp;</th>
						<td style="text-align:left"><input type="password" name="mb_pass" size="20" maxlength="20" required hname="암호" class="input"></td>
					</tr>
				</table>
				<table border="0" cellpadding="10" cellspacing="0" width="100%">
					<tr> 
						<td align="center">&nbsp;</td>
					</tr>
					<tr> 
						<td align="center">부당한 방법으로 접속시 불이익을 받을수 있으니 주의하시기 바랍니다</td>
					</tr>
					<tr> 
						<td align="center">&nbsp;</td>
					</tr>
					<tr> 
						<td align="center"> <input type="submit" value=" 확 인 " class="button">
					&nbsp; 
					<input type="button" value=" 뒤 로 " onclick='history.go(-1);' class="button"></td>
					</tr>
				</table>
				<br />
      </form>
			<table width="100%" cellpadding="0" cellspacing="0">
			  <tr>
			    <td align="center"><a href="http://alexleejw.com" target="_blank">Copyleft ⓒ 2003 ALECBOARDV2. All rights not reserved.</a></td>
		    </tr>
		  </table>
		</div>
	</div>
<script language='Javascript'>
	document.login_form.mb_id.focus();
</script>
</body>
<? include("../include/footer_win.php"); ?>