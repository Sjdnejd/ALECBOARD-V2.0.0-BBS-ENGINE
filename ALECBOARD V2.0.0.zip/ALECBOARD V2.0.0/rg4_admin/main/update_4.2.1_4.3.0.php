<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	$_MENU='0505';
	include_once("../include/header_code.php");

	if($act) {
		function chg_utf8_euckr($str) {
			return iconv("euc-kr", "utf-8", $str);
		}

		function ser_euckr_utf8($ser_str) {
			$tmp = unserialize(iconv("utf-8","euc-kr", $ser_str));
			if(is_array($tmp)) {
				rg_array_recursive_function($tmp,"chg_utf8_euckr");
				return serialize($tmp);
			} else {
				return $ser_str;
			}
		}
		
		// 사이트설정 테이블 변환
		$rs_list->clear();
		$rs_list->set_table($_table['setup']);
		while($R=$rs_list->fetch()) {
			$rs->clear();
			$rs->set_table($_table['setup']);
			$rs->add_field("ss_content",ser_euckr_utf8($R['ss_content']));
			$rs->add_where("ss_num='$R[ss_num]'");
			$rs->update();
		}
		
		// 회원
		$rs_list->clear();
		$rs_list->set_table($_table['member']);
		while($R=$rs_list->fetch()) {
			$rs->clear();
			$rs->set_table($_table['member']);
			$rs->add_field("mb_ext1",ser_euckr_utf8($R['mb_ext1']));
			$rs->add_field("mb_ext2",ser_euckr_utf8($R['mb_ext2']));
			$rs->add_field("mb_ext3",ser_euckr_utf8($R['mb_ext3']));
			$rs->add_field("mb_ext4",ser_euckr_utf8($R['mb_ext4']));
			$rs->add_field("mb_ext5",ser_euckr_utf8($R['mb_ext5']));
			$rs->add_field("mb_open_field",ser_euckr_utf8($R['mb_open_field']));
			$rs->add_field("mb_files",ser_euckr_utf8($R['mb_files']));
			$rs->add_where("mb_num='$R[mb_num]'");
			$rs->update();
		}
		
		// 게시판 설정
		$rs_list->clear();
		$rs_list->set_table($_table['bbs_cfg']);
		while($R=$rs_list->fetch()) {
			$rs->clear();
			$rs->set_table($_table['bbs_cfg']);
			$rs->add_field("list_cfg",ser_euckr_utf8($R['list_cfg']));
			$rs->add_field("write_cfg",ser_euckr_utf8($R['write_cfg']));
			$rs->add_field("reply_cfg",ser_euckr_utf8($R['reply_cfg']));
			$rs->add_field("view_cfg",ser_euckr_utf8($R['view_cfg']));
			$rs->add_where("bbs_num='$R[bbs_num]'");
			$rs->update();
		}
		
		// 게시판 첨부파일등
		$rs_list->clear();
		$rs_list->set_table($_table['bbs_body']);
		while($R=$rs_list->fetch()) {
			$rs->clear();
			$rs->set_table($_table['bbs_body']);
			$rs->add_field("bd_ext1",ser_euckr_utf8($R['bd_ext1']));
			$rs->add_field("bd_ext2",ser_euckr_utf8($R['bd_ext2']));
			$rs->add_field("bd_ext3",ser_euckr_utf8($R['bd_ext3']));
			$rs->add_field("bd_ext4",ser_euckr_utf8($R['bd_ext4']));
			$rs->add_field("bd_ext5",ser_euckr_utf8($R['bd_ext5']));
			$rs->add_field("bd_files",ser_euckr_utf8($R['bd_files']));
			$rs->add_field("bd_links",ser_euckr_utf8($R['bd_links']));
			$rs->add_where("bd_num='$R[bd_num]'");
			$rs->update();
		}
		
		// 그룹설정
		$rs_list->clear();
		$rs_list->set_table($_table['group']);
		while($R=$rs_list->fetch()) {
			$rs->clear();
			$rs->set_table($_table['group']);
			$rs->add_field("gr_level_info",ser_euckr_utf8($R['gr_level_info']));
			$rs->add_field("gr_ext_cfg",ser_euckr_utf8($R['gr_ext_cfg']));
			$rs->add_where("gr_num='$R[gr_num]'");
			$rs->update();
		}
		
		// 그룹회원
		$rs_list->clear();
		$rs_list->set_table($_table['gmember']);
		while($R=$rs_list->fetch()) {
			$rs->clear();
			$rs->set_table($_table['gmember']);
			$rs->add_field("gm_ext1",ser_euckr_utf8($R['gm_ext1']));
			$rs->add_field("gm_ext2",ser_euckr_utf8($R['gm_ext2']));
			$rs->add_field("gm_ext3",ser_euckr_utf8($R['gm_ext3']));
			$rs->add_field("gm_ext4",ser_euckr_utf8($R['gm_ext4']));
			$rs->add_field("gm_ext5",ser_euckr_utf8($R['gm_ext5']));
			$rs->add_where("gm_num='$R[gm_num]'");
			$rs->update();
		}
		
		// 팝업이미지
		$rs_list->clear();
		$rs_list->set_table($_table['popup']);
		while($R=$rs_list->fetch()) {
			$rs->clear();
			$rs->set_table($_table['popup']);
			$rs->add_field("pp_images",ser_euckr_utf8($R['pp_images']));
			$rs->add_where("pp_num='$R[pp_num]'");
			$rs->update();
		}
		
		
		rg_href("update.php","데이타베이스 변환이 완료되었습니다.");
	}

?>
<? include("../include/header_win.php"); ?>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?> > 4.2.1 => 4.3.0</td>
  </tr>
</table>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="center"><br>
    <form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="if(!confirm('확실합니까?')) return false;">
<input name="act" type="hidden" value="ok">
          <table border="0" cellspacing="0" cellpadding="0" width="70%" class="site_content">
          <tr> 
            <td height="30" align="center" valign="middle" bgcolor="f7f7f7">ALECBOARDV2 데이타베이스를 4.2.1 에서 4.3.0 로 변환합니다.<br>
							에러 및 데이타 유실에대한 책임을 지지 않사오니 미리 백업해주시기 바랍니다.<br>
<br>
업데이트 내용<br>
<br>
문자셋 euc-kr 에서 utf-8로 변경으로 인한 serialize 데이타 변환</td>
          </tr>
        </table>
        <br>
        <input type="submit" value=" 업데이트시작 " class="button">
        <input type="button" value=" 취 소 " class="button" onClick="history.back()">
      </form></td>
  </tr>
</table>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>