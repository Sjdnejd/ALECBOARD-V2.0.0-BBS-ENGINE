<?
/* =====================================================
  프로그램명 : ALECBOARDV2 V4
  화일명 : 
  작성일 : 
  작성자 : 윤범석 ( http://alexleejw.com )
  작성자 E-Mail : master@alexleejw.com

  최종수정일 : 
 ===================================================== */
	$_MENU='0505';
	include_once("../include/header_code.php");

	if($act) {
		switch(DB_TYPE) { // 디비종류
			case 'cubrid' :
				include_once('../schema/cubrid_schema.inc.php');
			break;
			case 'oracle' :
				include_once('../schema/oracle_schema.inc.php');
			break;
			case 'mysql' :
				include_once('../schema/mysql_schema.inc.php');
			break;
		}

		$table_array=array('member_sns');
		foreach($table_array as $k => $v)	{					
			if(!$dbcon->list_tables($_table[$v])) {
				$dbcon->query("CREATE TABLE {$_table[$v]} \n {$db_schema[$v]}");
//			$dbcon->query("CREATE TABLE {$_table[$v]} {$db_schema[$v]} DEFAULT CHARSET=euckr");
			} else {
				rg_href("update.php","이미 테이블이 있습니다.");
			}
		}

		if(DB_TYPE=='cubrid') {
			// 인덱스, 시리얼, 트리거 생성
			foreach($table_array as $v)	{
				if(is_array($db_schema_index[$v])) {
					foreach($db_schema_index[$v] as $v1) {
						$dbcon->query("CREATE INDEX {$v1}_idx on {$_table[$v]} ({$v1})");
					}
				}
				
				if($db_schema_serial_field[$v] != '') {
					$serial_name="{$_table[$v]}__{$db_schema_serial_field[$v]}";
					$dbcon->query("CREATE SERIAL $serial_name START WITH 10");
				}
			}
		}

		if(DB_TYPE=='oracle') {
			// 인덱스, 시퀀스 생성
			$i=0;
			foreach($table_array as $v)	{
				if(is_array($db_schema_index[$v])) {
					foreach($db_schema_index[$v] as $v1) {
						$i++;
						$dbcon->query("CREATE INDEX i{$i}_{$v1}_idx on {$_table[$v]} ({$v1})");
					}
				}
				
				if($db_schema_serial_field[$v] != '') {
					$serial_name="{$_table[$v]}__{$db_schema_serial_field[$v]}";
					$dbcon->query("CREATE SEQUENCE $serial_name START WITH 10");
				}
			}
		}
		
		rg_href("update.php","데이타베이스 변환이 완료되었습니다.");
	}

?>
<? include("../include/header_win.php"); ?>
<? include("../include/header.php"); ?>
<table border="0" cellspacing="0" cellpadding="0" width="100%" class="site_content">
  <tr>
    <td bgcolor="#F7F7F7"><?=$_TITLE?> > 4.3.0 => 4.3.1</td>
  </tr>
</table>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align="center"><br>
    <form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="if(!confirm('확실합니까?')) return false;">
<input name="act" type="hidden" value="ok">
          <table border="0" cellspacing="0" cellpadding="0" width="70%" class="site_content">
          <tr> 
            <td height="30" align="center" valign="middle" bgcolor="f7f7f7">ALECBOARDV2 데이타베이스를 4.3.0 에서 4.3.1 로 변환합니다.<br>
							에러 및 데이타 유실에대한 책임을 지지 않사오니 미리 백업해주시기 바랍니다.<br>
<br>
업데이트 내용<br>
<br>
SNS연동 테이블 생성</td>
          </tr>
        </table>
        <br>
        <input type="submit" value=" 업데이트시작 " class="button">
        <input type="button" value=" 취 소 " class="button" onClick="history.back()">
      </form></td>
  </tr>
</table>
<? include("../include/footer.php"); ?>
<? include("../include/footer_win.php"); ?>