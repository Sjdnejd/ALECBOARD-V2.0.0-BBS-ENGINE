<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<? include('../include/m_footer.php'); ?>
<? include('../include/m_footer_win.php'); ?>