<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	include_once($_default_skin_path.basename(__FILE__));
?>