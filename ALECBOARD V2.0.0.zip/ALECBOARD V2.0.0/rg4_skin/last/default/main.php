<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<?
	/*
	$view_url : 글보기 링크
	$bd_name : 작성자명
	$bd_subject : 제목
	$i_comment_count : 코멘트 갯수
	$i_new : 새글 아이콘
	$bd_write_date : 작성일
	*/
?>
<tr>
	<td><a href="<?=$view_url?>"><?php /*?>[<?=$bd_name?>] <?php */?><?=$bd_subject?> <?=$i_comment_count?> <?=$i_new?></a></td>
	<td class="date"><?=$bd_write_date?></td>
</tr>