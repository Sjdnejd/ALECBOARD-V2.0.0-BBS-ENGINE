<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<div class="login_box">
		<div class="title">회원정보수정</div>
		<form name="member_form" method="post" action="?" onsubmit="return validate(this)" enctype='multipart/form-data'>
		<input type="hidden" name="form_mode" value="member_modify">
		<input type="hidden" name="ret_url" value="../main/index.php">
※ 본인확인을 위해 암호를 입력해주세요.
		<table width="100%" align="center" border="0" cellpadding="0" cellspacing="6" style="margin-top:10px">
  <col width=120></col>
  <tr>
    <td align="right"><strong>아이디</strong>&nbsp;</td>
    <td><?=$_mb[mb_id]?></td>
  </tr>
  <tr>
    <td align="right"><strong>암호</strong></td>
    <td><input name="mb_pass_confirm" type="password" class="input" size="20" maxbyte="12" minbyte="4" required hname="암호"></td>
  </tr>
</table>
		<div style="margin:10px 0 5px 0;text-align:center">
			<input type="submit" value=" 회원정보수정 " class="button">
		</div>
		</form>
</div>
