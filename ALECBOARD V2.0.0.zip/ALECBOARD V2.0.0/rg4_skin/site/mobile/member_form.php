<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<style>
.input-70p {width:70%;float:left;margin-right:5px}
.input-45p {width:45%;float:left;margin-right:5px}
.input-25p {width:25%;float:left;margin-right:5px}
.input-80px {width:80px;float:left;margin-right:5px}
.input-a {width:auto;float:left;margin-right:5px}
</style>
<div style="margin:auto 10px">
<? if($mode=="member_join") { ?>
	<div class="form-group">
		<label for="f_mb_id"><span style="color:#F00">*</span> 아이디</label>
		<div>
		<input name="mb_id" id="f_mb_id" type="text" class="form-control input-45p" hname="아이디" value="" maxlength="12" required option="userid" placeholder="아이디">
		<input name="button" type="button" class="btn btn-default" onClick="search_mb_id('<?=$_url['member']?>','member_form|mb_id',document.member_form.mb_id.value)" value="중복확인" style="float:left;">
		</div>
		<div style="clear:both"></div>
		<small>
      3~12자의 한글,영문자,숫자,&quot;-&quot;,&quot;_&quot; 만 가능합니다.<br />
      단 &quot;-&quot;나 &quot;_&quot; 는 첫문자로 사용할 수 없습니다.
		</small>
  </div>
<? } else { ?>
	<div class="form-group">
		<label>아이디</label>
		<div>
		<p class="form-control input-45p"><?=$data['mb_id']?></p>
		</div>
		<div style="clear:both"></div>
	</div>
<? } // end if member_join ?>
	<div class="form-group">
		<label for="f_mb_pass"><? if($required['mb_pass']!='') { ?><span style="color:#F00">*</span><? } ?> 암호</label>
		<div>
		<input name="mb_pass" id="f_mb_pass" type="password" class="form-control input-45p" maxbyte="12" minbyte="4" <?=$required['mb_pass']?> hname="암호" match="mb_pass1" placeholder="암호">
    <input name="mb_pass1" type="password" class="form-control input-45p" hname="암호확인" placeholder="암호확인">
		</div>
		<div style="clear:both"></div>
		<small>
     4자 이상 12자 이하로 입력해주세요.
		</small>
  </div>
<? if($member_form['mb_name']!=0) { ?>
<? if($mode=="member_join") { ?>
	<div class="form-group">
		<label for="f_mb_name"><? if($required['mb_name']!='') { ?><span style="color:#F00">*</span><? } ?> 이름</label>
		<div>
		<input name="mb_name" id="f_mb_name" type="password" class="form-control input-45p" maxlength="20" minbyte="2" option="hanonly" <?=$required['mb_name']?> hname="이름" placeholder="이름">
		<label>
		<input type="checkbox" name="of[mb_name]" value="1" <?=$c_of['mb_name']?> />
    공개
		</label>
		</div>
		<div style="clear:both"></div>
		<small>
     공백없이 한글로만 입력해주세요.
		</small>
  </div>
<? } else { ?>
	<div class="form-group">
		<label>이름</label>
		<div>
		<p class="form-control input-45p"><?=$data['mb_name']?></p>
		<label><input type="checkbox" name="of[mb_name]" value="1" <?=$c_of['mb_name']?> /> 공개</label>
		</div>
		<div style="clear:both"></div>
	</div>
<? } // end if member_join ?>
<? } // end if mb_name ?>
<? if($member_form['mb_nick']!=0) { ?>
	<div class="form-group">
		<label for="f_mb_nick"><? if($required['mb_nick']!='') { ?><span style="color:#F00">*</span><? } ?> 닉네임</label>
		<div>
		<input name="mb_nick" id="f_mb_nick" type="text" class="form-control input-45p" value="<?=$data['mb_nick']?>" maxlength="20" minbyte="2" hname="닉네임" option="nick" <?=$required['mb_nick']?> placeholder="닉네임">
		<input name="button" type="button" class="btn btn-default pull-left" onClick="search_mb_nick('<?=$_url['member']?>','member_form|mb_nick',document.member_form.mb_nick.value)" value="중복확인">
		</div>
		<div style="clear:both"></div>
		<small>
     2~12자의 한글,영문자,숫자,"-","_" 만 가능합니다.
		</small>
  </div>
<? } // end if mb_nick ?>
<? if($member_form['mb_email']!=0) { ?>
	<div class="form-group">
		<label for="f_mb_email"><? if($required['mb_email']!='') { ?><span style="color:#F00">*</span><? } ?> 이메일</label>
		<div>
		<input name="mb_email" id="f_mb_email" type="text" class="form-control input-45p" value="<?=$data['mb_email']?>" maxlength="100" hname="이메일" option="email" <?=$required['mb_email']?> placeholder="이메일">
		<label>
		<input type="checkbox" name="of[mb_email]" value="1" <?=$c_of['mb_email']?> />
    공개
		</label>
		</div>
		<div style="clear:both"></div>
  </div>
<? } // end if mb_email ?>
<? if($member_form['mb_jumin']!=0) { ?>
<? if($mode=="member_join") { ?>
	<div class="form-group">
		<label for="f_mb_jumin1"><? if($required['mb_jumin']!='') { ?><span style="color:#F00">*</span><? } ?> 주민등록번호</label>
		<div>
		<input name="mb_jumin1" id="f_mb_jumin1" type="text" class="form-control input-a" size="6" maxlength="6" value="" span="2" glue="-" option="jumin" hname="주민등록번호" <?=$required['mb_jumin']?> placeholder="주민번호">
		<span class="pull-left" style="margin-right:5px">-</span>
		<input type="password" class="form-control input-a" name="mb_jumin2" size="7" maxlength="7" value="">
		</div>
		<div style="clear:both"></div>
  </div>
<? } // end if member_join ?>
<? } // end if mb_jumin ?>
<? if($member_form['mb_tel1']!=0) { ?>
	<div class="form-group">
		<label for="f_mb_tel11"><? if($required['mb_tel1']!='') { ?><span style="color:#F00">*</span><? } ?> 전화번호</label>
		<div>
		<input name="mb_tel11" id="f_mb_tel11" type="text" class="form-control input-80px" maxlength="4" value="<?=$data['mb_tel11']?>" option="phone" span="3" hname="전화번호" <?=$required['mb_tel1']?> placeholder="">
		<span class="pull-left" style="margin-right:5px">-</span>
		<input name="mb_tel12" id="f_mb_tel12" type="text" class="form-control input-80px" maxlength="4" value="<?=$data['mb_tel12']?>" placeholder="">
		<span class="pull-left" style="margin-right:5px">-</span>
		<input name="mb_tel13" id="f_mb_tel13" type="text" class="form-control input-80px" maxlength="4" value="<?=$data['mb_tel13']?>" placeholder="">
		<label>
		<input type="checkbox" name="of[mb_tel1]" value="1" <?=$c_of['mb_tel1']?> />
    공개
		</label>
		</div>
		<div style="clear:both"></div>
  </div>
<? } // end if mb_tel1 ?>
<? if($member_form['mb_tel2']!=0) { ?>
	<div class="form-group">
		<label for="f_mb_tel21"><? if($required['mb_tel2']!='') { ?><span style="color:#F00">*</span><? } ?> 핸드폰번호</label>
		<div>
		<input name="mb_tel21" id="f_mb_tel21" type="text" class="form-control input-80px" maxlength="4" value="<?=$data['mb_tel21']?>" option="phone" span="3" hname="핸드폰번호" <?=$required['mb_tel1']?> placeholder="">
		<span class="pull-left" style="margin-right:5px">-</span>
		<input name="mb_tel22" id="f_mb_tel22" type="text" class="form-control input-80px" maxlength="4" value="<?=$data['mb_tel22']?>" placeholder="">
		<span class="pull-left" style="margin-right:5px">-</span>
		<input name="mb_tel23" id="f_mb_tel23" type="text" class="form-control input-80px" maxlength="4" value="<?=$data['mb_tel23']?>" placeholder="">
		<label>
		<input type="checkbox" name="of[mb_tel2]" value="1" <?=$c_of['mb_tel2']?> />
    공개
		</label>
		</div>
		<div style="clear:both"></div>
  </div>
<? } // end if mb_tel2 ?>
<? if($member_form['mb_address']!=0) { ?>
	<div class="form-group">
		<label for="f_mb_post1"><? if($required['mb_address']!='') { ?><span style="color:#F00">*</span><? } ?> 우편번호</label>
		<div>
		<input type="text" class="form-control input-a" name="mb_post1" id="f_mb_post1" size="3" maxlength="3" readonly value="<?=$data['mb_post1']?>" span="2" hname="우편번호" <?=$required['mb_address']?> placeholder="">
		<span class="pull-left" style="margin-right:5px">-</span>
    <input type="text" name="mb_post2" class="form-control input-a" size="3" maxlength="3" readonly value="<?=$data['mb_post2']?>">
		<input type="button" class="btn btn-default pull-left" onClick="search_post('<?=$_url['member']?>','member_form|mb_post1|mb_post2|mb_address1|mb_address2')" value='우편번호 찾기' style="margin-right:5px"> 
		<label>
		<input type="checkbox" name="of[mb_post]" value="1" <?=$c_of['mb_post']?> />
    공개
		</label>
		</div>
		<div style="clear:both"></div>
  </div>

	<div class="form-group">
		<label for="f_mb_address1"><? if($required['mb_address']!='') { ?><span style="color:#F00">*</span><? } ?> 주소</label>
		<div>
		<input name="mb_address1" id="f_mb_address1" type="text" class="form-control" value="<?=$data['mb_address1']?>" readonly hname="주소" <?=$required['mb_address']?> placeholder="주소" style="margin-bottom:2px">
    <input name="mb_address2" type="text" class="form-control" id="mb_address2" value="<?=$data['mb_address2']?>" hname="상세주소" <?=$required['mb_address']?> placeholder="상세주소">
		</div>
		<div style="clear:both"></div>
  </div>
<? } // end if mb_address ?>
<? if($member_form['mb_signature']!=0) { ?>
	<div class="form-group">
		<label for="f_mb_signature"><? if($required['mb_signature']!='') { ?><span style="color:#F00">*</span><? } ?> 서명</label>
		<div>
		<textarea name="mb_signature" id="f_mb_signature" rows="3" class="form-control" hname="서명" <?=$required['mb_signature']?> placeholder="서명"><?=$data['mb_signature']?></textarea>
		</div>
		<div style="clear:both"></div>
		<small>
    본인이 작성한 글 하단에 표시됩니다.
		</small>
  </div>
<? } // end if mb_signature ?>
<? if($member_form['mb_introduce']!=0) { ?>
	<div class="form-group">
		<label for="f_mb_introduce"><? if($required['mb_introduce']!='') { ?><span style="color:#F00">*</span><? } ?> 자기소개</label>
		<div>
		<textarea name="mb_introduce" id="f_mb_introduce" rows="3" class="form-control" hname="자기소개" <?=$required['mb_introduce']?> placeholder="자기소개"><?=$data['mb_introduce']?></textarea>
		</div>
		<div style="clear:both"></div>
		<small>
    정보공개한 경우 다른 사람이 볼수 있습니다.
		</small>
  </div>
<? } // end if mb_introduce ?>
<? if($member_form['icon1']!=0) { ?>
	<div class="form-group">
		<label for="f_mb_files_icon1"><? if($required['icon1']!='') { ?><span style="color:#F00">*</span><? } ?> 회원아이콘</label>
		<div>
			<input type="file" name="mb_files[icon1]" id="f_mb_files_icon1" class="form-control input-70p" hname="회원아이콘" <?=$required['icon1']?> placeholder="회원아이콘">
		</div>
		<div style="clear:both"></div>
		<div>
			<? if($data['mb_files']['icon1']['name']!='') { ?>
			<label>
				<?=$data['mb_files']['icon1']['name']?>
				<input type="checkbox" name="mb_files_del[icon1]" value="1" />
				삭제
			</label>
			<? } ?>
		</div>
  </div>
<? } // end if icon1 ?>
<? if($member_form['photo1']!=0) { ?>
	<div class="form-group">
		<label for="f_mb_files_photo1"><? if($required['photo1']!='') { ?><span style="color:#F00">*</span><? } ?> 사진</label>
		<div>
			<input type="file" name="mb_files[photo1]" id="f_mb_files_photo1" class="form-control input-70p" hname="사진" <?=$required['icon1']?> placeholder="사진" />
			<input type="checkbox" name="of[photo1]" value="1" <?=$c_of[photo1]?> />
			공개
		</div>
		<div style="clear:both"></div>
		<div>
			<? if($data['mb_files']['photo1']['name']!='') { ?>
			<label>
				<?=$data['mb_files']['photo1']['name']?>
				<input type="checkbox" name="mb_files_del[photo1]" value="1" />
				삭제
			</label>
			<? } ?>
		</div>
  </div>
<? } // end if photo1 ?>
	<div class="form-group">
		<label style="margin-right:20px"><input name="mb_is_mailing" type="checkbox" id="mb_is_mailing" value="1" <?=$c_mb_is_mailing[1]?>> 메일수신</label>
		<label><input name="mb_is_opening" type="checkbox" id="mb_is_opening" value="1" <?=$c_mb_is_opening[1]?>> 정보공개</label>
  </div>
</div>