<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<script>
function join_member(){
	if(!document.getElementById("agree").checked) {
		alert('"회원가입약관"에 동의하셔야 회원가입이 가능합니다.');return false;
	}
	if(!document.getElementById("privacy").checked) {
		alert('"개인정보취급방침"에 동의하셔야 회원가입이 가능합니다.');return false;
	}
	location.replace('<?=$_url['member']?>join_form.php?from=<?=$from?>');
}
</script>
<div class="content">
<div class="panel-group" id="accordion">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#mb_agree">
          회원가입약관
        </a>
			    <label>
			      <input id="agree" value="" type="checkbox"> 동의합니다.
			    </label>
      </h4>
    </div>
    <div id="mb_agree" class="panel-collapse collapse in">
      <div class="panel-body" style="height:250px;overflow:auto;">
        <?=$mb_agree?>
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#mb_privacy">
          개인정보 취급방침
        </a>
			    <label>
			      <input id="privacy" value="" type="checkbox"> 동의합니다.
			    </label>
      </h4>
    </div>
    <div id="mb_privacy" class="panel-collapse collapse">
      <div class="panel-body" style="height:250px;overflow:auto;">
        <?=$mb_privacy?>
      </div>
    </div>
  </div>
</div>
<div style="text-align:center;margin-bottom:10px">
		<input type="button" onClick="join_member()" value="  회원가입  " class="btn btn-default">
</div>
</div>