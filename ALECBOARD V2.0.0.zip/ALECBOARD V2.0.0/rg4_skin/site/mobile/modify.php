<? if (!defined('ALECBOARDV2_VERSION')) exit; ?>
<div class="login_box">
		<div class="title">회원정보수정</div>
		<form name="member_form" method="post" action="?" onsubmit="return validate(this)" enctype='multipart/form-data'>
		<input type="hidden" name="form_mode" value="member_modify">
		<input type="hidden" name="ret_url" value="../main/index.php">
&nbsp; &nbsp; ※ 본인확인을 위해 암호를 입력해주세요.
<div class="text-center" style="margin-bottom:20px">
	<div style="text-align:left;width:60%;margin:auto auto;padding-top:20px">
		<div class="form-group">
			<label>아이디</label>
			<p class="form-control"><?=$_mb[mb_id]?></p>
		</div>
		
		<div class="form-group">
			<label for="mb_pass_confirm">암호</label>
			<input name="mb_pass_confirm" id="mb_pass_confirm" type="password" class="form-control" value=""  maxbyte="12" minbyte="4" required hname="암호" placeholder="암호">
		</div>
	</div>
	<input type="submit" value=" 회원정보수정 " class="btn btn-default">
	</form>
</div>
</div>
